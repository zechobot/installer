@extends('layouts.admin')

@section('title', 'Access Tokens')

@section('content')
<div class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Token Access</h3>
          <div class="box-tools">
            <a href="{{ route('tokens.create') }}" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Create Token</a>
            <a href="{{ route('tokens.export.csv') }}" class="btn btn-sm btn-success">Export CSV</a>
          </div>
        </div>

        <div class="box-body table-responsive no-padding">
          <table class="table table-hover">
            <thead>
              <tr>
                <th>ID</th>
                <th>SN</th>
                <th>Token</th>
                <th>Duration</th>
                <th>Activated</th>
                <th>Expires At</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              @foreach($tokens as $t)
              <tr>
                <td>{{ $t->id }}</td>
                <td>{{ $t->sn }}</td>
                <td><code style="word-break:break-all">{{ $t->token }}</code></td>
                <td>{{ $t->durationHuman() }}</td>
                <td>{{ $t->activated_at ? $t->activated_at->toDateTimeString() : '-' }}</td>
                <td>{{ $t->expires_at ? $t->expires_at->toDateTimeString() : ($t->isPermanent() ? 'Permanent' : 'Not activated') }}</td>
                <td>
                  @if($t->isPermanent())
                    <span class="label label-success">Permanent</span>
                  @elseif($t->isActivated() && !$t->isExpired())
                    <span class="label label-warning">Active</span>
                  @elseif($t->isActivated() && $t->isExpired())
                    <span class="label label-danger">Expired</span>
                  @else
                    <span class="label label-primary">Unused</span>
                  @endif
                </td>
                <td>
                  <a href="{{ route('tokens.edit', $t->id) }}" class="btn btn-xs btn-info">Edit</a>
                  <form action="{{ route('tokens.delete', $t->id) }}" method="POST" style="display:inline">
                    @csrf
                    <button class="btn btn-xs btn-danger" onclick="return confirm('Delete token?')">Delete</button>
                  </form>
                </td>
              </tr>
              @endforeach
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>
</div>

@if(session('new_token'))
<!-- show modal with new token for copying -->
<div id="newTokenModal" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-sm"><div class="modal-content">
    <div class="modal-header"><h4 class="modal-title">Token Created</h4></div>
    <div class="modal-body">
      <p>SN: <strong>{{ session('new_sn') }}</strong></p>
      <div class="input-group">
        <input id="newTokenInput" class="form-control" readonly value="{{ session('new_token') }}">
        <span class="input-group-btn"><button id="copyTokenBtn" class="btn btn-primary">Copy</button></span>
      </div>
      <small>Copy token now — it will not be shown again.</small>
    </div>
    <div class="modal-footer"><button class="btn btn-default" data-dismiss="modal">Close</button></div>
  </div></div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function(){
  $('#newTokenModal').modal('show');
  document.getElementById('copyTokenBtn').addEventListener('click', function(){
    const input = document.getElementById('newTokenInput');
    input.select();
    document.execCommand('copy');
    this.innerText = 'Copied';
    setTimeout(()=> this.innerText = 'Copy', 2000);
  });
});
</script>
@endif

@endsection