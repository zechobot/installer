@extends('layouts.admin')

@section('title', 'Edit Protex Access')

@section('content')
<div class="card">
    <div class="card-body">

        {{-- HEADER PROTEX --}}
        <div style="font-size:14px; font-weight:bold; margin-bottom:10px; color:#4a4a4a;">
            Protex V1.0.0 — By Felix Hasgawa
        </div>

        <h3>IZIN AKSES UNTUK: {{ $user->username }}</h3>

        <form method="POST" action="{{ route('admin.protex.save', $user->id) }}">
            @csrf

            {{-- ======================== --}}
            {{-- Akses Menu --}}
            {{-- ======================== --}}
            <h4>Akses Menu</h4>

            @foreach([
                'edit_account'=>'Edit Users',
                'create_account'=>'Crate Users',
                'delete_account'=>'Delete Users',
                'self_edit_access'=>'Edit Akses',
                'ak_ppt'=>'Akses Protex',
                'ak_sett' => 'Akses Settings',
                'ak_api'  => 'Akses API',
                'ak_db'   => 'Akses Database',
                'ak_loc'  => 'Akses Locations',
                'ak_node' => 'Akses Nodes',
                'ak_srv'  => 'Akses Servers',
                'ak_usr'  => 'Akses Users',
                'ak_mou'  => 'Akses Mounts',
                'ak_egg'  => 'Akses Egg'
            ] as $k => $label)
                <div>
                    <label>
                        <input type="checkbox" name="permissions[{{ $k }}]" value="1"
                            {{ !empty($permissions[$k]) ? 'checked' : '' }}>
                        {{ $label }}
                    </label>
                </div>
            @endforeach

            <hr>

            {{-- ======================== --}}
            {{-- General --}}
            {{-- ======================== --}}
            <h4>General</h4>

            <div>
                <label>
                    <input type="checkbox" name="permissions[access_foreign_server]" value="1"
                        {{ !empty($permissions['access_foreign_server']) ? 'checked' : '' }}>
                    Allow access to other admins' servers
                </label>
            </div>

            <div>
                <label>
                    <input type="checkbox" name="permissions[view]" value="1"
                        {{ !empty($permissions['view']) ? 'checked' : '' }}>
                    View Console
                </label>
            </div>

            <hr>

            {{-- ======================== --}}
            {{-- Command & Power --}}
            {{-- ======================== --}}
            <h4>Command / Power</h4>

            <div>
                <label>
                    <input type="checkbox" name="permissions[command]" value="1"
                        {{ !empty($permissions['command']) ? 'checked' : '' }}>
                    Command
                </label>
            </div>

            <div>
                <label>
                    <input type="checkbox" name="permissions[power]" value="1"
                        {{ !empty($permissions['power']) ? 'checked' : '' }}>
                    Power
                </label>
            </div>

            <hr>

            {{-- ======================== --}}
            {{-- File Manager --}}
            {{-- ======================== --}}
            <h4>File Manager</h4>

            @php
                $file = [
                    'file_list'      => 'List',
                    'file_view'      => 'View contents',
                    'file_download'  => 'Download',
                    'file_rename'    => 'Rename',
                    'file_copy'      => 'Copy',
                    'file_edit'      => 'Edit',
                    'file_compress'  => 'Compress',
                    'file_decompress'=> 'Decompress',
                    'file_delete'    => 'Delete',
                    'file_create'    => 'Create folder',
                    'file_chmod'     => 'Chmod',
                    'file_upload'    => 'Upload',
                    'file_pull'      => 'Pull',
                ];
            @endphp

            @foreach($file as $k => $label)
                <div>
                    <label>
                        <input type="checkbox" name="permissions[{{ $k }}]" value="1"
                            {{ !empty($permissions[$k]) ? 'checked' : '' }}>
                        {{ $label }}
                    </label>
                </div>
            @endforeach

            <hr>

            {{-- ======================== --}}
            {{-- Backups --}}
            {{-- ======================== --}}
            <h4>Backups</h4>

            @foreach([
                'backup_view'     => 'View',
                'backup_create'   => 'Create',
                'backup_download' => 'Download',
                'backup_edit'     => 'Lock/Unlock',
                'backup_restore'  => 'Restore',
                'backup_delete'   => 'Delete'
            ] as $k => $label)
                <div>
                    <label>
                        <input type="checkbox" name="permissions[{{ $k }}]" value="1"
                            {{ !empty($permissions[$k]) ? 'checked' : '' }}>
                        {{ $label }}
                    </label>
                </div>
            @endforeach

            <hr>

            {{-- ======================== --}}
            {{-- Startup --}}
            {{-- ======================== --}}
            <h4>Startup</h4>

            @foreach([
                'startup_view'     => 'View Startup',
                'startup_edit'     => 'Edit Startup',
                'settings_rename'  => 'Rename',
                'settings_reinstall'=> 'Reinstall'
            ] as $k => $label)
                <div>
                    <label>
                        <input type="checkbox" name="permissions[{{ $k }}]" value="1"
                            {{ !empty($permissions[$k]) ? 'checked' : '' }}>
                        {{ $label }}
                    </label>
                </div>
            @endforeach

            <hr>

            <button class="btn btn-primary" type="submit">Save</button>
            <a class="btn btn-secondary" href="{{ route('admin.protex.index') }}">Back</a>

        </form>
    </div>
</div>

{{-- COPYRIGHT FOOTER --}}
<div style="text-align:center; margin-top:30px; font-size:14px; opacity:0.8;">
    <a href="https://t.me/GlobalBotzXD" target="_blank" style="text-decoration:none; color:inherit;">
        <img src="https://cdn-icons-png.flaticon.com/512/2111/2111646.png"
             style="width:18px; vertical-align:middle; margin-right:6px;">
        © @zecho Tahun 2015 - 2025
    </a>
</div>

{{-- NOTIFICATION TOAST --}}
<script>
document.addEventListener('DOMContentLoaded', function () {
    const username = @json($user->username);

    const message = document.createElement('div');
    message.textContent = `🚀 Protex ${username}, akses diubah.`;
    Object.assign(message.style, {
        position: "fixed",
        bottom: "20px",
        right: "20px",
        background: "rgba(0,0,0,0.75)",
        color: "#fff",
        padding: "10px 15px",
        borderRadius: "10px",
        fontFamily: "monospace",
        fontSize: "14px",
        boxShadow: "0 0 10px rgba(0,0,0,0.3)",
        zIndex: "9999",
        opacity: "1",
        transition: "opacity 0.3s ease"
    });

    document.body.appendChild(message);

    setTimeout(() => message.style.opacity = "0", 3000);
    setTimeout(() => message.remove(), 3400);
});
</script>

@endsection