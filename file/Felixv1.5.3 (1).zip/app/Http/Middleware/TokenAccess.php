<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Models\Token;

class TokenAccess
{
    public function handle($request, Closure $next)
    {
        // ==========================
        // 1. ADMIN UTAMA BYPASS
        // ==========================
        if (Auth::check() && Auth::id() === 1) {
            return $next($request);
        }

        // ==========================
        // 2. TOKEN SESSION CHECK
        // ==========================
        $sn = $request->session()->get('token_sn');
        $value = $request->session()->get('token_value');

        // Jika belum login token → simpan URL yg diminta
        if (!$sn) {
            session()->put('url.intended', $request->fullUrl());
            return redirect()->route('token.form');
        }

        // Ambil token berdasarkan SN
        $token = Token::where('sn', $sn)->first();

        if (!$token) {
            $request->session()->forget(['token_sn', 'token_value']);
            session()->put('url.intended', $request->fullUrl());
            return redirect()->route('token.form')->with('error', 'Token tidak ditemukan.');
        }

        // ==========================
        // 3. EXPIRED CHECK
        // ==========================
        if ($token->isExpired()) {
            $token->delete();
            $request->session()->forget(['token_sn','token_value']);
            session()->put('url.intended', $request->fullUrl());
            return redirect()->route('token.form')->with('error', 'Token sudah expired.');
        }

        // ==========================
        // 4. SESSION TOKEN VALID?
        // ==========================
        if ($value !== $token->token) {
            $request->session()->forget(['token_sn','token_value']);
            session()->put('url.intended', $request->fullUrl());
            return redirect()->route('token.form')->with('error', 'Sesi token tidak valid.');
        }

        return $next($request);
    }
}