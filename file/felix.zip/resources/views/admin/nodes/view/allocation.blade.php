@extends('layouts.admin')

@section('title')
    {{ $node->name }}: Allocations
@endsection

@section('content-header')
    <h1>{{ $node->name }}<small>Control allocations available for servers on this node.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li><a href="{{ route('admin.nodes') }}">Nodes</a></li>
        <li><a href="{{ route('admin.nodes.view', $node->id) }}">{{ $node->name }}</a></li>
        <li class="active">Allocations</li>
    </ol>
@endsection

@section('content')
<div class="row">
    <div class="col-sm-8">
        {{-- Existing allocations (tabel lama tetap) --}}
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Existing Allocations</h3>
            </div>
            <div class="box-body table-responsive no-padding" style="overflow-x: visible">
                <table class="table table-hover" style="margin-bottom:0;">
                    <tr>
                        <th><input type="checkbox" class="select-all-files hidden-xs" data-action="selectAll"></th>
                        <th>IP Address <i class="fa fa-fw fa-minus-square" style="font-weight:normal;color:#d9534f;cursor:pointer;" data-toggle="modal" data-target="#allocationModal"></i></th>
                        <th>IP Alias</th>
                        <th>Port</th>
                        <th>Assigned To</th>
                        <th>
                            <div class="btn-group hidden-xs">
                                <button type="button" id="mass_actions" class="btn btn-sm btn-default dropdown-toggle disabled"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Mass Actions <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu dropdown-massactions">
                                    <li><a href="#" id="selective-deletion" data-action="selective-deletion">Delete <i class="fa fa-fw fa-trash-o"></i></a></li>
                                </ul>
                            </div>
                        </th>
                    </tr>
                    @foreach($node->allocations as $allocation)
                        <tr>
                            <td class="middle min-size" data-identifier="type">
                                @if(is_null($allocation->server_id))
                                <input type="checkbox" class="select-file hidden-xs" data-action="addSelection">
                                @else
                                <input disabled="disabled" type="checkbox" class="select-file hidden-xs" data-action="addSelection">
                                @endif
                            </td>
                            <td class="col-sm-3 middle" data-identifier="ip">{{ $allocation->ip }}</td>
                            <td class="col-sm-3 middle">
                                <input class="form-control input-sm" type="text" value="{{ $allocation->ip_alias }}" data-action="set-alias" data-id="{{ $allocation->id }}" placeholder="none" />
                                <span class="input-loader" style="display:none;"><i class="fa fa-refresh fa-spin fa-fw"></i></span>
                            </td>
                            <td class="col-sm-2 middle" data-identifier="port">{{ $allocation->port }}</td>
                            <td class="col-sm-3 middle">
                                @if(! is_null($allocation->server))
                                    <a href="{{ route('admin.servers.view', $allocation->server_id) }}">{{ $allocation->server->name }}</a>
                                @endif
                            </td>
                            <td class="col-sm-1 middle">
                                @if(is_null($allocation->server_id))
                                    <button data-action="deallocate" data-id="{{ $allocation->id }}" class="btn btn-sm btn-danger"><i class="fa fa-trash-o"></i></button>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </table>
            </div>
            @if($node->allocations->hasPages())
                <div class="box-footer text-center">
                    {{ $node->allocations->render() }}
                </div>
            @endif
        </div>
    </div>

    {{-- Assign New Allocations (form gaya baru tapi fungsi lama tetap) --}}
    <div class="col-sm-4">
        <form id="allocationForm" action="{{ route('admin.nodes.view.allocation', $node->id) }}" method="POST">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title">Assign New Allocations</h3>
                </div>
                <div class="box-body">

                    {{-- IP combo: existing + manual --}}
                    <div class="form-group">
                        <label class="control-label">IP Address</label>
                        <div>
                            <select id="ipSelect" class="form-control" style="width:100%">
                                <option value="" selected disabled>None</option>
                                @foreach($allocations as $allocation)
                                    <option value="{{ $allocation->ip }}">{{ $allocation->ip }}</option>
                                @endforeach
                                <option value="__manual__">-- Manual Input (Type new IP) --</option>
                            </select>
                            <input type="hidden" name="ip" id="ipField" value="" />
                            <div id="manualIpBox" style="margin-top:8px; display:none;">
                                <input type="text" id="manualIpInput" class="form-control" placeholder="e.g. 192.168.1.10" />
                                <p class="text-muted small">Type a new IP address to register automatically.</p>
                            </div>
                        </div>
                    </div>

                    {{-- Alias --}}
                    <div class="form-group">
                        <label for="alias" class="control-label">IP Alias</label>
                        <div>
                            <input type="text" id="alias" class="form-control" name="alias" placeholder="alias (optional)" />
                            <p class="text-muted small">Optional alias for these allocations.</p>
                        </div>
                    </div>

                    {{-- Port Mode --}}
                    <div class="form-group">
                        <label for="mode" class="control-label">Port Mode</label>
                        <select id="mode" name="mode" class="form-control">
                            <option value="auto">Auto (preset ranges)</option>
                            <option value="manual">Manual (type/select ports)</option>
                            <option value="custom">Custom (enter ranges / list)</option>
                        </select>
                    </div>

                    {{-- Auto: preset range --}}
                    <div id="autoBox" class="form-group" style="display:none;">
                        <label class="control-label">Preset Auto Range</label>
                        <select name="range" id="rangeSelect" class="form-control">
                            <option value="1">1024 — 3000</option>
                            <option value="2">1024 — 4000</option>
                            <option value="3">1024 — 5000</option>
                            <option value="4">1024 — 6000</option>
                        </select>
                        <p class="text-muted small">Auto assigns all ports in the selected range, skipping existing ones.</p>
                    </div>

                    {{-- Manual ports --}}
                    <div id="manualBox" class="form-group" style="display:none;">
                        <label class="control-label">Select / Type Ports</label>
                        <select id="portsSelect" name="ports[]" class="form-control" multiple style="width:100%"></select>
                        <p class="text-muted small">Type ports (e.g. 25565) or paste a list.</p>
                        <div style="margin-top:6px;">
                            <button type="button" id="fill3000" class="btn btn-xs btn-default">Fill 1024–3000</button>
                            <button type="button" id="fill4000" class="btn btn-xs btn-default">Fill 1024–4000</button>
                            <button type="button" id="fill5000" class="btn btn-xs btn-default">Fill 1024–5000</button>
                            <button type="button" id="fill6000" class="btn btn-xs btn-default">Fill 1024–6000</button>
                        </div>
                    </div>

                    {{-- Custom ports --}}
                    <div id="customBox" class="form-group" style="display:none;">
                        <label for="custom" class="control-label">Custom Ports / Ranges</label>
                        <input type="text" id="custom" name="custom" class="form-control" placeholder="e.g. 25565,30000-30010,19132" />
                        <p class="text-muted small">Enter comma-separated ports and ranges. Ranges use hyphen (30000-30010).</p>
                    </div>

                </div>
                <div class="box-footer">
                    {!! csrf_field() !!}
                    <button type="submit" class="btn btn-success btn-sm pull-right">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>

{{-- Delete modal tetap lama --}}
<div class="modal fade" id="allocationModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Delete Allocations for IP Block</h4>
            </div>
            <form action="{{ route('admin.nodes.view.allocation.removeBlock', $node->id) }}" method="POST">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <select class="form-control" name="ip">
                                @foreach($allocations as $allocation)
                                    <option value="{{ $allocation->ip }}">{{ $allocation->ip }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    {{{ csrf_field() }}}
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger">Delete Allocations</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('footer-scripts')
    @parent

    {{-- select2 --}}
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
    (function () {
        // IP select2 combo
        $('#ipSelect').select2({ width:'resolve' });
        $('#portsSelect').select2({ tags:true, tokenSeparators:[',',' '], width:'resolve', maximumSelectionLength:50000 });

        // sync IP hidden input
        function setIpField(val){$('#ipField').val(val||'');}
        $('#ipSelect').on('change', function(){
            var v=$(this).val();
            if(v==='__manual__'){ $('#manualIpBox').slideDown(); setIpField($('#manualIpInput').val().trim()); }
            else { $('#manualIpBox').slideUp(); setIpField(v); }
        });
        $('#manualIpInput').on('input',function(){ setIpField($(this).val().trim()); });

        // mode toggling
        function refreshMode(){
            var m=$('#mode').val();
            $('#autoBox').toggle(m==='auto');
            $('#manualBox').toggle(m==='manual');
            $('#customBox').toggle(m==='custom');
        }
        $('#mode').on('change', refreshMode); refreshMode();

        // fill ranges
        function fillRangeToPorts(end){
            if($('#mode').val()!=='manual'){ $('#mode').val('manual').trigger('change'); }
            var start=1100, batch=500, current=start; $('#portsSelect').prop('disabled',true);
            function addBatch(){
                var to=Math.min(current+batch-1,end), items=[];
                for(var p=current;p<=to;p++)items.push(p.toString());
                items.forEach(function(val){
                    if($('#portsSelect option[value="'+val+'"]').length===0){
                        var newOption=new Option(val,val,true,true);$('#portsSelect').append(newOption);
                    }else{ $('#portsSelect option[value="'+val+'"]').prop('selected',true); }
                });
                $('#portsSelect').trigger('change'); current=to+1;
                if(current<=end){ setTimeout(addBatch,30); } else { $('#portsSelect').prop('disabled',false); }
            }
            addBatch();
        }
        $('#fill3000').on('click',function(){ fillRangeToPorts(3000); });
        $('#fill4000').on('click',function(){ fillRangeToPorts(4000); });
        $('#fill5000').on('click',function(){ fillRangeToPorts(5000); });
        $('#fill6000').on('click',function(){ fillRangeToPorts(6000); });

        // client-side validation
        $('#allocationForm').on('submit', function(e){
            var ipVal=$('#ipField').val().trim();
            if(!ipVal){ e.preventDefault(); alert('Please select or type an IP address.'); return false; }
            var mode=$('#mode').val();
            if(mode==='manual'){ var ports=$('#portsSelect').val(); if(!ports||ports.length===0){ e.preventDefault(); alert('Please add one or more ports for Manual mode.'); return false; } }
            if(mode==='custom'){ var custom=$('#custom').val().trim(); if(!custom){ e.preventDefault(); alert('Please provide custom ports/ranges.'); return false; } }
            if(mode==='auto' && !$('#rangeSelect').val()){ e.preventDefault(); alert('Please choose an auto range.'); return false; }
            return true;
        });

    })();
    </script>
@endsection