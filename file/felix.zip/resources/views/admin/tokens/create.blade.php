@extends('layouts.admin')

@section('title', 'Create Token')

@section('content')
<div class="content">
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <div class="box box-primary">
        <div class="box-header with-border"><h3 class="box-title">Create Token</h3></div>

        <form method="POST" action="{{ route('tokens.store') }}">
          @csrf
          <div class="box-body">
            <div class="form-group">
              <label>Duration value</label>
              <input type="number" name="duration_value" class="form-control" min="1" placeholder="e.g. 5">
            </div>
            <div class="form-group">
              <label>Duration type</label>
              <select name="duration_type" class="form-control">
                <option value="seconds">Seconds</option>
                <option value="minutes">Minutes</option>
                <option value="hours">Hours</option>
                <option value="days">Days</option>
                <option value="months">Months</option>
                <option value="years">Years</option>
                <option value="permanent">Permanent</option>
              </select>
            </div>
          </div>

          <div class="box-footer">
            <button class="btn btn-primary">Create Token</button>
            <a href="{{ route('tokens.index') }}" class="btn btn-default pull-right">Back</a>
          </div>
        </form>

      </div>
    </div>
  </div>
</div>
@endsection