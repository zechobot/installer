@extends('layouts.admin')

@section('content')
<div class="container">
    <h1>Redeem Token</h1>

    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <form method="POST" action="{{ route('admin.redeem') }}">
        @csrf

        <div class="form-group">
            <label>Token</label>
            <input type="text" name="token" class="form-control" required>
        </div>

        <button class="btn btn-primary mt-3">Redeem</button>
    </form>
</div>
@endsection