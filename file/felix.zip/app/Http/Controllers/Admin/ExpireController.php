<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\User;
use Pterodactyl\Models\GiftToken;
use Illuminate\Http\Request;
use Carbon\Carbon;

class ExpireController extends Controller
{
    public function index()
    {
        return view('admin.expire.index', [
            'users' => User::all(),
            'tokens' => GiftToken::latest()->get(),
        ]);
    }

    public function updateUser(Request $r, $id)
    {
        $user = User::findOrFail($id);

        // convert expires_at to Carbon if set
        $user->expires_at = $r->expires_at
            ? Carbon::parse($r->expires_at)
            : null;

        $user->is_permanent = $r->is_permanent ? true : false;

        $user->save();

        return back()->with('success', 'Updated');
    }

    public function createToken(Request $r)
    {
        GiftToken::create([
            'token' => strtoupper(bin2hex(random_bytes(5))),
            'days'  => $r->days,
        ]);

        return back()->with('success', 'Token created');
    }
}