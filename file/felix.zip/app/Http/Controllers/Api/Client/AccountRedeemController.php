<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Carbon\Carbon;
use Pterodactyl\Models\GiftToken;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;

class AccountRedeemController extends ClientApiController
{
    public function redeem(Request $request): JsonResponse
    {
        $request->validate([
            'token' => 'required|string',
        ]);

        $user = $request->user();

        /** @var GiftToken|null $gift */
        $gift = GiftToken::where('token', $request->token)->first();

        if (!$gift) {
            return response()->json([
                'errors' => [
                    ['detail' => 'Invalid or expired token.'],
                ],
            ], 422);
        }

        // 🔒 PERMANENT
        if ((int) $gift->days === 0) {
            $user->is_permanent = true;
            $user->expires_at = null;
        } else {
            $base = $user->expires_at
                ? Carbon::parse($user->expires_at)
                : Carbon::now();

            $user->expires_at = $base->addDays($gift->days);
        }

        $user->save();

        // 🔥 TOKEN SEKALI PAKAI
        $gift->delete();

        return response()->json([
            'success' => true,
            'message' => 'Token redeemed successfully.',
        ]);
    }
}