<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Model;

class GiftToken extends Model
{
    protected $fillable = ['token', 'days', 'used'];
}