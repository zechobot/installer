<?php

namespace Pterodactyl\Http\Controllers\Api\Application\Users;

use Pterodactyl\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Spatie\QueryBuilder\QueryBuilder;
use Pterodactyl\Services\Users\UserUpdateService;
use Pterodactyl\Services\Users\UserCreationService;
use Pterodactyl\Services\Users\UserDeletionService;
use Pterodactyl\Transformers\Api\Application\UserTransformer;
use Pterodactyl\Http\Requests\Api\Application\Users\GetUsersRequest;
use Pterodactyl\Http\Requests\Api\Application\Users\StoreUserRequest;
use Pterodactyl\Http\Requests\Api\Application\Users\DeleteUserRequest;
use Pterodactyl\Http\Requests\Api\Application\Users\UpdateUserRequest;
use Pterodactyl\Http\Controllers\Api\Application\ApplicationApiController;

class UserController extends ApplicationApiController
{
    /**
     * UserController constructor.
     */
    public function __construct(
        private UserCreationService $creationService,
        private UserDeletionService $deletionService,
        private UserUpdateService $updateService
    ) {
        parent::__construct();
    }

    /**
     * Handle request to list all users on the panel. Returns a JSON-API representation
     * of a collection of users including any defined relations passed in
     * the request.
     */
    public function index(GetUsersRequest $request): array
    {
        $users = QueryBuilder::for(User::query())
            ->allowedFilters(['email', 'uuid', 'username', 'external_id'])
            ->allowedSorts(['id', 'uuid'])
            ->paginate($request->query('per_page') ?? 50);

        return $this->fractal->collection($users)
            ->transformWith($this->getTransformer(UserTransformer::class))
            ->toArray();
    }

    /**
     * Handle a request to view a single user. Includes any relations that
     * were defined in the request.
     */
    public function view(GetUsersRequest $request, User $user): array
    {
        return $this->fractal->item($user)
            ->transformWith($this->getTransformer(UserTransformer::class))
            ->toArray();
    }

    /**
     * Update an existing user on the system and return the response. Returns the
     * updated user model response on success. Supports handling of token revocation
     * errors when switching a user from an admin to a normal user.
     *
     * Revocation errors are returned under the 'revocation_errors' key in the response
     * meta. If there are no errors this is an empty array.
     *
     * @throws \Pterodactyl\Exceptions\Model\DataValidationException
     * @throws \Pterodactyl\Exceptions\Repository\RecordNotFoundException
     */
    public function update(UpdateUserRequest $request, User $user): array|JsonResponse
    {
        $actor = $request->user();
        $actorRole = $actor->root_admin ? 'Admin' : 'User';
        $targetRole = $user->root_admin ? 'Admin' : 'User';
        
        // =====================================================
        // LOG ACTION ATTEMPT
        // =====================================================
        //Log::info("{$actorRole} ID {$actor->id} ({$actor->username}) mencoba mengedit {$targetRole} ID {$user->id} ({$user->username})");

        // =====================================================
        // 1. ADMIN UTAMA (ID 1) TIDAK BOLEH DIEDIT SELAIN OLEH DIRI SENDIRI
        // =====================================================
        if (intval($user->id) === 1 && intval($actor->id) !== 1) {
            //\Log::warning("{$actorRole} ID {$actor->id} ditolak mengedit Admin Utama ID 1");
            return response()->json([
                'errors' => [
                    [
                        'status' => '403',
                        'code' => 'AccessDenied',
                        'detail' => "{$actorRole} tidak dapat mengedit Admin Utama. Hanya Admin Utama yang boleh mengedit akunnya sendiri.",
                        'meta' => [
                            'actor_role' => $actorRole,
                            'target_role' => 'Admin Utama',
                            'action' => 'edit'
                        ]
                    ]
                ]
            ], 403);
        }

        // =====================================================
        // 2. CEK PERMISSION UNTUK EDIT USER LAIN
        // =====================================================
        if (intval($actor->id) !== intval($user->id)) {
            // Jika actor adalah admin
            if ($actor->root_admin) {
                // Jika actor BUKAN admin utama (ID 1)
                if (intval($actor->id) !== 1) {
                    $perms = $actor->protex_permissions ?? [];
                    if (!is_array($perms)) {
                        $perms = (array) $perms;
                    }

                    // Cek apakah punya permission edit_account
                    if (empty($perms['edit_account'])) {
                       // \Log::warning("{$actorRole} ID {$actor->id} tidak memiliki izin edit_account untuk mengedit {$targetRole} ID {$user->id}");
                        return response()->json([
                            'errors' => [
                                [
                                    'status' => '403',
                                    'code' => 'AccessDenied',
                                    'detail' => "{$actorRole} tidak memiliki izin untuk mengedit {$targetRole} lain.",
                                    'meta' => [
                                        'actor_role' => $actorRole,
                                        'target_role' => $targetRole,
                                        'action' => 'edit'
                                    ]
                                ]
                            ]
                        ], 403);
                    }
                }
                // Admin ID 1 selalu bisa edit
            } else {
                // Non-admin mencoba edit user lain
             //   \Log::warning("User ID {$actor->id} mencoba mengedit {$targetRole} ID {$user->id}");
                return response()->json([
                    'errors' => [
                        [
                            'status' => '403',
                            'code' => 'AccessDenied',
                            'detail' => "User tidak memiliki izin untuk mengedit {$targetRole} lain.",
                            'meta' => [
                                'actor_role' => 'User',
                                'target_role' => $targetRole,
                                'action' => 'edit'
                            ]
                        ]
                    ]
                ], 403);
            }
        }

       // \Log::info("{$actorRole} ID {$actor->id} berhasil mengedit {$targetRole} ID {$user->id}");
        
        $this->updateService->setUserLevel(User::USER_LEVEL_ADMIN);
        $user = $this->updateService->handle($user, $request->validated());

        $response = $this->fractal->item($user)
            ->transformWith($this->getTransformer(UserTransformer::class));

        return $response->toArray();
    }

    /**
     * Store a new user on the system. Returns the created user and an HTTP/201
     * header on successful creation.
     *
     * @throws \Exception
     * @throws \Pterodactyl\Exceptions\Model\DataValidationException
     */
    public function store(StoreUserRequest $request): JsonResponse
    {
        $actor = $request->user();
        $actorRole = $actor->root_admin ? 'Admin' : 'User';
        $isCreatingAdmin = !empty($request->input('root_admin', false));
        $targetRole = $isCreatingAdmin ? 'Admin' : 'User';
        
        // =====================================================
        // LOG ACTION ATTEMPT
        // =====================================================
        //\Log::info("{$actorRole} ID {$actor->id} ({$actor->username}) mencoba membuat {$targetRole} baru");

        // =====================================================
        // 1. CEK PERMISSION UNTUK CREATE USER
        // =====================================================
        if ($actor->root_admin) {
            // Jika actor BUKAN admin utama (ID 1)
            if (intval($actor->id) !== 1) {
                $perms = $actor->protex_permissions ?? [];
                if (!is_array($perms)) {
                    $perms = (array) $perms;
                }

                // Cek apakah punya permission create_account
                if (empty($perms['create_account'])) {
                   // \Log::warning("{$actorRole} ID {$actor->id} tidak memiliki izin create_account untuk membuat {$targetRole}");
                    return response()->json([
                        'errors' => [
                            [
                                'status' => '403',
                                'code' => 'AccessDenied',
                                'detail' => "{$actorRole} tidak memiliki izin untuk membuat {$targetRole} baru.",
                                'meta' => [
                                    'actor_role' => $actorRole,
                                    'target_role' => $targetRole,
                                    'action' => 'create'
                                ]
                            ]
                        ]
                    ], 403);
                }
            }
            // Admin ID 1 selalu bisa create user
        } else {
            // Non-admin mencoba create user
          //  \Log::warning("User ID {$actor->id} mencoba membuat {$targetRole} baru");
            return response()->json([
                'errors' => [
                    [
                        'status' => '403',
                        'code' => 'AccessDenied',
                        'detail' => "User tidak memiliki izin untuk membuat {$targetRole} baru.",
                        'meta' => [
                            'actor_role' => 'User',
                            'target_role' => $targetRole,
                            'action' => 'create'
                        ]
                    ]
                ]
            ], 403);
        }

        // =====================================================
        // 2. CEK USERNAME/EMAIL SUDAH ADA
        // =====================================================
        $data = $request->validated();
        
        // Cek username sudah ada
        $existingUsername = User::where('username', $data['username'])->first();
        if ($existingUsername) {
          //  \Log::warning("{$actorRole} ID {$actor->id} gagal membuat {$targetRole}: Username '{$data['username']}' sudah digunakan");
            return response()->json([
                'errors' => [
                    [
                        'status' => '422',
                        'code' => 'ValidationError',
                        'detail' => 'Username sudah digunakan. Silakan pilih username lain.',
                        'meta' => [
                            'actor_role' => $actorRole,
                            'conflict_field' => 'username',
                            'conflict_value' => $data['username']
                        ],
                        'source' => [
                            'pointer' => '/data/attributes/username'
                        ]
                    ]
                ]
            ], 422);
        }

        // Cek email sudah ada
        $existingEmail = User::where('email', $data['email'])->first();
        if ($existingEmail) {
           // \Log::warning("{$actorRole} ID {$actor->id} gagal membuat {$targetRole}: Email '{$data['email']}' sudah digunakan");
            return response()->json([
                'errors' => [
                    [
                        'status' => '422',
                        'code' => 'ValidationError',
                        'detail' => 'Email sudah digunakan. Silakan gunakan email lain.',
                        'meta' => [
                            'actor_role' => $actorRole,
                            'conflict_field' => 'email',
                            'conflict_value' => $data['email']
                        ],
                        'source' => [
                            'pointer' => '/data/attributes/email'
                        ]
                    ]
                ]
            ], 422);
        }

        // =====================================================
        // 3. CREATE USER
        // =====================================================
        //  \Log::info("{$actorRole} ID {$actor->id} berhasil membuat {$targetRole} baru: {$data['username']} ({$data['email']})");
        $user = $this->creationService->handle($data);

        return $this->fractal->item($user)
            ->transformWith($this->getTransformer(UserTransformer::class))
            ->addMeta([
                'resource' => route('api.application.users.view', [
                    'user' => $user->id,
                ]),
            ])
            ->respond(201);
    }

    /**
     * Handle a request to delete a user from the Panel. Returns a HTTP/204 response
     * on successful deletion.
     *
     * @throws \Pterodactyl\Exceptions\DisplayException
     */
    public function delete(DeleteUserRequest $request, User $user): JsonResponse
    {
        $actor = $request->user();
        $actorRole = $actor->root_admin ? 'Admin' : 'User';
        $targetRole = $user->root_admin ? 'Admin' : 'User';
        
        // =====================================================
        // LOG ACTION ATTEMPT
        // =====================================================
        // \Log::info("{$actorRole} ID {$actor->id} ({$actor->username}) mencoba menghapus {$targetRole} ID {$user->id} ({$user->username})");

        // =====================================================
        // 1. CEK JIKA MENCOBA HAPUS DIRI SENDIRI
        // =====================================================
        if (intval($actor->id) === intval($user->id)) {
          //  \Log::warning("{$actorRole} ID {$actor->id} mencoba menghapus akun sendiri");
            return response()->json([
                'errors' => [
                    [
                        'status' => '403',
                        'code' => 'AccessDenied',
                        'detail' => "{$actorRole} tidak dapat menghapus akun sendiri.",
                        'meta' => [
                            'actor_role' => $actorRole,
                            'action' => 'delete_self'
                        ]
                    ]
                ]
            ], 403);
        }

        // =====================================================
        // 2. ADMIN UTAMA (ID 1) TIDAK BOLEH DIHAPUS
        // =====================================================
        if (intval($user->id) === 1) {
            // \Log::warning("{$actorRole} ID {$actor->id} mencoba menghapus Admin Utama ID 1");
            return response()->json([
                'errors' => [
                    [
                        'status' => '403',
                        'code' => 'AccessDenied',
                        'detail' => "{$actorRole} tidak dapat menghapus Admin Utama.",
                        'meta' => [
                            'actor_role' => $actorRole,
                            'target_role' => 'Admin Utama',
                            'action' => 'delete'
                        ]
                    ]
                ]
            ], 403);
        }

        // =====================================================
        // 3. CEK PERMISSION UNTUK HAPUS USER LAIN
        // =====================================================
        if ($actor->root_admin) {
            // Jika actor BUKAN admin utama (ID 1)
            if (intval($actor->id) !== 1) {
                $perms = $actor->protex_permissions ?? [];
                if (!is_array($perms)) {
                    $perms = (array) $perms;
                }

                // Cek apakah punya permission edit_account (untuk hapus)
                if (empty($perms['edit_account'])) {
                  //  \Log::warning("{$actorRole} ID {$actor->id} tidak memiliki izin edit_account untuk menghapus {$targetRole} ID {$user->id}");
                    return response()->json([
                        'errors' => [
                            [
                                'status' => '403',
                                'code' => 'AccessDenied',
                                'detail' => "{$actorRole} tidak memiliki izin untuk menghapus {$targetRole} lain.",
                                'meta' => [
                                    'actor_role' => $actorRole,
                                    'target_role' => $targetRole,
                                    'action' => 'delete'
                                ]
                            ]
                        ]
                    ], 403);
                }
            }
            // Admin ID 1 selalu bisa hapus
        } else {
            // Non-admin mencoba hapus user
            //  \Log::warning("User ID {$actor->id} mencoba menghapus {$targetRole} ID {$user->id}");
            return response()->json([
                'errors' => [
                    [
                        'status' => '403',
                        'code' => 'AccessDenied',
                        'detail' => "User tidak memiliki izin untuk menghapus {$targetRole} lain.",
                        'meta' => [
                            'actor_role' => 'User',
                            'target_role' => $targetRole,
                            'action' => 'delete'
                        ]
                    ]
                ]
            ], 403);
        }

       // \Log::info("{$actorRole} ID {$actor->id} berhasil menghapus {$targetRole} ID {$user->id}");
        $this->deletionService->handle($user);

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }
}