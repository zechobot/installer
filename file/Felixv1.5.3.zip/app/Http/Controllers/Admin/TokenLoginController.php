<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Pterodactyl\Models\Token;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;

class TokenLoginController extends Controller
{
    public function form()
    {
        return view('admin.token.form');
    }

    public function verify(Request $r)
    {
        $r->validate(['token' => 'required|string']);

        $token = Token::where('token', $r->token)->first();

        if (!$token) {
            return back()->with('error', 'Token tidak ditemukan atau salah.');
        }

        // if already activated and expired => delete and error
        if ($token->isActivated() && $token->isExpired()) {
            $token->delete();
            return back()->with('error', 'Token sudah expired.');
        }

        // single device check (used_by) — we consider session id
        $clientId = $r->session()->getId();

        if ($token->used_by && $token->used_by !== $clientId) {
            return back()->with('error', 'Token sudah dipakai perangkat/session lain.');
        }

        // activate if not yet activated
        if (!$token->isActivated()) {
            $token->activated_at = now();

            if (!$token->isPermanent() && $token->duration_seconds !== null) {
                $token->expires_at = now()->addSeconds($token->duration_seconds);
            } else {
                $token->expires_at = null; // permanent
            }

            $token->is_used = true;
        }

        // mark used_by as session id
        $token->used_by = $clientId;
        $token->save();

        // store session key to allow access
        $r->session()->put('token_sn', $token->sn);
        $r->session()->put('token_value', $token->token);

        return redirect()->intended(route('admin.protex.index'))->with('success', 'Token valid, akses diberikan.');
    }

    // optional logout from token session
    public function logout(Request $r)
    {
        $r->session()->forget(['token_sn', 'token_value']);
        return redirect()->route('token.form')->with('success', 'Anda keluar dari sesi token.');
    }
}