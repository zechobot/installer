<?php

namespace Pterodactyl\Http\Controllers\Admin\Nodes;

use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Node;
use Pterodactyl\Models\Allocation;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class AllocationController extends Controller
{
    public function store(Request $request, $nodeId)
    {
        $node = Node::findOrFail($nodeId);

        $request->validate([
            'ip' => 'required|string',
            'mode' => 'required|in:auto,manual,custom',
            'alias' => 'nullable|string|max:191',
            'ports.*' => 'nullable|integer|min:1024|max:65535',
            'custom' => 'nullable|string',
            'range' => 'nullable|in:1,2,3,4',
        ]);

        $ip = $request->input('ip');
        $alias = $request->input('alias');
        $mode = $request->input('mode');

        $insertRows = [];

        // helper parse custom
        $parsePorts = function($input) {
            $ports = [];
            $input = trim($input);
            if ($input === '') return [];
            $parts = preg_split('/[,\s]+/', $input);
            foreach ($parts as $part) {
                if (strpos($part, '-') !== false) {
                    [$s, $e] = array_map('intval', explode('-', $part,2));
                    if ($s>$e) [$s,$e]=[$e,$s];
                    $s = max(1024, $s); $e = min(65535,$e);
                    for($p=$s;$p<=$e;$p++) $ports[]=$p;
                } else {
                    $val=intval($part);
                    if($val>=1024 && $val<=65535) $ports[]=$val;
                }
            }
            return array_unique($ports);
        };

        try {
            // get existing ports for this ip
            $existing = Allocation::where('node_id',$node->id)->where('ip',$ip)->pluck('port')->toArray();
            $existing = array_map('intval', $existing);

            if($mode==='auto'){
                // preset ranges
                $ranges = [
                    1 => [1024, 3000],
                    2 => [1024, 4000],
                    3 => [1024, 5000],
                    4 => [1024, 6000],
                ];
                $rangeId = $request->input('range',3);
                [$start,$end] = $ranges[$rangeId] ?? [1024,5000];

                for($p=$start;$p<=$end;$p++){
                    if(!in_array($p,$existing)){
                        $insertRows[]=[
                            'node_id'=>$node->id,
                            'ip'=>$ip,
                            'port'=>$p,
                            'ip_alias'=>$alias,
                            'created_at'=>now(),
                            'updated_at'=>now(),
                        ];
                    }
                }
            } elseif($mode==='manual'){
                $ports = $request->input('ports',[]);
                $ports = array_filter(array_map('intval',$ports), fn($v)=>$v>=1024 && $v<=65535);
                if(empty($ports)) return redirect()->back()->withErrors(['ports'=>'No valid ports provided.']);

                foreach($ports as $p){
                    if(!in_array($p,$existing)){
                        $insertRows[]=[
                            'node_id'=>$node->id,
                            'ip'=>$ip,
                            'port'=>$p,
                            'ip_alias'=>$alias,
                            'created_at'=>now(),
                            'updated_at'=>now(),
                        ];
                    }
                }
            } else { // custom
                $custom = $request->input('custom','');
                $ports = $parsePorts($custom);
                if(empty($ports)) return redirect()->back()->withErrors(['custom'=>'No valid ports parsed.']);

                foreach($ports as $p){
                    if(!in_array($p,$existing)){
                        $insertRows[]=[
                            'node_id'=>$node->id,
                            'ip'=>$ip,
                            'port'=>$p,
                            'ip_alias'=>$alias,
                            'created_at'=>now(),
                            'updated_at'=>now(),
                        ];
                    }
                }
            }

            if(count($insertRows)===0){
                return redirect()->back()->with('warning','No new allocations to insert (all ports already exist).');
            }

            // batch insert
            DB::beginTransaction();
            foreach(array_chunk($insertRows,500) as $chunk){
                DB::table((new Allocation)->getTable())->insert($chunk);
            }
            DB::commit();

            return redirect()->back()->with('success','Allocations added: '.count($insertRows));

        } catch (\Exception $ex){
            DB::rollBack();
            Log::error('Allocation store failed: '.$ex->getMessage(), ['exception'=>$ex]);
            return redirect()->back()->withErrors(['error'=>'Failed to create allocations. See logs.']);
        }
    }
}