<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Pterodactyl\Models\Token;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Validation\Rule;

class TokenController extends Controller
{
    // list tokens
    public function index()
    {
        $tokens = Token::orderByDesc('id')->get();
        return view('admin.tokens.index', compact('tokens'));
    }

    // show create form
    public function create()
    {
        return view('admin.tokens.create');
    }

    // store new token
    public function store(Request $r)
    {
        $r->validate([
            'duration_value' => 'nullable|integer|min:1',
            'duration_type'  => ['required', Rule::in(['seconds','minutes','hours','days','months','years','permanent'])],
        ]);

        // compute duration_seconds or null for permanent
        $durationSeconds = null;
        if ($r->duration_type !== 'permanent') {
            $val = intval($r->duration_value ?? 1);
            $durationSeconds = match($r->duration_type) {
                'seconds' => $val,
                'minutes' => $val * 60,
                'hours'   => $val * 3600,
                'days'    => $val * 86400,
                'months'  => $val * 2592000,   // approx 30d
                'years'   => $val * 31536000,  // approx 365d
                default => $val,
            };
        }

        $created = Token::create([
            'sn' => strtoupper(Str::random(10)),
            'token' => Str::random(64),
            'duration_seconds' => $durationSeconds,
            'activated_at' => null,
            'expires_at' => null,
            'is_used' => false,
        ]);

        // redirect back and show created token once
        return redirect()->route('tokens.index')->with([
            'new_token' => $created->token,
            'new_sn' => $created->sn,
        ]);
    }

    // edit form
    public function edit($id)
    {
        $t = Token::findOrFail($id);
        return view('admin.tokens.edit', ['token' => $t]);
    }

    // update token duration (if already activated, recompute expires_at relative to activated_at)
    public function update(Request $r, $id)
    {
        $r->validate([
            'duration_value' => 'nullable|integer|min:1',
            'duration_type'  => ['required', Rule::in(['seconds','minutes','hours','days','months','years','permanent'])],
        ]);

        $token = Token::findOrFail($id);

        $durationSeconds = null;
        if ($r->duration_type !== 'permanent') {
            $val = intval($r->duration_value ?? 1);
            $durationSeconds = match($r->duration_type) {
                'seconds' => $val,
                'minutes' => $val * 60,
                'hours'   => $val * 3600,
                'days'    => $val * 86400,
                'months'  => $val * 2592000,
                'years'   => $val * 31536000,
                default => $val,
            };
        }

        $token->duration_seconds = $durationSeconds;

        if ($token->isActivated()) {
            // recompute expires_at relative to activated_at
            if ($durationSeconds === null) {
                $token->expires_at = null;
            } else {
                $token->expires_at = $token->activated_at->copy()->addSeconds($durationSeconds);
            }
        } else {
            $token->expires_at = null;
            $token->activated_at = null;
            $token->is_used = false;
            $token->used_by = null;
        }

        $token->save();

        return redirect()->route('tokens.index')->with('success', 'Token updated.');
    }

    // delete token
    public function destroy($id)
    {
        $token = Token::findOrFail($id);
        $token->delete();
        return back()->with('success', 'Token deleted.');
    }

    // export CSV (optional)
    public function exportCsv()
    {
        $tokens = Token::orderByDesc('id')->get();
        $filename = 'tokens_export_'.now()->format('Ymd_His').'.csv';
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ];
        $columns = ['id','sn','token','duration_seconds','activated_at','expires_at','is_used','used_by','created_at'];

        $callback = function() use ($tokens, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);
            foreach ($tokens as $t) {
                fputcsv($file, [
                    $t->id,
                    $t->sn,
                    $t->token,
                    $t->duration_seconds ?? 'PERMANENT',
                    $t->activated_at?->toDateTimeString() ?? '',
                    $t->expires_at?->toDateTimeString() ?? '',
                    $t->is_used ? '1' : '0',
                    $t->used_by ?? '',
                    $t->created_at->toDateTimeString(),
                ]);
            }
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}