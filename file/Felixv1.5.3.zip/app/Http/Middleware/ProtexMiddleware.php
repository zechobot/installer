<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Models\Server;
use Pterodactyl\Models;
class ProtexMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param string $permission  e.g. "command", "file_download", "view"
     */
    public function handle(Request $request, Closure $next, string $permission)
    {
        $user = Auth::user();
        
        if (!$user) {
            return $this->deny($request, 'User tidak terautentikasi.');
        }

        // SUPER ADMIN (ID 1) BEBAS APA SAJA
        if (intval($user->id) === 1) {
            return $next($request);
        }
        
       $targetUser = $request->route('user') ?? null;

       // Normalisasi ID → object model
      if ($targetUser && !is_object($targetUser)) {
      $targetUser = Models\User::find($targetUser);
       }
        if ($targetUser instanceof User) {
                    if ($user->root_admin) {

                // ❌ Admin biasa tidak boleh edit admin lain
                if (
                    $targetUser->root_admin &&
                    (int) $targetUser->id !== (int) $user->id
                ) {
                    $perms = (array) ($user->protex_permissions ?? []);

                    if (empty($perms['edit_account'])) {
                        abort(
                            403,
                            'Anda tidak diizinkan mengedit admin lain. Izin ini hanya dapat diberikan oleh Admin Utama.'
                        );
                    }
                }
            }
        }

       if ($targetUser) {

        // 1. Admin biasa tidak boleh edit admin utama
    if (intval($targetUser->id) === 1) {
        abort(403, "Admin utama tidak dapat diedit.");
    }

    // 2. Admin biasa tidak boleh edit dirinya sendiri
    if (intval($targetUser->id) === intval($user->id)) {

        $perms = $user->protex_permissions ?? [];
        if (!is_array($perms)) {
            $perms = (array)$perms;
        }

        // Jika TIDAK ada izin self_edit_access → BLOK
        if (empty($perms['self_edit_access'])) {
            abort(403,
                "Anda tidak dapat mengedit akses Anda sendiri. Hanya Admin Utama yang boleh mengizinkan ini."
            );
        }
    }
}
        // Ambil server jika route memiliki parameter 'server'
        $server = $request->route('server') ?? null;

        // Normalisasi jika parameter berupa ID
        if ($server && ! is_object($server)) {
            $server = Server::find($server);
        }

        // =============================================================
        //           ROUTE TANPA SERVER  →   MODE GLOBAL ADMIN
        // =============================================================
        if (!$server) {
            // root_admin wajib punya protex permission tertentu
            $perms = $user->protex_permissions ?? [];

            if (!is_array($perms)) {
                $perms = (array) $perms;
            }

            // Jika admin non-root
            
            if (!intval($user->root_admin)) {
               abort(403, 'Hanya admin yang dapat mengakses menu ini.');
            }

            // Cek izin spesifik
            if (empty($perms[$permission])) {
                abort(403, "Akses ditolak. Anda Tidak dapat mengakses menu ini.");
            }

            return $next($request);
        }


        // =============================================================
        //   ROUTE DENGAN SERVER →  MODE SERVER OWNER / ADMIN PROTEX
        // =============================================================

        // Jika server tidak ditemukan
        if (!$server) {
            return $this->deny($request, 'Server tidak ditemukan.');
        }

        // BLOK khusus → server milik admin utama id 1 tidak boleh dibuka
        if (intval($server->owner_id) === 1 && intval($user->id) !== 1) {
            return $this->deny($request, 'Server ini hanya dapat diakses oleh Admin Utama.');
        }

        // Bukan root_admin (USER BIASA)
        if (!intval($user->root_admin)) {
        return $next($request);   // ⬅ user biasa SKIP protex
        }
        if (!intval($user->root_admin)) {
            if (intval($server->owner_id) !== intval($user->id)) {
                return $this->deny($request, 'Hanya pemilik server yang boleh mengakses ini.');
            }
            return $next($request);
        }

        // ADMIN tetapi bukan owner server
        $perms = $user->protex_permissions ?? [];

        if (!is_array($perms)) {
            $perms = (array) $perms;
        }

        // Jika admin membuka server orang lain, cek izin foreign server
        if (intval($server->owner_id) !== intval($user->id)) {
            if (empty($perms['access_foreign_server'])) {
                return $this->deny($request, 'Admin tidak diizinkan membuka server milik orang lain.');
            }
        }

        // Cek izin fitur spesifik
        if (empty($perms[$permission])) {
         if (intval($server->owner_id) !== intval($user->id)) {
                return $this->deny($request, "Akses Tidak Diizinkan Oleh @Felix.");
            }
            return $next($request);
        }

        return $next($request);
    }

    private function deny(Request $request, string $message)
    {
        if ($request->expectsJson() || str_starts_with($request->path(), 'api/')) {
            return response()->json(['error' => $message], 403);
        }

        return response()->view('errors.403', ['message' => $message], 403);
    }
}