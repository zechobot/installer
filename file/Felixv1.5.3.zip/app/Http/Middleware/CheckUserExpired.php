<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Carbon\Carbon;

class CheckUserExpired
{
    public function handle($request, Closure $next)
    {
        $user = auth()->user();

        if ($user && $user->id != 1 && !$user->is_permanent) {
            if ($user->expires_at && Carbon::now()->greaterThan($user->expires_at)) {
                auth()->logout();
                return redirect('/')->withErrors([
                    'Your account has expired. Please enter a gift token.'
                ]);
            }
        }

        return $next($request);
    }
}