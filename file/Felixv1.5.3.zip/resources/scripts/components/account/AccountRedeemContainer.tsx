import React, { useState } from 'react';

export default function AccountRedeemContainer() {
    const [token, setToken] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const submit = async () => {
        setLoading(true);
        setError(null);

        try {
            const res = await fetch('/api/client/account/redeem', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify({ token }),
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data?.message || 'Redeem failed');
            }

            window.location.href = '/account';
        } catch (e: any) {
            setError(e.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="w-full max-w-md mx-auto mt-10">
            <h1 className="text-2xl font-semibold mb-4">Redeem Token</h1>

            {error && (
                <div className="bg-red-500 text-white p-2 rounded mb-3">
                    {error}
                </div>
            )}

            <input
                type="text"
                placeholder="Enter your token"
                className="w-full p-2 border rounded mb-3"
                value={token}
                onChange={(e) => setToken(e.target.value)}
            />

            <button
                onClick={submit}
                disabled={loading || !token}
                className="w-full bg-blue-600 text-white p-2 rounded disabled:opacity-50"
            >
                {loading ? 'Processing...' : 'Redeem'}
            </button>
        </div>
    );
}