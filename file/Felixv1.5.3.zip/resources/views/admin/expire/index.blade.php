@extends('layouts.admin')

@section('title', 'User Expired Manager')

@section('content')
<div class="container mt-4">

    {{-- SUCCESS / ERROR --}}
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if($errors->any())
        <div class="alert alert-danger">{{ $errors->first() }}</div>
    @endif

    <div class="row">

        {{-- ======================= USERS EXPIRATION ========================= --}}
        <div class="col-md-8">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">User Expiration</h3>
                </div>
                <div class="box-body table-responsive">

                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Expires</th>
                                <th>Permanent</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            @foreach($users as $u)
                                <tr>
                                    <td>{{ $u->username }}</td>
                                    <td>{{ $u->email }}</td>
                                    <td>
                                        @if($u->is_permanent)
                                            <span class="label label-success">Permanent</span>
                                        @elseif($u->expires_at)
                                            {{ $u->expires_at }}
                                        @else
                                            <span class="label label-warning">Not Set</span>
                                        @endif
                                    </td>
                                    <td>{{ $u->is_permanent ? 'Yes' : 'No' }}</td>
                                    <td>
                                        <button class="btn btn-xs btn-primary"
                                                data-toggle="modal"
                                                data-target="#editUser{{ $u->id }}">
                                            Edit
                                        </button>
                                    </td>
                                </tr>

                                {{-- EDIT USER MODAL --}}
                                <div class="modal fade" id="editUser{{ $u->id }}">
                                    <div class="modal-dialog">
                                        <form method="POST" action="/admin/expire/user/{{ $u->id }}">
                                            @csrf
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Edit Expiration — {{ $u->username }}</h4>
                                                </div>
                                                <div class="modal-body">

                                                    <label>Expires At</label>
                                                    <input type="datetime-local"
                                                           name="expires_at"
                                                           class="form-control"
                                                           value="{{ $u->expires_at ? $u->expires_at->format('Y-m-d\TH:i') : '' }}">

                                                    <label class="mt-3">
                                                        <input type="checkbox" name="is_permanent" {{ $u->is_permanent ? 'checked' : '' }}> Permanent User
                                                    </label>

                                                </div>
                                                <div class="modal-footer">
                                                    <button class="btn btn-default" data-dismiss="modal">Close</button>
                                                    <button class="btn btn-success">Save</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            @endforeach

                        </tbody>
                    </table>

                </div>
            </div>
        </div>


        {{-- ======================= TOKEN GENERATOR ========================= --}}
        <div class="col-md-4">
            <div class="box box-success">
                <div class="box-header with-border">
                    <h3 class="box-title">Gift Tokens</h3>
                </div>
                <div class="box-body">

                    <form action="/admin/expire/token/new" method="POST">
                        @csrf

                        <label>Days to Add</label>
                        <input type="number" name="days" class="form-control" value="30">

                        <button class="btn btn-success btn-block mt-3">Generate Token</button>
                    </form>

                    <hr>

                    <h4>Available Tokens</h4>

                    <ul class="list-group">
                        @foreach($tokens as $t)
                            <li class="list-group-item">
                                <strong>{{ $t->token }}</strong>
                                <span class="badge">{{ $t->days }} days</span>
                                @if($t->used)
                                    <span class="label label-danger pull-right">Used</span>
                                @else
                                    <span class="label label-success pull-right">Active</span>
                                @endif
                            </li>
                        @endforeach
                    </ul>

                </div>
            </div>
        </div>

    </div>
</div>
@endsection