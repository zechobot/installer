@extends('layouts.admin')

@section('title', 'Protex Admin')

@section('content')
<div class="card">
  <div class="card-body">
  
    {{-- HEADER PROTEX --}}
    <div style="font-size:14px; font-weight:bold; margin-bottom:10px; color:#4a4a4a;">
        Protex V1.0.0 — By Felix Hasgawa
    </div>
   <div class="mb-3">
    <li>
        <a href="{{ route('tokens.index') }}" class="btn btn-info">
            <i class="fa fa-key"></i> <span>TOKENS</span>
        </a>
    </li>
</div>
<div class="mb-3">
    <li>
        <a href="{{ route('admin.expire') }}" class="btn btn-primary">
            <i class="fa fa-warning"></i> <span>EXPAIRED</span>
        </a>
    </li>
</div>

    <h3>Daftar Admin Panel</h3>
    @if(session('status')) <div class="alert alert-success">{{ session('status') }}</div> @endif
    <table class="table">
      <thead>
        <tr><th>ID</th><th>Username</th><th>Email</th><th>Button</th></tr>
      </thead>
      <tbody>
        @foreach($admins as $a)
          <tr>
            <td>{{ $a->id }}</td>
            <td>{{ $a->username }}</td>
            <td>{{ $a->email }}</td>
            <td><a href="{{ route('admin.protex.edit', $a->id) }}" class="btn btn-sm btn-primary">Akses</a></td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>

{{-- COPYRIGHT FOOTER --}}
<div style="text-align:center; margin-top:30px; font-size:14px; opacity:0.8;">
    <a href="https://t.me/GlobalBotzXD" target="_blank" style="text-decoration:none; color:inherit;">
        <img src="https://cdn-icons-png.flaticon.com/512/2111/2111646.png" 
             style="width:18px; vertical-align:middle; margin-right:6px;">
        © @FelixHasgawa Tahun 2015 - 2025
    </a>
</div>
@endsection