<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('tokenslogin', function (Blueprint $table) {
            $table->id();
            $table->string('sn', 64)->unique();              // serial number
            $table->string('token', 128)->unique();          // token string
            $table->bigInteger('duration_seconds')->nullable(); // null = permanent
            $table->timestamp('activated_at')->nullable();   // set when first used
            $table->timestamp('expires_at')->nullable();     // set when activated
            $table->string('used_by')->nullable();           // session id or IP
            $table->boolean('is_used')->default(false);      // true after activation
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('tokenslogin');
    }
};