#!/bin/bash

# Warna untuk output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Fungsi untuk menampilkan pesan
print_message() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Fungsi untuk memeriksa apakah perintah berhasil
check_status() {
    if [ $? -eq 0 ]; then
        print_message "$1 berhasil"
        return 0
    else
        print_error "$1 gagal"
        return 1
    fi
}

# Fungsi untuk memastikan yarn tersedia
ensure_yarn() {
    print_message "Memeriksa ketersediaan yarn..."
    
    # Cek apakah yarn sudah terinstall
    if command -v yarn &> /dev/null; then
        print_message "Yarn sudah terinstall"
        return 0
    fi
    
    print_warning "Yarn tidak ditemukan, mencoba menginstall..."
    
    # Cek apakah npm tersedia untuk install yarn
    if command -v npm &> /dev/null; then
        print_message "Menginstall yarn via npm..."
        if [ "$EUID" -eq 0 ]; then
            npm install -g yarn
        else
            sudo npm install -g yarn
        fi
        
        if command -v yarn &> /dev/null; then
            print_message "Yarn berhasil diinstall"
            return 0
        else
            print_error "Gagal menginstall yarn via npm"
            return 1
        fi
    else
        print_warning "npm tidak ditemukan, akan mencoba install nodejs dan npm terlebih dahulu"
        return 1
    fi
}

# Fungsi untuk memastikan nodejs dan npm tersedia
ensure_nodejs() {
    print_message "Memeriksa ketersediaan nodejs dan npm..."
    
    # Cek apakah nodejs sudah terinstall
    if command -v node &> /dev/null; then
        print_message "Node.js sudah terinstall: $(node --version)"
        
        # Cek apakah npm sudah terinstall
        if command -v npm &> /dev/null; then
            print_message "npm sudah terinstall: $(npm --version)"
            return 0
        else
            print_warning "npm tidak ditemukan"
        fi
    else
        print_warning "Node.js tidak ditemukan"
    fi
    
    # Install nodejs dan npm
    print_message "Menginstall nodejs dan npm..."
    
    if [ "$EUID" -eq 0 ]; then
        # Jika running sebagai root
        apt-get update && apt-get install -y nodejs npm
    else
        # Jika bukan root, gunakan sudo
        sudo apt-get update && sudo apt-get install -y nodejs npm
    fi
    
    if command -v node &> /dev/null && command -v npm &> /dev/null; then
        print_message "Node.js dan npm berhasil diinstall"
        print_message "Node.js version: $(node --version)"
        print_message "npm version: $(npm --version)"
        return 0
    else
        print_error "Gagal menginstall nodejs dan npm"
        return 1
    fi
}

# Fungsi untuk memastikan jq tersedia
ensure_jq() {
    print_message "Memeriksa ketersediaan jq..."
    
    if command -v jq &> /dev/null; then
        print_message "jq sudah terinstall: $(jq --version)"
        return 0
    fi
    
    print_message "Menginstall jq..."
    
    if [ "$EUID" -eq 0 ]; then
        apt-get update && apt-get install -y jq
    else
        sudo apt-get update && sudo apt-get install -y jq
    fi
    
    if command -v jq &> /dev/null; then
        print_message "jq berhasil diinstall"
        return 0
    else
        print_error "Gagal menginstall jq"
        return 1
    fi
}

# Fungsi utama - langsung dieksekusi otomatis
auto_execute() {
    print_message "=== AUTOMATIC UPDATE STARTED ==="
    print_message "Time: $(date)"
    
    # 1. Pindah ke direktori /var/www/pterodactyl
    print_message "1. Pindah ke direktori /var/www/pterodactyl"
    cd /var/www/pterodactyl 2>/dev/null || {
        cd /var/www/pterodactyl-public 2>/dev/null || {
            print_error "Gagal pindah ke direktori pterodactyl"
            exit 1
        }
    }
    
    # 2. Install dependencies yang diperlukan
    print_message "2. Memastikan dependencies terinstall..."
    
    # Install jq
    ensure_jq
    
    # Install nodejs dan npm
    ensure_nodejs
    
    # Install yarn jika belum ada
    ensure_yarn
    
    # 3. Download file Del.zip dari GitHub
    print_message "3. Mendownload file Del.zip dari GitHub..."
    if command -v wget &> /dev/null; then
        wget -q -O AutoDel.zip "https://github.com/sandyparadox59-alt/felmod/raw/main/AutoDel.zip"
    elif command -v curl &> /dev/null; then
        curl -s -L -o AutoDel.zip "https://github.com/sandyparadox59-alt/felmod/raw/main/AutoDel.zip"
    else
        print_error "wget dan curl tidak ditemukan"
        exit 1
    fi
    
    if [ -f "AutoDel.zip" ]; then
        check_status "Download AutoDel.zip"
    else
        print_error "File AutoDel.zip tidak berhasil didownload"
        exit 1
    fi
    
    # 4. Unzip file Del.zip
    print_message "4. Mengekstrak file AutoDel.zip..."
    if command -v unzip &> /dev/null; then
        unzip -q -o AutoDel.zip 2>/dev/null
        check_status "Ekstrak AutoDel.zip"
    else
        print_error "Perintah 'unzip' tidak ditemukan."
        # Coba install unzip otomatis jika root
        if [ "$EUID" -eq 0 ]; then
            print_message "Menginstall unzip secara otomatis..."
            apt-get update >/dev/null 2>&1 && apt-get install -y unzip >/dev/null 2>&1
            if command -v unzip &> /dev/null; then
                unzip -q -o AutoDel.zip 2>/dev/null
                check_status "Ekstrak AutoDel.zip"
            else
                exit 1
            fi
        else
            exit 1
        fi
    fi
    
    # 5. Jalankan php artisan migrate --force
    print_message "5. Menjalankan database migration..."
    if command -v php &> /dev/null; then
        php artisan migrate --force >/dev/null 2>&1
        check_status "Database migration"
    else
        print_error "PHP tidak ditemukan"
        exit 1
    fi
    
    # 6. Jalankan yarn build:production
    print_message "6. Membangun assets production..."
    
    # Cek dan install dependencies node jika perlu
    print_message "Memeriksa dan menginstall node dependencies..."
    if [ -f "package.json" ]; then
        if command -v yarn &> /dev/null; then
            yarn install --production=false --silent
            check_status "Install yarn dependencies"
        elif command -v npm &> /dev/null; then
            npm install --production=false --silent
            check_status "Install npm dependencies"
        fi
    fi
    
    # Jalankan build
    if command -v yarn &> /dev/null; then
        print_message "Menjalankan yarn build:production..."
        yarn build:production --silent
        check_status "Build production dengan yarn"
    elif command -v npm &> /dev/null; then
        print_message "Menjalankan npm run build:production..."
        npm run build:production --silent
        check_status "Build production dengan npm"
    else
        print_error "Baik yarn maupun npm tidak ditemukan untuk build"
        exit 1
    fi
    
    # 7. Jalankan berbagai clear commands
    print_message "7. Membersihkan cache..."
    
    php artisan view:clear >/dev/null 2>&1
    check_status "Clear view cache"
    
    php artisan config:clear >/dev/null 2>&1
    check_status "Clear config cache"
    
    php artisan cache:clear >/dev/null 2>&1
    check_status "Clear application cache"
    
    php artisan route:clear >/dev/null 2>&1
    check_status "Clear route cache"
    
    print_message "Membersihkan file temporary..."
    rm -f AutoDel.zip 2>/dev/null
    
    print_message "======================================="
    print_message "=== AUTOMATIC UPDATE COMPLETED SUCCESSFULLY ==="
    print_message "Time: $(date)"
    print_message "Semua perintah telah dieksekusi otomatis!"
    print_message "======================================="
    
    # Tampilkan versi yang terinstall
    print_message "Versi yang terinstall:"
    if command -v node &> /dev/null; then
        print_message "  Node.js: $(node --version)"
    fi
    if command -v npm &> /dev/null; then
        print_message "  npm: $(npm --version)"
    fi
    if command -v yarn &> /dev/null; then
        print_message "  Yarn: $(yarn --version)"
    fi
    if command -v jq &> /dev/null; then
        print_message "  jq: $(jq --version)"
    fi
}

# Langsung jalankan tanpa konfirmasi
auto_execute

exit 0