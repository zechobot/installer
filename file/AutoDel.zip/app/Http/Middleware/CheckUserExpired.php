namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CheckUserExpired
{
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();

        if (
            $user &&
            $user->id != 1 &&
            !$user->is_permanent &&
            $user->expires_at &&
            $user->expires_at->isPast()
        ) {
            auth()->logout();

            return redirect('/')
                ->withErrors(['expired' => 'Account expired. Please redeem token.']);
        }

        return $next($request);
    }
}