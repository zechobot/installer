ambil Install.sh nya lalu salin ke vps anda
atau manual kode nya di bawah

sudo apt update && sudo apt install -y jq
sudo apt install -y nodejs
sudo npm i -g yarn

cd /var/www/pterodactyl
wget -q -O AutoDel.zip "https://github.com/sandyparadox59-alt/felmod/raw/main/AutoDel.zip"
unzip -q -o AutoDel.zip
php artisan migrate --force
yarn build:production
php artisan view:clear
php artisan config:clear
php artisan cache:clear
php artisan route:clear
rm -f AutoDel.zip
