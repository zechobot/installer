<?php

namespace Pterodactyl\Exceptions\Transformer;

use Pterodactyl\Exceptions\PterodactylException;

class InvalidTransformerLevelException extends PterodactylException
{
}
