<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redis;

class UserNotificationController extends Controller
{
    /**
     * Get user notifications (API endpoint untuk React)
     */
    public function index(Request $request): JsonResponse
    {
        $user = Auth::user();
        $notifications = [];
        
        if (!$user) {
            return response()->json(['notifications' => []]);
        }
        
        // Skip untuk admin
        if ($user->id == 1 || $user->root_admin || $user->is_permanent) {
            return response()->json(['notifications' => []]);
        }
        
        // 1. Cek dari Redis
        $redisKey = "user_notification:{$user->id}";
        $redisNotification = Redis::get($redisKey);
        
        if ($redisNotification) {
            $notification = json_decode($redisNotification, true);
            
            // Pastikan notifikasi masih valid (belum expired)
            if (isset($notification['timestamp']) && 
                (now()->timestamp - $notification['timestamp']) < 7200) {
                $notifications[] = $notification;
            } else {
                // Hapus jika expired
                Redis::del($redisKey);
            }
        }
        
        // 2. Cek dari session (fallback)
        if ($request->session()->has('user_notification')) {
            $sessionNotification = $request->session()->get('user_notification');
            if (!in_array($sessionNotification, $notifications)) {
                $notifications[] = $sessionNotification;
            }
        }
        
        // 3. Generate notifikasi real-time dari database
        if (!$user->is_permanent && $user->expires_at && !$user->expires_at->isPast()) {
            $minutesLeft = $user->expires_at->diffInMinutes(now());
            
            if ($minutesLeft <= 120) {
                $notification = [
                    'type' => 'expiring_soon',
                    'message' => $minutesLeft <= 60 
                        ? "Your account will expire in {$minutesLeft} minutes!" 
                        : "Your account will expire in " . ceil($minutesLeft / 60) . " hours!",
                    'expires_at' => $user->expires_at->toISOString(),
                    'minutes_left' => $minutesLeft,
                    'show_countdown' => true,
                    'auto_close' => 5,
                    'show_close_button' => true,
                    'timestamp' => now()->timestamp
                ];
                
                // Simpan ke Redis
                Redis::setex($redisKey, 7200, json_encode($notification));
                $notifications[] = $notification;
            }
        }
        
        return response()->json([
            'notifications' => $notifications,
            'count' => count($notifications)
        ]);
    }
    
    /**
     * Dismiss a notification
     */
    public function dismiss(Request $request): JsonResponse
    {
        $user = Auth::user();
        
        if ($user) {
            // Hapus dari Redis
            $redisKey = "user_notification:{$user->id}";
            Redis::del($redisKey);
            
            // Hapus dari session
            $request->session()->forget('user_notification');
            
            return response()->json([
                'success' => true,
                'message' => 'Notification dismissed'
            ]);
        }
        
        return response()->json([
            'success' => false,
            'message' => 'Unauthorized'
        ], 401);
    }
}