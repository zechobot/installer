<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Pterodactyl\Services\Servers\SuspensionService;

class ExpireController extends Controller
{
    private $suspensionService;
    private $notificationService;

    public function __construct(SuspensionService $suspensionService, UserNotificationService $notificationService)
{
    $this->suspensionService = $suspensionService;
    $this->notificationService = $notificationService;
}

    public function index(Request $request)
    {
        $query = User::query()
            ->orderBy('is_permanent', 'desc')
            ->orderBy('expires_at', 'asc');

        // Filter users
        if ($request->has('filter')) {
            switch ($request->get('filter')) {
                case 'expired':
                    $query->where('is_permanent', false)
                          ->whereNotNull('expires_at')
                          ->where('expires_at', '<', now());
                    break;
                case 'expiring':
                    $query->where('is_permanent', false)
                          ->whereNotNull('expires_at')
                          ->where('expires_at', '>', now())
                          ->where('expires_at', '<=', now()->addHours(2));
                    break;
                case 'permanent':
                    $query->where('is_permanent', true);
                    break;
                case 'all':
                default:
                    // No filter
                    break;
            }
        }

        $users = $query->with('servers')->paginate(20);

        return view('admin.expire.index', [
            'users' => $users,
        ]);
    }

    public function updateUser(Request $request, $id)
    {
        $user = User::with('servers')->findOrFail($id);

        $request->validate([
            'expires_at' => 'nullable|date',
            'is_permanent' => 'boolean',
        ]);

        // Simpan nilai expires_at saat ini sebelum perubahan
        $currentExpiresAt = $user->expires_at;
        
        // Handle data update
        $isPermanent = $request->has('is_permanent') && $request->is_permanent;
        
        if ($isPermanent) {
            // Jika menjadi permanent: set flag permanent, tapi JANGAN ubah expires_at
            $user->is_permanent = true;
            // expires_at tetap seperti semula (tidak diubah ke null)
        } else {
            // Jika menjadi non-permanent
            $user->is_permanent = false;
            
            if ($request->filled('expires_at')) {
                // Jika ada input expires_at baru, gunakan itu
                $user->expires_at = Carbon::parse($request->expires_at);
            } else {
                // Jika tidak ada input expires_at
                if ($currentExpiresAt) {
                    // Gunakan data expires_at yang sudah ada (data lama)
                    $user->expires_at = $currentExpiresAt;
                } else {
                    // Jika benar-benar tidak ada data lama (null), baru set default 30 hari
                    $user->expires_at = now()->addDays(30);
                }
            }
        }

        $user->save();

        // Auto-suspend jika kurang dari 2 jam dan user bukan permanent
        if (!$user->is_permanent && $user->expires_at && $user->expires_at->diffInHours(now()) <= 2) {
            foreach ($user->servers as $server) {
                if (!$server->isSuspended()) {
                    try {
                        $this->suspensionService->toggle($server, 'suspend');
                    } catch (\Exception $e) {
                        \Log::error('Failed to suspend server: ' . $server->id . ' - ' . $e->getMessage());
                    }
                }
            }
        }
        if (!$user->is_permanent && $user->expires_at && $user->expires_at->diffInHours(now()) <= 2) {
    foreach ($user->servers as $server) {
        if (!$server->isSuspended()) {
            try {
                $this->suspensionService->toggle($server, 'suspend');
            } catch (\Exception $e) {
                \Log::error('Failed to suspend server: ' . $server->id . ' - ' . $e->getMessage());
            }
        }
    }
    
    // Set notification for expiring user
    $this->notificationService->setExpiringNotification($user);
}
        // Hitung ulang statistik
        $stats = $this->calculateStats();

        // Untuk tampilan di frontend: jika permanent, kembalikan expires_at sebagai null
        // Tapi di database tetap simpan data aslinya
        $displayExpiresAt = $user->is_permanent ? null : $user->expires_at;

        return response()->json([
            'success' => "User {$user->username} has been updated successfully!",
            'user' => [
                'id' => $user->id,
                'username' => $user->username,
                'email' => $user->email,
                'root_admin' => (bool)$user->root_admin,
                'is_permanent' => (bool)$user->is_permanent,
                'expires_at' => $displayExpiresAt ? $displayExpiresAt->toISOString() : null,
                'expires_at_actual' => $user->expires_at ? $user->expires_at->toISOString() : null, // data sebenarnya di DB
                'expires_at_formatted' => $displayExpiresAt ? $displayExpiresAt->format('Y-m-d H:i') : null,
                'expires_at_human' => $displayExpiresAt ? $displayExpiresAt->diffForHumans() : null,
                'servers_count' => $user->servers->count(),
                'suspended_servers_count' => $user->servers->where('status', 'suspended')->count(),
                'is_expired' => !$user->is_permanent && $user->expires_at && $user->expires_at->isPast(),
                'is_expiring_soon' => !$user->is_permanent && $user->expires_at && 
                                    $user->expires_at->diffInHours(now()) <= 2 && 
                                    !$user->expires_at->isPast(),
                'time_left' => !$user->is_permanent && $user->expires_at && !$user->expires_at->isPast() ? 
                    $this->formatTimeLeft($user->expires_at) : null,
                'time_left_minutes' => !$user->is_permanent && $user->expires_at && !$user->expires_at->isPast() ? 
                    $user->expires_at->diffInMinutes(now()) : null,
            ],
            'stats' => $stats
        ]);
    }

    /**
     * Calculate statistics for live update
     */
    private function calculateStats()
    {
        $allUsers = User::all();
        $permanentUsers = $allUsers->where('is_permanent', true);
        $nonPermanentUsers = $allUsers->where('is_permanent', false);
        
        $expiringSoon = $nonPermanentUsers->filter(function($user) {
            return $user->expires_at && 
                   $user->expires_at->gt(now()) && 
                   $user->expires_at->lte(now()->addHours(2));
        });
        
        $expired = $nonPermanentUsers->filter(function($user) {
            return $user->expires_at && $user->expires_at->lt(now());
        });

        // Calculate server stats
        $totalServers = 0;
        $suspendedServers = 0;
        
        foreach ($allUsers as $user) {
            $totalServers += $user->servers->count();
            $suspendedServers += $user->servers->where('status', 'suspended')->count();
        }

        return [
            'total_users' => $allUsers->count(),
            'permanent_users' => $permanentUsers->count(),
            'expiring_soon' => $expiringSoon->count(),
            'expired_users' => $expired->count(),
            'total_servers' => $totalServers,
            'suspended_servers' => $suspendedServers,
        ];
    }

    /**
     * Format time left for display
     */
    private function formatTimeLeft($expiresAt)
    {
        $diff = $expiresAt->diff(now());
        
        $parts = [];
        if ($diff->days > 0) {
            $parts[] = $diff->days . 'd';
        }
        if ($diff->h > 0) {
            $parts[] = $diff->h . 'h';
        }
        if ($diff->i > 0) {
            $parts[] = $diff->i . 'm';
        }
        
        if (empty($parts)) {
            $parts[] = '0m';
        }
        
        return implode(' ', $parts);
    }
}