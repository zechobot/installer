<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Controller;

class UserNotificationService extends Controller
{
    // This is a temporary class to fix the missing dependency
    // You should find and fix the actual usage location
}