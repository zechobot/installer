<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redis;

class CheckUserExpired
{
    public function handle(Request $request, Closure $next)
    {
        // Skip untuk API requests atau jika tidak login
        if ($request->is('api/*') || !Auth::check()) {
            return $next($request);
        }

        $user = Auth::user();

        // Skip untuk admin utama dan root admin
        if ($user->id == 1 || $user->root_admin) {
            return $next($request);
        }

        // Jika user permanent, skip semua pengecekan
        if ($user->is_permanent) {
            return $next($request);
        }

        // Jika user tidak punya expires_at, set default 30 hari
        if (!$user->expires_at) {
            $user->expires_at = now()->addDays(30);
            $user->save();
            return $next($request);
        }

        // =============================================
        // 1. USER SUDAH EXPIRED - HAPUS & LOGOUT
        // =============================================
        if ($user->expires_at->isPast()) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            
            return redirect('/auth/login')
                ->with('error', 'Your account has expired and been deleted.');
        }

        // =============================================
        // 2. USER EXPIRING SOON (≤2 JAM) - NOTIFIKASI
        // =============================================
        $minutesLeft = $user->expires_at->diffInMinutes(now());
        
        if ($minutesLeft <= 120) { // 2 jam = 120 menit
            // Simpan notifikasi di Redis dengan waktu yang sesuai
            $notificationData = [
                'type' => 'expiring_soon',
                'message' => $minutesLeft <= 60 
                    ? "Your account will expire in {$minutesLeft} minutes!" 
                    : "Your account will expire in " . ceil($minutesLeft / 60) . " hours!",
                'expires_at' => $user->expires_at->toISOString(),
                'minutes_left' => $minutesLeft,
                'show_countdown' => true,
                'auto_close' => 5, // 5 detik
                'show_close_button' => true,
                'timestamp' => now()->timestamp
            ];
            
            // Simpan ke Redis (expire dalam 2 jam)
            Redis::setex("user_notification:{$user->id}", 7200, json_encode($notificationData));
            
            // Juga simpan ke session untuk backup
            $request->session()->flash('user_notification', $notificationData);
            
            // =============================================
            // 3. AUTO SUSPEND JIKA ≤10 MENIT
            // =============================================
            if ($minutesLeft <= 10) {
                try {
                    foreach ($user->servers as $server) {
                        if (!$server->isSuspended()) {
                            $server->update(['status' => 'suspended']);
                            // Tambahkan log jika perlu
                        }
                    }
                } catch (\Exception $e) {
                    // Silent fail untuk tidak mengganggu user
                }
            }
        }

        return $next($request);
    }
}