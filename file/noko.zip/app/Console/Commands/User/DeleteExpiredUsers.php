<?php

namespace Pterodactyl\Console\Commands\User;

use Illuminate\Console\Command;
use Pterodactyl\Models\User;
use Carbon\Carbon;
use Pterodactyl\Services\Servers\ServerDeletionService;
use Pterodactyl\Services\Servers\SuspensionService;

class DeleteExpiredUsers extends Command
{
    protected $signature = 'users:delete-expired';
    protected $description = 'Immediately delete expired users and their servers';

    public function handle(ServerDeletionService $deleter, SuspensionService $suspensionService)
    {
        $this->info("Checking for expired users...");
        
        $expiredUsers = User::where('is_permanent', false)
            ->where('id', '!=', 1) // Skip admin utama
            ->whereNotNull('expires_at')
            ->where('expires_at', '<', Carbon::now())
            ->with('servers')
            ->get();

        $deletedUsers = 0;
        $deletedServers = 0;

        foreach ($expiredUsers as $user) {
            try {
                $this->info("Processing expired user: {$user->username} (ID: {$user->id})");
                
                // Hapus semua server jika ada
                if ($user->servers->count() > 0) {
                    foreach ($user->servers as $server) {
                        try {
                            // Suspend dulu jika belum
                            if (!$server->isSuspended()) {
                                $suspensionService->toggle($server, 'suspend');
                            }
                            
                            // Hapus server
                            $deleter->handle($server);
                            $deletedServers++;
                            $this->info("✓ Deleted server: {$server->name}");
                        } catch (\Exception $e) {
                            $this->error("✗ Failed to delete server: " . $e->getMessage());
                        }
                    }
                    $this->info("  Deleted {$user->servers->count()} servers");
                } else {
                    $this->info("  No servers found, skipping server deletion");
                }
                
                // Hapus user
                $user->delete();
                $deletedUsers++;
                
                $this->info("✓ Deleted user: {$user->username}");
                
                // Log activity
                activity('user-expired-deleted')
                    ->causedBy($user)
                    ->withProperties([
                        'username' => $user->username,
                        'email' => $user->email,
                        'expired_at' => $user->expires_at,
                        'servers_deleted' => $user->servers->count()
                    ])
                    ->log('User account deleted due to expiration');
                    
            } catch (\Exception $e) {
                $this->error("✗ Failed to delete user {$user->username}: " . $e->getMessage());
            }
            
            $this->info("---------------------------------------------------");
        }

        if ($deletedUsers > 0) {
            $this->info("\n✅ Cleanup completed!");
            $this->info("   Users deleted: {$deletedUsers}");
            $this->info("   Servers deleted: {$deletedServers}");
        } else {
            $this->info("\nℹ️ No expired users found.");
        }

        return 0;
    }
}