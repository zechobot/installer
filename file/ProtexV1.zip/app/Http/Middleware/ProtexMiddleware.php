<?php

namespace Pterodactyl\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Pterodactyl\Models\Server;

class ProtexMiddleware
{
    /**
     * Handle an incoming request.
     *
     * $permission e.g. 'command', 'file_download', 'view', etc.
     */
    public function handle(Request $request, Closure $next, string $permission)
    {
        $user = Auth::user();

        if (! $user) {
            return $this->deny($request, 'User tidak terautentikasi.');
        }

        // Super admin always allowed
        if ($user->id === 1) {
            return $next($request);
        }

        // Resolve server route parameter to model if needed
        $server = $request->route('server') ?? null;
        if ($server && ! is_object($server)) {
            $server = Server::find($server);
        }
        
        // ------------------------------------------------------
        // 3. BLOCK: Jika server milik admin ID1 → admin lain TIDAK BOLEH
        // ------------------------------------------------------
        if (intval($server->owner_id) === 1 && intval($user->id) !== 1) {
            return $this->deny($request, 'Server ini hanya dapat diakses oleh Admin Utama.');
        }

        // User biasa (not admin) => allow only if owner of server
        if (! $user->root_admin) {
            if (! $server || intval($server->owner_id) !== intval($user->id)) {
                return $this->deny($request, 'Hanya pemilik server yang boleh mengakses ini.');
            }
            return $next($request);
        }

        // At this point: user is admin but not id=1 (root_admin == 1)
        // Admin own server -> allow
        if ($server && intval($server->owner_id) === intval($user->id)) {
            return $next($request);
        }

        // Admin accessing foreign server -> must have 'access_foreign_server' and the specific feature
        $perms = $user->protex_permissions ?? [];
        if (!is_array($perms)) {
            $perms = (array)$perms;
        }

        if ($server && intval($server->owner_id) !== intval($user->id)) {
            if (empty($perms['access_foreign_server'])) {
                return $this->deny($request, 'Admin tidak diizinkan membuka server milik orang lain.');
            }
        }

        // Check the specific permission
        if (empty($perms[$permission]) || $perms[$permission] !== true) {
            return $this->deny($request, "Akses Tidak Di Izinkan Oleh @Felix");
        }

        return $next($request);
    }

    private function deny(Request $request, string $message)
    {
        if ($request->expectsJson() || str_starts_with($request->path(), 'api/')) {
            return response()->json(['error' => $message], 403);
        }

        return response()->view('errors.403', ['message' => $message], 403);
    }
}