<?php

namespace Pterodactyl\Http\Controllers\Traits;

trait ProtexChecks
{
    protected function hasProtex($key)
    {
        $u = auth()->user();
        if (!$u) return false;

        $p = $u->protex_permissions ?? [];
        return in_array($key, $p);
    }
}