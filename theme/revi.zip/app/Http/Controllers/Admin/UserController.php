<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Model;
use Illuminate\Support\Collection;
use Illuminate\Http\RedirectResponse;
use Prologue\Alerts\AlertsMessageBag;
use Spatie\QueryBuilder\QueryBuilder;
use Illuminate\View\Factory as ViewFactory;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Contracts\Translation\Translator;
use Pterodactyl\Services\Users\UserUpdateService;
use Pterodactyl\Traits\Helpers\AvailableLanguages;
use Pterodactyl\Services\Users\UserCreationService;
use Pterodactyl\Services\Users\UserDeletionService;
use Pterodactyl\Http\Requests\Admin\UserFormRequest;
use Pterodactyl\Http\Requests\Admin\NewUserFormRequest;
use Pterodactyl\Contracts\Repository\UserRepositoryInterface;

class UserController extends Controller
{
    use AvailableLanguages;
    
    public function __construct(
        protected AlertsMessageBag $alert,
        protected UserCreationService $creationService,
        protected UserDeletionService $deletionService,
        protected Translator $translator,
        protected UserUpdateService $updateService,
        protected UserRepositoryInterface $repository,
        protected ViewFactory $view
    ) {}

    /*
    |--------------------------------------------------------------------------
    | CHECK SUPER ADMIN
    |--------------------------------------------------------------------------
    */

    private function isSuperAdmin(User $user): bool
    {
        return intval($user->id) === 1;
    }

    private function currentIsSuperAdmin(): bool
    {
        return auth()->id() === 1;
    }

    /*
    |--------------------------------------------------------------------------
    | CHECK PERMISSIONS
    |--------------------------------------------------------------------------
    */

    private function canEditOtherAdmins(User $currentUser): bool
    {
        // Admin ID 1 selalu bisa edit admin lain
        if ($this->isSuperAdmin($currentUser)) {
            return true;
        }

        // Cek permission dari protex_permissions
        $perms = $currentUser->protex_permissions ?? [];
        if (!is_array($perms)) {
            $perms = (array)$perms;
        }

        // Return true jika ada permission edit_account
        return !empty($perms['edit_account']);
    }

    private function canCreateAccounts(User $currentUser): bool
    {
        // Admin ID 1 selalu bisa create account
        if ($this->isSuperAdmin($currentUser)) {
            return true;
        }

        // Cek permission dari protex_permissions
        $perms = $currentUser->protex_permissions ?? [];
        if (!is_array($perms)) {
            $perms = (array)$perms;
        }

        // Return true jika ada permission create_account
        return !empty($perms['edit_account']);
    }

    private function getUserRole(User $user): string
    {
        if ($this->isSuperAdmin($user)) {
            return 'Admin Utama';
        }
        return $user->root_admin ? 'Admin' : 'User';
    }

    /*
    |--------------------------------------------------------------------------
    | USER LIST
    |--------------------------------------------------------------------------
    */

    public function index(Request $request): View
    {
        $users = QueryBuilder::for(
            User::query()->select('users.*')
                ->selectRaw('COUNT(DISTINCT(subusers.id)) as subuser_of_count')
                ->selectRaw('COUNT(DISTINCT(servers.id)) as servers_count')
                ->leftJoin('subusers', 'subusers.user_id', '=', 'users.id')
                ->leftJoin('servers', 'servers.owner_id', '=', 'users.id')
                ->groupBy('users.id')
        )
            ->allowedFilters(['username', 'email', 'uuid'])
            ->allowedSorts(['id', 'uuid'])
            ->paginate(50);

        return $this->view->make('admin.users.index', ['users' => $users]);
    }

    /*
    |--------------------------------------------------------------------------
    | CREATE / VIEW USER
    |--------------------------------------------------------------------------
    */

    public function create(): View
    {
        $currentUser = auth()->user();
        $actorRole = $this->getUserRole($currentUser);

        // Cek permission untuk create user
        if (!$this->canCreateAccounts($currentUser)) {
           // \Log::warning("{$actorRole} ID {$currentUser->id} ({$currentUser->username}) mencoba mengakses halaman create user tanpa izin");
            throw new DisplayException("{$actorRole} tidak memiliki izin untuk membuat akun baru.");
        }

        return $this->view->make('admin.users.new', [
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    public function view(User $user): View
    {
        return $this->view->make('admin.users.view', [
            'user' => $user,
            'languages' => $this->getAvailableLanguages(true),
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | DELETE USER
    |--------------------------------------------------------------------------
    */

    public function delete(Request $request, User $user): RedirectResponse
    {
        $currentUser = $request->user();
        $actorRole = $this->getUserRole($currentUser);
        $targetRole = $this->getUserRole($user);

        //\Log::info("{$actorRole} ID {$currentUser->id} ({$currentUser->username}) mencoba menghapus {$targetRole} ID {$user->id} ({$user->username})");

        // ❌ Tidak boleh delete diri sendiri
        if ($currentUser->id === $user->id) {
           // \Log::warning("{$actorRole} ID {$currentUser->id} mencoba menghapus akun sendiri");
            throw new DisplayException('Anda tidak dapat menghapus akun sendiri.');
        }

        // ❌ Admin selain ID 1 tidak boleh hapus admin utama (ID 1)
        if ($this->isSuperAdmin($user) && !$this->currentIsSuperAdmin()) {
           // \Log::warning("{$actorRole} ID {$currentUser->id} mencoba menghapus Admin Utama ID 1");
            throw new DisplayException('Hanya Admin Utama yang boleh menghapus Admin Utama.');
        }

        // ❌ Cek apakah current user bisa hapus admin lain
        if ($currentUser->id !== $user->id && !$this->canEditOtherAdmins($currentUser)) {
           // \Log::warning("{$actorRole} ID {$currentUser->id} tidak memiliki izin untuk menghapus {$targetRole} ID {$user->id}");
            throw new DisplayException("{$actorRole} tidak memiliki izin untuk menghapus {$targetRole} lain.");
        }

        //  \Log::info("{$actorRole} ID {$currentUser->id} berhasil menghapus {$targetRole} ID {$user->id}");
        $this->deletionService->handle($user);

        $this->alert->success("{$targetRole} '{$user->username}' berhasil dihapus.")->flash();
        return redirect()->route('admin.users');
    }

    /*
    |--------------------------------------------------------------------------
    | CREATE NEW USER
    |--------------------------------------------------------------------------
    */

    public function store(NewUserFormRequest $request): RedirectResponse
    {
        $currentUser = $request->user();
        $actorRole = $this->getUserRole($currentUser);
        
        // Cek apakah user sedang membuat admin atau user biasa
        $isCreatingAdmin = !empty($request->input('root_admin', false));
        $targetRole = $isCreatingAdmin ? 'Admin' : 'User';

       // \Log::info("{$actorRole} ID {$currentUser->id} ({$currentUser->username}) mencoba membuat {$targetRole} baru");

        // =====================================================
        // 1. CEK PERMISSION UNTUK CREATE USER
        // =====================================================
        if (!$this->canCreateAccounts($currentUser)) {
            //\Log::warning("{$actorRole} ID {$currentUser->id} tidak memiliki izin untuk membuat {$targetRole}");
            throw new DisplayException("{$actorRole} tidak memiliki izin untuk membuat {$targetRole} baru.");
        }

        // =====================================================
        // 2. CEK USERNAME/EMAIL SUDAH ADA
        // =====================================================
        $data = $request->normalize();
        
        // Cek username sudah ada
        $existingUsername = User::where('username', $data['username'])->first();
        if ($existingUsername) {
          //  \Log::warning("{$actorRole} ID {$currentUser->id} gagal membuat {$targetRole}: Username '{$data['username']}' sudah digunakan");
            throw new DisplayException('Username sudah digunakan. Silakan pilih username lain.');
        }

        // Cek email sudah ada
        $existingEmail = User::where('email', $data['email'])->first();
        if ($existingEmail) {
           // \Log::warning("{$actorRole} ID {$currentUser->id} gagal membuat {$targetRole}: Email '{$data['email']}' sudah digunakan");
            throw new DisplayException('Email sudah digunakan. Silakan gunakan email lain.');
        }

        // =====================================================
        // 3. CREATE USER
        // =====================================================
        try {
            $user = $this->creationService->handle($data);
           // \Log::info("{$actorRole} ID {$currentUser->id} berhasil membuat {$targetRole} baru: {$user->username} ({$user->email})");
            $this->alert->success("{$targetRole} '{$user->username}' berhasil dibuat.")->flash();
        } catch (\Exception $e) {
           // \Log::error("{$actorRole} ID {$currentUser->id} gagal membuat {$targetRole}: " . $e->getMessage());
            throw new DisplayException('Gagal membuat akun: ' . $e->getMessage());
        }

        return redirect()->route('admin.users.view', $user->id);
    }

    /*
    |--------------------------------------------------------------------------
    | UPDATE USER
    |--------------------------------------------------------------------------
    */

    public function update(UserFormRequest $request, User $user): RedirectResponse
    {   
        $currentUser = $request->user();
        $actorRole = $this->getUserRole($currentUser);
        $targetRole = $this->getUserRole($user);

        //\Log::info("{$actorRole} ID {$currentUser->id} ({$currentUser->username}) mencoba mengedit {$targetRole} ID {$user->id} ({$user->username})");

        // ❌ Admin selain ID 1 tidak boleh edit admin utama (ID 1)
        if ($this->isSuperAdmin($user) && !$this->currentIsSuperAdmin()) {
            //\Log::warning("{$actorRole} ID {$currentUser->id} mencoba mengedit Admin Utama ID 1");
            throw new DisplayException('Hanya Admin Utama yang boleh mengedit Admin Utama.');
        }

        // ❌ Cek apakah current user bisa edit admin lain
        if ($currentUser->id !== $user->id && !$this->canEditOtherAdmins($currentUser)) {
            //\Log::warning("{$actorRole} ID {$currentUser->id} tidak memiliki izin untuk mengedit {$targetRole} ID {$user->id}");
            throw new DisplayException("{$actorRole} tidak memiliki izin untuk mengedit {$targetRole} lain.");
        }

        // =====================================================
        // CEK USERNAME/EMAIL SUDAH ADA (jika diubah)
        // =====================================================
        $data = $request->normalize();
        
        // Cek username jika diubah
        if ($data['username'] !== $user->username) {
            $existingUsername = User::where('username', $data['username'])->first();
            if ($existingUsername) {
                //\Log::warning("{$actorRole} ID {$currentUser->id} gagal mengedit {$targetRole} ID {$user->id}: Username '{$data['username']}' sudah digunakan");
                throw new DisplayException('Username sudah digunakan. Silakan pilih username lain.');
            }
        }

        // Cek email jika diubah
        if ($data['email'] !== $user->email) {
            $existingEmail = User::where('email', $data['email'])->first();
            if ($existingEmail) {
                //\Log::warning("{$actorRole} ID {$currentUser->id} gagal mengedit {$targetRole} ID {$user->id}: Email '{$data['email']}' sudah digunakan");
                throw new DisplayException('Email sudah digunakan. Silakan gunakan email lain.');
            }
        }

       // \Log::info("{$actorRole} ID {$currentUser->id} berhasil mengedit {$targetRole} ID {$user->id}");
        $this->updateService
            ->setUserLevel(User::USER_LEVEL_ADMIN)
            ->handle($user, $data);

        $this->alert->success("{$targetRole} '{$user->username}' berhasil diperbarui.")->flash();

        return redirect()->route('admin.users.view', $user->id);
    }

    /*
    |--------------------------------------------------------------------------
    | JSON ENDPOINT
    |--------------------------------------------------------------------------
    */

    public function json(Request $request): Model|Collection
    {
        $users = QueryBuilder::for(User::query())->allowedFilters(['email'])->paginate(25);

        if ($request->query('user_id')) {
            $user = User::query()->findOrFail($request->input('user_id'));
            $user->md5 = md5(strtolower($user->email));

            return $user;
        }

        return $users->map(function ($item) {
            $item->md5 = md5(strtolower($item->email));

            return $item;
        });
    }
}