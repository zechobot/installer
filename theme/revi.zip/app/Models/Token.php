<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Token extends Model
{
    protected $table = 'tokenslogin';

    protected $fillable = [
        'sn',
        'token',
        'duration_seconds',
        'activated_at',
        'expires_at',
        'used_by',
        'is_used',
    ];

    protected $casts = [
        'activated_at' => 'datetime',
        'expires_at' => 'datetime',
        'is_used' => 'boolean',
    ];

    // apakah token permanent?
    public function isPermanent(): bool
    {
        return $this->duration_seconds === null;
    }

    // apakah sudah diaktifkan?
    public function isActivated(): bool
    {
        return $this->activated_at !== null;
    }

    // apakah expired?
    public function isExpired(): bool
    {
        if ($this->isPermanent()) {
            return false;
        }
        if (!$this->expires_at) {
            return false;
        }
        return now()->greaterThan($this->expires_at);
    }

    // sisa detik (null jika permanent / belum activated)
    public function remainingSeconds(): ?int
    {
        if ($this->isPermanent() || !$this->expires_at) return null;
        return max(0, $this->expires_at->diffInSeconds(now(), false));
    }

    // human readable duration (used in views)
    public function durationHuman(): string
    {
        if ($this->isPermanent()) return 'Permanent';
        $s = $this->duration_seconds;
        if ($s < 60) return $s . ' seconds';
        if ($s < 3600) return intval($s / 60) . ' minutes';
        if ($s < 86400) return intval($s / 3600) . ' hours';
        if ($s < 2592000) return intval($s / 86400) . ' days';
        if ($s < 31536000) return intval($s / 2592000) . ' months';
        return intval($s / 31536000) . ' years';
    }
}