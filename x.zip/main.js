const fs = require("fs")
const path = require("path")
const chalk = require('chalk')
const axios = require('axios');
const fetch = require("node-fetch")
const userbotinput = require("input");
const syntaxError = require("syntax-error")
const child_process = require("child_process")
require("./config")
require("./lib/function.js");
const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const apiId = global.apiId;
const apiHash = global.apiHash;
const rootDir = path.join(__dirname, "Felix");
const subfolders = ["sesions", "temp"];
subfolders.forEach(sub => {
  const dir = path.join(rootDir, sub);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log(`✅ Folder dibuat: ${dir}`);
  } else {
    console.log(`📂 Folder sudah ada: ${dir}`);
  }
});
const sessionsDir = path.join(rootDir, "sesions");
const tempDir = path.join(rootDir, "temp");
const sessionFile = path.join(sessionsDir, global.session);
const sessionFiles = path.join(sessionsDir, "WhatsApp_sessions.json");
const handler = require('./handler')
const TelegramBot = require("node-telegram-bot-api")
const conn = new TelegramBot(global.token, { polling: true })
const { listPanel, deletePanel } = require('./lib/cpanel')

require("./lib/simple")(conn)
function waktuWIB() {
  const now = new Date()
  // WIB: GMT+7
  const wibTime = new Date(now.getTime() + 7 * 60 * 60 * 1000)
  const options = {
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    timeZone: "Asia/Jakarta",
    timeZoneName: "longOffset",
  }
  const formatted = wibTime.toLocaleString("en-US", options)
  return `[${formatted.replace(/GMT\+7/, "GMT+0700")} (Western Indonesia Time - WIB)]`
}

conn.logger = {
  info: (msg) =>
    console.log(`${chalk.green.bold("INFO")} ${chalk.white.bold(waktuWIB())}: ${chalk.cyan(msg)}`),
  warn: (msg) =>
    console.log(
      `${chalk.hex('#FF8800').bold("WARNING")} ${chalk.white.bold(waktuWIB())}: ${chalk.yellow(msg)}`,
    ),
  error: (msg) =>
    console.log(`${chalk.red.bold("ERROR")} ${chalk.white.bold(waktuWIB())}: ${chalk.red(msg)}`),
}

let dbLibrary
try {
  dbLibrary = require("lowdb")
} catch (error) {
  dbLibrary = require("./lib/lowdb")
}
const { Low, JSONFile } = dbLibrary

const adapter = new JSONFile("./database.json")
global.db = new Low(adapter)
global.loadDatabase = async () => {
  if (global.db.READ) {
    return new Promise((resolve) => {
      const interval = setInterval(() => {
        if (!global.db.READ) {
          clearInterval(interval)
          resolve(global.db.data == null ? global.loadDatabase() : global.db.data)
        }
      }, 1000)
    })
  }

  if (global.db.data !== null) return

  global.db.READ = true
  await global.db.read()
  global.db.READ = false
  global.db.data = {
    users: {},
    chats: {},
    owner: [],
    reseller: [],
    premium: [],
    stats: {},
    msgs: {},
    sticker: {},
    ...(global.db.data || {}),
  }
  global.db.READ = false
}

async function saveDatabase() {
  try {
    if (global.db.data) {
      await global.db.write()
    }
  } catch (e) {
    console.log("Save database error:", e)
  }
}

loadDatabase()
setInterval(saveDatabase, 30000)

global.plugins = {}
const pluginsDir = path.join(__dirname, "plugins")


function loadPlugins() {
  if (!fs.existsSync(pluginsDir)) {
    fs.mkdirSync(pluginsDir)
  }

  const files = fs.readdirSync(pluginsDir).filter((file) => file.endsWith(".js"))

  for (const file of files) {
    try {
      delete require.cache[require.resolve(path.join(pluginsDir, file))]
      global.plugins[file] = require(path.join(pluginsDir, file))
    } catch (e) {
      console.log(`Error loading plugin ${file}:`, e)
    }
  }
}

loadPlugins()
global.reload = (event, filePath) => {
  if (/\.js$/.test(filePath)) {
    const fullFilePath = path.join(pluginsDir, filePath)
    if (fullFilePath in require.cache) {
      delete require.cache[fullFilePath]
      if (fs.existsSync(fullFilePath)) {
        conn.logger.info(`Re-requiring plugin '${filePath}'`)
      } else {
        conn.logger.warn(`Deleted plugin '${filePath}'`)
        return delete global.plugins[filePath]
      }
    } else {
      conn.logger.info(`Requiring new plugin '${filePath}'`)
    }

    const errorCheck = syntaxError(fs.readFileSync(fullFilePath), filePath)
    if (errorCheck) {
      conn.logger.error(`Syntax error while loading '${filePath}':\n${errorCheck}`)
    } else {
      try {
        global.plugins[filePath] = require(fullFilePath)
      } catch (error) {
        conn.logger.error(error)
      } finally {
        global.plugins = Object.fromEntries(Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b)))
      }
    }
  }
}
Object.freeze(global.reload)
fs.watch(path.join(__dirname, "plugins"), global.reload)

let sessionData = "";
if (fs.existsSync(sessionFile)) {
  sessionData = fs.readFileSync(sessionFile, "utf8").trim();
}


// === Userbot Telegram ===
if (global.usersbot) {
  (async () => {
    try {
      const session = new StringSession(sessionData);
      global.FelixUserBot = new TelegramClient(session, apiId, apiHash, {
        connectionRetries: 10,
        autoReconnect: true,
      });

      console.log("[•] Menghubungkan ke Telegram...");

      await global.FelixUserBot.start({
        phoneNumber: global.phoneNumber,
        password: async () => await userbotinput.text("[•] Password 2FA (kosongkan jika tidak ada): "),
        phoneCode: async () => await userbotinput.text("[•] Kode OTP dari Telegram:\n"),
        onError: (err) => console.log("Login error:", err),
      });

      fs.writeFileSync(sessionFile, global.FelixUserBot.session.save(), "utf8");
      console.log("[•] Userbot berhasil tersambung ke Telegram.");

      try { await global.loadChatTelegram(Api, global.FelixUserBot); } catch (e) {}
      try { await global.FelixUserBot.getDialogs(); } catch (e) {}

      // Event handler userbot
      global.FelixUserBot.addEventHandler(
        async (event) => {
          try {
            const msgx = event.message;
            if (typeof handler.handler === "function") {
              await handler.handler.call(conn, null, msgx);
            }
          } catch (e) {
            console.error("Error event userbot:", e);
          }
        },
        new NewMessage({ incoming: true, outgoing: true })
      );

      // Simpan global.FelixUserBot global supaya handler bisa akses

      // Connect userbot
      await global.FelixUserBot.connect();
    } catch (err) {
      console.log("Gagal login atau connect userbot:", err);
      process.exit(1);
    }
  })();
}
async function downloadFile(filePath) {
  const fileUrl = `https://api.telegram.org/file/bot${global.token}/${filePath}`;
  const tempFile = path.join(tempDir, filePath);

  const response = await axios({
    url: fileUrl,
    responseType: "stream",
  });

  const writer = fs.createWriteStream(tempFile);
  response.data.pipe(writer);

  await new Promise((resolve, reject) => {
    writer.on("finish", resolve);
    writer.on("error", reject);
    response.data.on("error", reject);
  });

  // Return filePath dan hapus setelah selesai digunakan
  return tempFile;
}

function smsg(msg) {
  if (!msg) return null

  const isCallback = !!msg.callback_query
  const m = isCallback ? msg.callback_query.message : msg
  if (!m || !m.chat) return null

  const M = {}
  
  M.text = m.text || m.caption || ""
  const msgInfo =
    m.photo?.at(-1) ||
    m.video ||
    m.document ||
    m.voice ||
    m.audio ||
    m.sticker ||
    null;
  const mimeTypex =
    m.document?.mime_type ||
    m.video?.mime_type ||
    m.voice?.mime_type ||
    m.audio?.mime_type ||
    m.sticker?.mime_type ||
    (msgInfo && m.photo ? "image/jpeg" : "") ||
    (m.sticker ? "image/webp" : "") ||
    "";
  
  // Tentukan jenis pesan (mediaType)
  const mediaTypex =
    (m.photo && "photo") ||
    (m.video && "video") ||
    (m.voice && "voice") ||
    (m.audio && "audio") ||
    (m.document && "document") ||
    (m.sticker && "sticker") ||
    (M.text ? "text" : "unknown");
    
    // kalau stiker
  if (m.sticker) { M.emoji = m.sticker.emoji || ""; }
  M.mtype = Object.keys(m)[1] || Object.keys(m)[0]
  M.id = m.message_id
  M.date = m.date
  M.chat = m.chat.id
  M.sender = (msg.from || m.from)?.id || m.chat.id
  M.fromMe = (msg.from || m.from)?.is_bot || false
  M.name = (msg.from || m.from)?.first_name || (msg.from || m.from)?.username || "Unknown"
  M.firstname = (msg.from || m.from)?.first_name || ""
  M.lastname = (msg.from || m.from)?.last_name || ""
  M.usertag = (msg.from || m.from)?.username || ""
  M.isBot = (msg.from || m.from)?.is_bot || false
  // === Deteksi jenis chat ===
  M.chatType = m.chat.type || "private"
  M.isGroup = ["group", "supergroup"].includes(M.chatType)
  M.isPrivate = M.chatType === "private"
  M.mimetype = mimeTypex;
  M.mediaType = mediaTypex;
  M.isMedia = mediaTypex !== "text" && mediaTypex !== "unknown";
  M.quoted = null; // default biar gak undefined

  if (M.isGroup) M.groupName = m.chat.title || "Unknown Group"
  M.mentionedJid = []

  // === Callback query handling ===
  if (isCallback) {
    M.isCallback = true
    M.callbackQuery = msg.callback_query
    M.data = msg.callback_query.data || ""
    M.id = m.message_id
    M.chat = m.chat.id
  }

  if (m.entities) {
    m.entities.forEach((entity) => {
      if (entity.type === "mention" && entity.user) M.mentionedJid.push(entity.user.id)
    })
  }

  // === Core Reply/Forward/Delete ===
  M.reply = async (text, options = {}) => {
    if (!text || !text.trim()) text = "⚠️ Empty message."
    return conn.sendMessage(M.chat, text, {
      reply_to_message_id: M.id,
      ...options,
    })
  }

  M.forward = async (jid) => conn.forwardMessage(jid, M.chat, M.id).catch(() => { })
  M.delete = async () => conn.deleteMessage(M.chat, M.id).catch(() => { })
  // === Handle Quoted Message ===
  if (m.reply_to_message) {
    const q = m.reply_to_message
    try {
      const msgContent =
      q.photo?.at(-1) ||
      q.video ||
      q.document ||
      q.voice ||
      q.audio ||
      q.sticker ||
        null

      // Dapatkan mime-type dan mediaType
      const mimetype =
        q?.document?.mime_type ||
        q?.video?.mime_type ||
        q?.audio?.mime_type ||
        q?.voicet?.mime_type ||
        q?.stiker?.mime_type ||
        (msgContent ? "image/jpeg" : "") ||
        ""

      const mediaType =
    (q.photo && "photo") ||
    (q.video && "video") ||
    (q.voice && "voice") ||
    (q.audio && "audio") ||
    (q.document && "document") ||
    (q.sticker && "sticker") ||
        "text"
      M.quoted = {
        text: q.text || q.caption || "",
        mtype: Object.keys(q)[1] || Object.keys(q)[0],
        msg: msgContent, // <-- simpan file media-nya
        mimetype: mimetype,        // <-- simpan mime-type-nya
        mediaType: mediaType,       // <-- jenis media (photo, video, dsb)
        isMedia: mediaType !== "text" && mediaType !== "unknown", // <-- flag boolean
        id: q.message_id,
        chat: msg.chat.id,
        sender: q.from.id,
        fromMe: q.from.is_bot,
        name: q.from.first_name || q.from.username || "Unknown",
        firstname: q.from.first_name || "",
        lastname: q.from.last_name || "",
        usertag: q.from.username || "",
        isBot: q.from.is_bot,
        isGroup: msg.chat.type === "group" || msg.chat.type === "supergroup",
        mentionedJid: [],
        reply: async (text, options = {}) =>
          conn.sendMessage(M.chat, text, {
            reply_to_message_id: q.message_id,
            ...options,
          }),

        forward: async (jid) => conn.forwardMessage(jid, M.chat, q.message_id).catch(() => { }),
        delete: async () => conn.deleteMessage(M.chat, q.message_id).catch(() => { }),
        copy: () => M.quoted,
        download: async () => {
          try {
            if (!msgContent?.file_id) return null
            const fileData = await conn.getFile(msgContent.file_id)
            const buffer = await downloadFile(fileData.file_path)
            return buffer
          } catch (err) {
            console.error("Quoted download error:", err)
            return null
          }
        },
      }

      if (q.entities) {
        q.entities.forEach((entity) => {
          if (entity.type === "mention")
            M.quoted.mentionedJid.push(entity.user?.id)
        })
      }

    } catch (err) {
      console.error("Quoted message parse error:", err)
      M.quoted = null
    }
  }

  // === File Downloader ===
  M.download = async () => {
    const file = (
    m.photo?.at(-1) ||
    m.video ||
    m.document ||
    m.voice ||
    m.audio ||
    m.sticker
    )
    if (!file) return null

    const fileData = await conn.getFile(file.file_id)
    const buffer = await downloadFile(fileData.file_path)
    return buffer
  }
  return M
}
conn._pageCache = {}
conn._menuViewIndex = conn._menuViewIndex || {}; // menyimpan indeks tampilan per chat
conn.on("callback_query", async (callback) => {
  try {
    const chatId = callback.message?.chat?.id
    const msgId = callback.message?.message_id
    const data = callback.data
    if (!chatId || !msgId) return

    // Bungkus callback menjadi struktur smsg
    const m = smsg({
      callback_query: callback,
      message: callback.message,
      from: callback.from,
    })

    let sendercek = m.sender?.toString() || m.sender;
    // pastikan target string
    if (sendercek) sendercek = sendercek.toString()
    const pxys = (global.ownerid && global.ownerid.length > 0 ? global.ownerid?.includes(sendercek) : false);
    const prex = (global.premid && global.premid.length > 0 ? global.premid?.includes(sendercek) : false);
    const owners = global.db?.data?.owner || [];
    const resellers = global.db?.data?.reseller || [];
    const premiums = global.db?.data?.premium || [];
    const premids = global.premid || [];
    const ownerids = global.ownerid || [];
    const isROwner =
      pxys ||
      ownerids.includes(sendercek);


    const isPrem =
      prex ||
      owners.includes(sendercek) ||
      premids.includes(sendercek) ||
      resellers.includes(sendercek) ||
      ownerids.includes(sendercek) ||
      premiums.includes(sendercek);

    const isReseller =
      owners.includes(sendercek) ||
      ownerids.includes(sendercek) ||
      resellers.includes(sendercek);

    const isOwner = isROwner || owners.includes(sendercek);
    const isPrems = isOwner || isPrem || isReseller;

    if (isPrem) {
      if (!premiums.includes(sendercek)) premiums.push(sendercek);
    }

    if (isROwner) {
      if (!owners.includes(sendercek)) owners.push(sendercek);
      if (!resellers.includes(sendercek)) resellers.push(sendercek);
      if (!premiums.includes(sendercek)) premiums.push(sendercek);
    }
// Inisialisasi cache
if (!conn._createCache) conn._createCache = {};
if (!conn._listCache) conn._listCache = {};
if (!conn._srvCache) conn._srvCache = {};
if (!conn._subCache) conn._subCache = {};
if (!conn._menuCache) conn._menuCache = {};
if (!conn._menuViewIndex) conn._menuViewIndex = {};
if (!conn._pageCache) conn._pageCache = {};

if (data.startsWith("sandy_panel_")) {
  const Felix = Number(data.split("_")[2]);
  const cpanels = Object.keys(global.cpanel || {});
  const tldnya = cpanels[Felix - 1];
  if (!tldnya) return await conn.answerCallbackQuery(callback.id, { text: "Server tidak ditemukan!" });

  const apikey = global.cpanel[tldnya]?.apikey;
  if (!apikey) return await conn.answerCallbackQuery(callback.id, { text: "API key tidak ditemukan!" });

  // --- Fetch list user awal
  const res = await fetch(`${tldnya}/api/application/users`, {
    method: "GET",
    headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${apikey}` }
  });
  const result = await res.json();
  const listData = result.data || [];
  if (!listData.length) return await conn.answerCallbackQuery(callback.id, { text: "Tidak ada user di panel ini!" });

  // --- Simpan cache panel
  conn._pageCache[m.chat] = {
    mode: "users",
    Felix,
    listData,
    index: 0
  };

  // --- Kirim list user pertama
  const perPage = 5;
  const slice = listData.slice(0, perPage);
  let caption = `📋 *List User (${listData.length})*\n\n`;
  slice.forEach((item, i) => caption += `${i + 1}. ${item.attributes.username}\n`);
  caption += `\n📄 Halaman 1/${Math.ceil(listData.length / perPage)}`;

  const keyboard = slice.map((item, i) => [{ text: item.attributes.username, callback_data: `list_user_${i}` }]);
  keyboard.push([{ text: '🡰 Back', callback_data: 'list_back' }, { text: '❌ Close', callback_data: 'menu_delete' }, { text: '🡲 Next', callback_data: 'list_next' }]);

  // Tombol delete hanya untuk owner
  if (isOwner) {
    keyboard.push([
      { text: '✖ 👤', callback_data: 'list_delete_user' },
      { text: '✖ 👤 🖥', callback_data: 'list_delete_all' },
      { text: '✖ 🖥', callback_data: 'list_delete_srv' }
    ]);
  }

  await conn.editMessageMedia({
    type: "photo",
    media: global.links,
    caption,
    parse_mode: "Markdown"
  }, { chat_id: m.chat, message_id: m.id, reply_markup: { inline_keyboard: keyboard } });
}

if (data && data.startsWith('list_')) {
  if (!isOwner && !resellers && !isPrems)
    return await conn.answerCallbackQuery(callback.id, { text: "Hanya owner dan reseller yang bisa menggunakan menu ini!" });

  const cache = conn._pageCache[chatId] || {};
  let { mode = 'users', Felix, listData = [], index = 0 } = cache;

  const normalizeMode = (modeInput) => {
    if (!modeInput) return 'users';
    const input = modeInput.toLowerCase();
    if (['srv', 'server', 'servers'].includes(input)) return 'servers';
    if (['user', 'users'].includes(input)) return 'users';
    return 'users';
  };

  if (data === 'list_user') { mode = 'users'; listData = []; index = 0; }
  if (data === 'list_server') { mode = 'servers'; listData = []; index = 0; }
  mode = normalizeMode(mode);

  const domain = Object.keys(global.cpanel)[Felix - 1];
  const apikey = global.cpanel[domain]?.apikey;
  if (!domain || !apikey) return await conn.answerCallbackQuery(callback.id, { text: 'Domain atau API key tidak ditemukan!' });

  if (!listData.length && mode === 'users') {
    const res = await fetch(`${domain}/api/application/users`, {
      method: 'GET',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json', Authorization: `Bearer ${apikey}` }
    });
    const result = await res.json();
    if (!result.data || result.data.length === 0) return await conn.answerCallbackQuery(callback.id, { text: 'Tidak ada user!' });
    listData = result.data;
  }

  const perPage = 5;
  const totalPages = Math.ceil(listData.length / perPage) || 1;
  if (data === 'list_next') index = (index + 1) % totalPages;
  if (data === 'list_back') index = (index - 1 + totalPages) % totalPages;
  if (data === "list_delete_all") {
    if (!isOwner && !isReseller) return conn.answerCallbackQuery(callback.id, { text: "Hanya owner dan reseller yang bisa Menggunakan Menu ini!!" });
    const res = await deletePanel({ cmd: 'deletepanel', args: [Felix, 'all'] });
    await conn.answerCallbackQuery(callback.id, { text: res.success ? `🗑 ${res.message} !!` : res.message });
  } else if (data === "list_delete_srv") {
    if (!isOwner && !isReseller) return conn.answerCallbackQuery(callback.id, { text: "Hanya owner dan reseller yang bisa Menggunakan Menu ini!!" });
    const res = await deletePanel({ cmd: 'deletepanel', args: [Felix, 'allserver'] });
    await conn.answerCallbackQuery(callback.id, { text: res.success ? `🗑 ${res.message} !!` : res.message });
  } else if (data === "list_delete_user") {
    if (!isOwner && !isReseller) return conn.answerCallbackQuery(callback.id, { text: "Hanya owner dan reseller yang bisa Menggunakan Menu ini!!" });
    const res = await deletePanel({ cmd: 'deletepanel', args: [Felix, 'alluser'] });
    await conn.answerCallbackQuery(callback.id, { text: res.success ? `🗑 ${res.message} !!` : res.message });
  }
  conn._pageCache[chatId] = { mode, Felix, listData, index };
  const slice = listData.slice(index * perPage, (index + 1) * perPage);

  // --- List User Page ---
  if (mode === 'users' && !data.startsWith('list_user_')) {
    let caption = `📋 *List User (${listData.length})*\n\n`;
    for (let i = 0; i < slice.length; i++) {
      const item = slice[i]; 
      const nomor = index * perPage + i;
      caption += `${nomor + 1}. ${item.attributes.username}\n`;
    }
    caption += `\n📄 Halaman ${index + 1}/${totalPages}`;
// Tombol list user
const keyboard = slice.map((item, i) => {
  const nomor = index * perPage + i;
  return [{ text: item.attributes.username, callback_data: `list_user_${nomor}` }];
});

// Tombol navigasi
keyboard.push([
  { text: '🡰 Back', callback_data: 'list_back' },
  { text: '❌ Close', callback_data: 'menu_delete' },
  { text: '🡲 Next', callback_data: 'list_next' }
]);

// Tombol delete hanya untuk owner
if (isOwner) {
  keyboard.push([
    { text: '✖ 👤', callback_data: 'list_delete_user' },
    { text: '✖ 👤 🖥', callback_data: 'list_delete_all' },
    { text: '✖ 🖥', callback_data: 'list_delete_srv' }
  ]);
}

// Kirim edit message
await conn.editMessageMedia({
  type: "photo",
  media: global.links,
  caption,
  parse_mode: "Markdown"
}, {
  chat_id: chatId,
  message_id: msgId,
  reply_markup: { inline_keyboard: keyboard }
});

  }

  // --- List Servers milik user ---
  if (data.startsWith('list_user_')) {
    const nomor = Number(data.split('_')[2]);
    const user = listData[nomor]?.attributes;
    if (!user) return await conn.answerCallbackQuery(callback.id, { text: "User tidak ditemukan!" });

    const allServersRes = await fetch(`${domain}/api/application/servers`, {
      method: 'GET',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json', Authorization: `Bearer ${apikey}` }
    });
    const allServers = await allServersRes.json();
    const userServers = (allServers.data || []).filter(s => s.attributes.user === user.id);

// Tombol server individual
const keyboard = userServers.map(srv => [{ text: srv.attributes.name, callback_data: `delete_srv_${srv.attributes.id}_${user.id}` }]);

// Tombol aksi
const actionButtons = [{ text: '❌ Delete User', callback_data: `delete_user_${user.id}` }];

// Tambahkan Delete All hanya jika user punya lebih dari 1 server
if (userServers.length > 1) {
  actionButtons.push({ text: '🗑 Delete All', callback_data: `delete_all_srv_${user.id}` });
}

// Tambahkan tombol aksi dan navigasi
keyboard.push(actionButtons);
keyboard.push([{ text: '🔙 Back', callback_data: 'list_user' }, { text: '❌ Close', callback_data: 'menu_delete' }]);

// Caption
const caption = `📋 Server milik user: ${user.username}\n🆔 ID: ${user.id}\n\nPilih server untuk dihapus:`;

// Kirim edit message
await conn.editMessageMedia({
  type: "photo",
  media: global.links,
  caption,
  parse_mode: "Markdown"
}, { chat_id: chatId, message_id: msgId, reply_markup: { inline_keyboard: keyboard } });

  }

  // --- Delete single server ---
  if (data.startsWith('delete_srv_')) {
    const [_, __, serverId, userId] = data.split('_');
    await fetch(`${domain}/api/application/servers/${serverId}`, { method: 'DELETE', headers: { Accept: 'application/json', 'Content-Type': 'application/json', Authorization: `Bearer ${apikey}` } });
    await conn.answerCallbackQuery(callback.id, { text: '✅ Server berhasil dihapus!' });
    callback.data = `list_user_${listData.findIndex(u => u.attributes.id == userId)}`;
  }

  // --- Delete all servers ---
  if (data.startsWith('delete_all_srv_')) {
    const userId = data.split('_')[3];
    const allServersRes = await fetch(`${domain}/api/application/servers`, { method: 'GET', headers: { Accept: 'application/json', 'Content-Type': 'application/json', Authorization: `Bearer ${apikey}` } });
    const allServers = await allServersRes.json();
    const userServers = (allServers.data || []).filter(s => s.attributes.user == userId);
    for (const srv of userServers) {
      await fetch(`${domain}/api/application/servers/${srv.attributes.id}`, { method: 'DELETE', headers: { Accept: 'application/json', 'Content-Type': 'application/json', Authorization: `Bearer ${apikey}` } });
    }
    await conn.answerCallbackQuery(callback.id, { text: '✅ Semua server user berhasil dihapus!' });
    callback.data = 'list_user';
  }

  // --- Delete user ---
  if (data.startsWith('delete_user_')) {
    const userId = data.split('_')[2];
    await fetch(`${domain}/api/application/users/${userId}`, { method: 'DELETE', headers: { Accept: 'application/json', 'Content-Type': 'application/json', Authorization: `Bearer ${apikey}` } });
    await conn.answerCallbackQuery(callback.id, { text: `✅ User berhasil dihapus!` });
    callback.data = 'list_user';
  }
} else if (data && data.startsWith('crate_')) {
  try {
    // Hanya owner atau reseller/premium
    if (!isOwner && !isPrem) {
      return await conn.answerCallbackQuery(callback.id, { text: "Khusus owner/reseller!" });
    }
    if (data.startsWith("crate_adp_")) {
      try {
      const srvIndex = Number(data.split("_")[2]);
      const userCache = conn._createCache?.[m.sender];
      if (!userCache) {
        return await conn.answerCallbackQuery(callback.id, { text: "⚠️ Tidak ada sesi aktif untuk Anda!" });
      }
  
      const { username, idTelegram } = userCache;
      console.log(idTelegram)
      const cpanels = Object.keys(global.cpanel || {});
      const tldnya = cpanels[srvIndex - 1];
      if (!tldnya) {
        return await conn.answerCallbackQuery(callback.id, { text: "Server tidak ditemukan!" });
      }
  
      const panelData = global.cpanel[tldnya];
      if (!panelData) {
        return await conn.answerCallbackQuery(callback.id, { text: "Data panel tidak ditemukan!" });
      }
  
      const { apikey } = panelData;
      const domain = tldnya;
      const email = `${username}@adp.com`;
      const name = `${username.charAt(0).toUpperCase() + username.slice(1)}`;
      const password = global.getRandom();
      await conn.answerCallbackQuery(callback.id, { text: "🔧 Membuat Admin Panel..." });
      
    // === Create User ===
    const createUserRes = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`,
      },
      body: JSON.stringify({ email, username, first_name: name, last_name: "Admin", root_admin: true, language: "en", password }),
    });
    const userRes = await createUserRes.json();
    if (userRes.errors) {
      await conn.deleteMessage(chatId, msgId).catch(() => {
        conn.sendMessage(chatId, "❌ Tidak bisa hapus pesan (mungkin sudah dihapus atau tidak ada izin).")
      })
      console.log("Error create Admin:", userRes.errors);
      m.reply(JSON.stringify(userRes.errors[0], null, 2));
      await conn.answerCallbackQuery(callback.id, { text: `⚠️ Error` })
      return;
    }
    const user = userRes.attributes;
        await conn.deleteMessage(chatId, msgId).catch(() => {
      conn.sendMessage(chatId, "❌ Tidak bisa hapus pesan (mungkin sudah dihapus atau tidak ada izin).")
    })
    const teks = `
   ✅ <b>Berhasil membuat akun panel</b>
    
    🆔 <b>Users ID:</b> <code>${user.id}</code>
    👤 <b>Username:</b> <code>${username}</code>
    🔐 <b>Password:</b> <code>${password}</code>
    🌐 <b>Panel:</b> <code>${domain}</code>
    🗓️ <b>Tanggal:</b> ${new Date().toLocaleString()}

    ⚠️ <b>Rules pembelian admin panel:</b>
    - <b>Masa aktif 30 hari</b>
    - <b>Data bersifat pribadi, mohon disimpan dengan aman</b>
    - <b>Garansi berlaku 15 hari (1x replace)</b>
    - <b>Jangan Rusuh</b>
    - <b>Jangan Colong Script orang atau delet panel orang tanpa sebab</b>
    - <b>Klaim garansi wajib menyertakan</b> <b>bukti chat pembelian</b>
    `;
    
        // Kirim ke user
        try {
          if (!global.FelixUserBot?.sendMessage) {
            await conn.sendMessage(idTelegram, `<blockquote>${teks}</blockquote>`, { parse_mode: "HTML" });
          } else {
            await global.FelixUserBot.sendMessage(idTelegram, { message: teks, parseMode: "HTML" });
          }
        } catch {
          console.log(idTelegram)
          await conn.sendMessage(idTelegram, `<blockquote>${teks}</blockquote>`, { parse_mode: "HTML" });
        }
    
        await conn.answerCallbackQuery(callback.id, { text: `✅ Admin berhasil dibuat! Username: ${username}` });
        delete conn._createCache[m.sender];
    
      } catch (err) {
        console.error("Error create Admin:", err);
        await conn.answerCallbackQuery(callback.id, { text: "❌ Gagal membuat Admin!" });
        try {
          await conn.answerCallbackQuery(callback.id, { text: "❌ Gagal membuat Admin!" });
        } catch {}
      }
    }
    if (data.startsWith("crate_srvx_")) {
      const srvIndex = Number(data.split("_")[2]);
      const userCache = conn._createCache?.[m.sender];
      if (!userCache) return await conn.answerCallbackQuery(callback.id, { text: "⚠️ Tidak ada sesi aktif!" });
      await conn.deleteMessage(chatId, msgId).catch(() => {
        conn.sendMessage(chatId, "❌ Tidak bisa hapus pesan (mungkin sudah dihapus atau tidak ada izin).")
      })
      const cpanels = Object.keys(global.cpanel || {});
      const tldnya = cpanels[srvIndex - 1];
      if (!tldnya) return await conn.answerCallbackQuery(callback.id, { text: "Server tidak ditemukan!" });
    
      
      const sizes = ["1gb","2gb","3gb","4gb","5gb","6gb","7gb","8gb","9gb","10gb","unli"];
      const keyboard = sizes.map(size => [{
        text: size.toUpperCase(),
        callback_data: `crate_server_${tldnya}_${size}`
      }]);
      
      const teks = `<b>🛠 Pilih ukuran server untuk:</b>\n👤 <b>${userCache.username}</b>\n🆔 <code>${userCache.userid}</code>`;
      
      // Perhatikan parse_mode di luar reply_markup
      await conn.sendMessage(m.chat, teks, {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: "HTML"
      });
    }
    
    if (data.startsWith("crate_server_")) {
      const parts = data.split("_");
      const tldnya = parts[2];
      const size = parts[3];
      const userCache = conn._createCache?.[m.sender];
      if (!userCache) return await conn.answerCallbackQuery(callback.id, { text: "⚠️ Tidak ada sesi aktif!" });
    
      const { username, userid } = userCache;
      const panelData = global.cpanel[tldnya];
      if (!panelData) return await conn.answerCallbackQuery(callback.id, { text: "Data panel tidak ditemukan!" });
    
      const { apikey, nestid, egg, loc } = panelData;
      const domain = tldnya;
      const name = `${username.charAt(0).toUpperCase() + username.slice(1)} Server`;
    
      const resourceMap = {
        "1gb": { ram: 1000, disk: 1000, cpu: 40 },
        "2gb": { ram: 2000, disk: 1000, cpu: 60 },
        "3gb": { ram: 3000, disk: 2000, cpu: 80 },
        "4gb": { ram: 4000, disk: 2000, cpu: 100 },
        "5gb": { ram: 5000, disk: 3000, cpu: 120 },
        "6gb": { ram: 6000, disk: 3000, cpu: 140 },
        "7gb": { ram: 7000, disk: 4000, cpu: 160 },
        "8gb": { ram: 8000, disk: 4000, cpu: 180 },
        "9gb": { ram: 9000, disk: 5000, cpu: 200 },
        "10gb": { ram: 10000, disk: 5000, cpu: 220 },
        "unli": { ram: 0, disk: 0, cpu: 0 },
      };
      const { ram, disk, cpu } = resourceMap[size] || { ram: 0, disk: 0, cpu: 0 };
    
      // Ambil Egg info
      const eggRes = await fetch(`${domain}/api/application/nests/${nestid}/eggs/${egg}`, {
        method: "GET",
        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${apikey}` }
      });
      const eggData = await eggRes.json();
      const docker_image = eggData.attributes.docker_image;
      const startup_cmd = eggData.attributes.startup;
    
      // Create server
      const createServerRes = await fetch(`${domain}/api/application/servers`, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${apikey}` },
        body: JSON.stringify({
          name,
          user: userid,
          egg: parseInt(egg),
          docker_image,
          startup: startup_cmd,
          environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
          limits: { memory: ram, swap: 0, disk, io: 500, cpu },
          feature_limits: { databases: 5, backups: 5, allocations: 5 },
          deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
        })
      });
    
      await conn.answerCallbackQuery(callback.id, { text: "🔧 Membuat Server Panel..." });
      const serverRes = await createServerRes.json();
      if (serverRes.errors) {
        await conn.deleteMessage(chatId, msgId).catch(() => {
          conn.sendMessage(chatId, "❌ Tidak bisa hapus pesan (mungkin sudah dihapus atau tidak ada izin).")
        })
        console.log("Error create server:", serverRes.errors);
        await conn.answerCallbackQuery(callback.id, { text: `❌ Gagal membuat server!` });
        return;
      }
    
      const server = serverRes.attributes;
      const formatSpec = (val) => val === 0 ? "Unlimited" : val >= 1024 ? `${Math.floor(val/1024)} GB` : `${val} MB`;
      const sram = formatSpec(server.limits.memory);
      const sdisk = formatSpec(server.limits.disk);
      const scpu = server.limits.cpu === 0 ? "Unlimited" : `${server.limits.cpu}%`;
    
      const teks = `
    ✅ <b>Berhasil membuat Server Panel</b>
    📡 <b>Server ID:</b> <code>${server.id}</code>
    🗓️ <b>Tanggal:</b> ${new Date().toLocaleString()}
    ⚙️ <b>Spesifikasi:</b>
    RAM: ${sram}
    Disk: ${sdisk}
    CPU: ${scpu}`;
    
      try {
        if (!global.FelixUserBot?.sendMessage) {
          await conn.sendMessage(m.chat, `<blockquote>${teks}</blockquote>`, { parse_mode: "HTML" });
        } else {
          await global.FelixUserBot.sendMessage(m.chat, { message: teks, parseMode: "HTML" });
        }
      } catch {
        await conn.sendMessage(m.chat, `<blockquote>${teks}</blockquote>`, { parse_mode: "HTML" });
      }
      await conn.deleteMessage(chatId, msgId).catch(() => {
        conn.sendMessage(chatId, "❌ Tidak bisa hapus pesan (mungkin sudah dihapus atau tidak ada izin).")
      })
      await conn.answerCallbackQuery(callback.id, { text: `✅ Panel berhasil dibuat! Username: ${username}` });
      delete conn._createCache[sendercek];
    }    
    // Hanya handle create server
    if (data.startsWith("crate_srv_")) {
    
    const srvIndex = Number(data.split("_")[2]);
    const userCache = conn._createCache?.[m.sender];
    if (!userCache) {
      return await conn.answerCallbackQuery(callback.id, { text: "⚠️ Tidak ada sesi aktif untuk Anda!" });
    }

    const { username, idTelegram, command } = userCache;
    console.log(idTelegram)
    const cpanels = Object.keys(global.cpanel || {});
    const tldnya = cpanels[srvIndex - 1];
    if (!tldnya) {
      return await conn.answerCallbackQuery(callback.id, { text: "Server tidak ditemukan!" });
    }

    const panelData = global.cpanel[tldnya];
    if (!panelData) {
      return await conn.answerCallbackQuery(callback.id, { text: "Data panel tidak ditemukan!" });
    }

    const { apikey, nestid, egg, loc } = panelData;
    const domain = tldnya;
    const email = `${username}@gmail.com`;
    const name = `${username.charAt(0).toUpperCase() + username.slice(1)} Server`;
    const password = global.getRandom();

    await conn.answerCallbackQuery(callback.id, { text: "🔧 Membuat panel..." });

    // Mapping resources
    const resourceMap = {
      "1gb": { ram: 1000, disk: 1000, cpu: 40 },
      "2gb": { ram: 2000, disk: 1000, cpu: 60 },
      "3gb": { ram: 3000, disk: 2000, cpu: 80 },
      "4gb": { ram: 4000, disk: 2000, cpu: 100 },
      "5gb": { ram: 5000, disk: 3000, cpu: 120 },
      "6gb": { ram: 6000, disk: 3000, cpu: 140 },
      "7gb": { ram: 7000, disk: 4000, cpu: 160 },
      "8gb": { ram: 8000, disk: 4000, cpu: 180 },
      "9gb": { ram: 9000, disk: 5000, cpu: 200 },
      "10gb": { ram: 10000, disk: 5000, cpu: 220 },
      "unli": { ram: 0, disk: 0, cpu: 0 },
    };
    const { ram, disk, cpu } = resourceMap[command] || { ram: 0, disk: 0, cpu: 0 };

    // === Create User ===
    const createUserRes = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`,
      },
      body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password }),
    });
    const userRes = await createUserRes.json();
    if (userRes.errors) {
      await conn.deleteMessage(chatId, msgId).catch(() => {
        conn.sendMessage(chatId, "❌ Tidak bisa hapus pesan (mungkin sudah dihapus atau tidak ada izin).")
      })
      console.log("Error create User:", userRes.errors);
      m.reply(JSON.stringify(userRes.errors[0], null, 2));
      await conn.answerCallbackQuery(callback.id, { text: `⚠️ Error` })
      return;
    }
    const user = userRes.attributes;

    // === Get Egg Info ===
    const eggRes = await fetch(`${domain}/api/application/nests/${nestid}/eggs/${egg}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`,
      },
    });
    const eggData = await eggRes.json();
    const docker_image = eggData.attributes.docker_image;
    const startup_cmd = eggData.attributes.startup;

    // === Create Server ===
    const createServerRes = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apikey}`,
      },
      body: JSON.stringify({
        name,
        user: user.id,
        egg: parseInt(egg),
        docker_image,
        startup: startup_cmd,
        environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
        limits: { memory: ram, swap: 0, disk, io: 500, cpu },
        feature_limits: { databases: 5, backups: 5, allocations: 5 },
        deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
      }),
    });

    const serverRes = await createServerRes.json();
     if (serverRes.errors) {
      await conn.deleteMessage(chatId, msgId).catch(() => {
        conn.sendMessage(chatId, "❌ Tidak bisa hapus pesan (mungkin sudah dihapus atau tidak ada izin).")
      })
      console.log("Error create server:", serverRes.errors);
      m.reply(JSON.stringify(serverRes.errors[0], null, 2));
      await conn.answerCallbackQuery(callback.id, { text: `⚠️ Error` })
      return;
    }
    const server = serverRes.attributes;

    // Format server specs
    const formatSpec = (val) => val === 0 ? "Unlimited" : val >= 1024 ? `${Math.floor(val/1024)} GB` : `${val} MB`;
    const sram = formatSpec(server.limits.memory);
    const sdisk = formatSpec(server.limits.disk);
    const scpu = server.limits.cpu === 0 ? "Unlimited" : `${server.limits.cpu}%`;
    await conn.deleteMessage(chatId, msgId).catch(() => {
      conn.sendMessage(chatId, "❌ Tidak bisa hapus pesan (mungkin sudah dihapus atau tidak ada izin).")
    })
    // Text result
    const teks = `
✅ <b>Berhasil membuat akun panel</b>

🆔 <b>Users ID:</b> <code>${user.id}</code>
📡 <b>Server ID:</b> <code>${server.id}</code>
👤 <b>Username:</b> <code>${username}</code>
🔐 <b>Password:</b> <code>${password}</code>
🌐 <b>Panel:</b> <code>${domain}</code>
🗓️ <b>Tanggal:</b> ${new Date().toLocaleString()}

⚙️ <b>Spesifikasi:</b>
RAM: ${sram}
Disk: ${sdisk}
CPU: ${scpu}

⚠️ <b>Rules pembelian panel:</b>
- <b>Masa aktif 30 hari</b>
- <b>Data bersifat pribadi, mohon disimpan dengan aman</b>
- <b>Garansi berlaku 15 hari (1x replace)</b>
- <b>Klaim garansi wajib menyertakan</b> <b>bukti chat pembelian</b>`;

    // Kirim ke user
    try {
      if (!global.FelixUserBot?.sendMessage) {
        await conn.sendMessage(idTelegram, `<blockquote>${teks}</blockquote>`, { parse_mode: "HTML" });
      } else {
        await global.FelixUserBot.sendMessage(idTelegram, { message: teks, parseMode: "HTML" });
      }
    } catch {
      console.log(idTelegram)
      await conn.sendMessage(idTelegram, `<blockquote>${teks}</blockquote>`, { parse_mode: "HTML" });
    }

    await conn.answerCallbackQuery(callback.id, { text: `✅ Panel berhasil dibuat! Username: ${username}` });
    
    console.log(idTelegram)
    delete conn._createCache[sendercek];
  }
  } catch (err) {
    console.error("Error create server:", err);
    await conn.answerCallbackQuery(callback.id, { text: "❌ Gagal membuat panel!" });
    try {
      await conn.answerCallbackQuery(callback.id, { text: "❌ Gagal membuat panel!" });
    } catch {}
  }
} else if (data && data.startsWith('sub_')) {
  if (!isOwner && !isReseller) return conn.answerCallbackQuery(callback.id, { text: "Khusus owner/reseller!" });
  // --- SUBDOMAIN HANDLER ---
  if (data.startsWith("sub_srv_")) {
    if (!conn._srvCache) conn._srvCache = {};

    const index = parseInt(data.replace("sub_srv_", ""));
    const domainKeys = Object.keys(global.subdomain);
    const selectedDomain = domainKeys[index - 1];
    if (!selectedDomain) return conn.answerCallbackQuery(callback.id, { text: "Server tidak ditemukan!" });

    const { apitoken, zone } = global.subdomain[selectedDomain];
    const res = await axios.get(`https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`, { headers: { Authorization: `Bearer ${apitoken}`, "Content-Type": "application/json" } });
    const records = res.data.result || [];
    conn._srvCache[chatId] = { records, index: 0, apitoken, zone, domain: selectedDomain };

    return await tampilkanDaftarDomain(conn, chatId, msgId, selectedDomain);

  } else if (data === "sub_next" || data === "sub_back") {
    const cache = conn._srvCache[chatId]; if (!cache) return conn.answerCallbackQuery(callback.id, { text: "Cache kosong!" });
    const totalPages = Math.ceil(cache.records.length / 10);
    cache.index = data === "sub_next" ? (cache.index + 1) % totalPages : (cache.index - 1 + totalPages) % totalPages;
    return await tampilkanDaftarDomain(conn, chatId, msgId, cache.domain);

  } else if (data.startsWith("sub_dom_")) {
    if (!isROwner) return conn.answerCallbackQuery(callback.id, { text: "Hanya root owner yang bisa!" });
    const parts = data.split("_"); const idxStr = parts.pop(); const domain = parts.slice(2).join("_");
    const cache = conn._srvCache[chatId]; if (!cache) return conn.answerCallbackQuery(callback.id, { text: "Cache kosong!" });
    const index = parseInt(idxStr); const record = cache.records[index];
    if (!record) return conn.answerCallbackQuery(callback.id, { text: "Subdomain tidak ditemukan!" });

    const caption = `🌐 *Detail Subdomain*\n\n🏷️ *Nama:* ${record.name}\n📄 *Type:* ${record.type}\n📶 *Content:* ${record.content}\n\nPilih tindakan:`;
    const reply_markup = {
      inline_keyboard: [
        [{ text: "🔍 Cek Data", callback_data: `sub_cek_${domain}_${index}` }, { text: "🗑 Hapus", callback_data: `sub_del_${domain}_${index}` }],
        [{ text: "↩️ Kembali", callback_data: "sub_back" }, { text: "❎", callback_data: "menu_delete" }]
      ]
    };
    await conn.editMessageText(caption, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup });

  } else if (data === "sub_back") {
    const cache = conn._srvCache[chatId]; if (!cache) return conn.answerCallbackQuery(callback.id, { text: "Cache kosong!" });
    return await tampilkanDaftarDomain(conn, chatId, msgId, cache.domain);

  } else if (data.startsWith("sub_del_")) {
    if (!isROwner) return conn.answerCallbackQuery(callback.id, { text: "Hanya root owner yang bisa!" });
    const parts = data.split("_"); const idxStr = parts.pop(); const domain = parts.slice(2).join("_");
    const cache = conn._srvCache[chatId]; if (!cache) return conn.answerCallbackQuery(callback.id, { text: "Cache kosong!" });
    const index = parseInt(idxStr); const record = cache.records[index];
    if (!record) return conn.answerCallbackQuery(callback.id, { text: "Subdomain tidak ditemukan!" });

    await conn.answerCallbackQuery(callback.id, { text: "Menghapus..." });
    try {
      await axios.delete(`https://api.cloudflare.com/client/v4/zones/${cache.zone}/dns_records/${record.id}`, { headers: { Authorization: `Bearer ${cache.apitoken}`, "Content-Type": "application/json" } });
      cache.records = cache.records.filter((r) => r.id !== record.id);
      return await tampilkanDaftarDomain(conn, chatId, msgId, cache.domain);
    } catch (e) { console.error(e); return await conn.answerCallbackQuery(callback.id, { text: "❌ Gagal hapus!", show_alert: true }); }

  } else if (data.startsWith("sub_cek_")) {
    if (!isROwner) return conn.answerCallbackQuery(callback.id, { text: "Hanya root owner yang bisa!" });
    const parts = data.split("_"); const idxStr = parts.pop(); const domain = parts.slice(2).join("_");
    const cache = conn._srvCache[chatId]; if (!cache) return conn.answerCallbackQuery(callback.id, { text: "Cache kosong!" });
    const index = parseInt(idxStr); const record = cache.records[index];
    if (!record) return conn.answerCallbackQuery(callback.id, { text: "Subdomain tidak ditemukan!" });

    const caption = `🔍 *Cek Data Domain*\n\n🌐 *Nama:* ${record.name}\n📄 *Type:* ${record.type}\n📶 *Content:* ${record.content}\n🕒 *TTL:* ${record.ttl}`;
    const reply_markup = { inline_keyboard: [[{ text: "↩️ Kembali", callback_data: "sub_back" }]] };
    try { await conn.editMessageText(caption, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup }); }
    catch { await conn.editMessageCaption(caption, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup }); }

  }

} else if (data && data.startsWith('menu_')) {
 
  const pluginDir = path.join(__dirname, "plugins"); const plugins = [];
  fs.readdirSync(pluginDir).forEach(file => { if (file.endsWith(".js")) { try { delete require.cache[require.resolve(path.join(pluginDir, file))]; const plugin = require(path.join(pluginDir, file)); if (plugin.help && plugin.tags) plugins.push(plugin); } catch (e) { console.error(e); } } });
  const categories = {}; plugins.forEach(plugin => { plugin.tags.forEach(tag => { if (!categories[tag]) categories[tag] = []; categories[tag].push(...plugin.help) }) });

  // init caches on conn
  if (!conn._pageCache) conn._pageCache = {};
  if (!conn._offsetCache) conn._offsetCache = {};
  if (!conn._menuViewIndex) conn._menuViewIndex = {};
  const categoryNames = {
    reseller: "💠 RESELLER",
    subdomain: "🌐 SUBDOMAIN",
    main: "🎯 MAIN",
    tools: "⚙️ TOOLS",
    downloader: "💫 DOWNLOADER",
    fun: "🎪 FUN",
    group: "👾 GROUP",
    owner: "👤 OWNER",
    admin: "🛡️ ADMIN",
    premium: "⭐ PREMIUM",
    info: "🎐 INFO",
    advanced: "⚡ ADVANCED",
  };

  // pages = kategori yang ada (urut berdasarkan categoryNames order)
  const pages = [
    ...Object.keys(categoryNames).filter(k => categories[k] && categories[k].length > 0),
    ...Object.keys(categories).filter(k => !categoryNames[k] && categories[k].length > 0)
  ];
  let catIndex = Number(conn._pageCache[chatId] || 0);
  let offset = Number(conn._offsetCache[chatId] || 0);
  const MAX_PER_PAGE = 15;
  if (!pages || pages.length === 0) {
    try { await conn.answerCallbackQuery(callback.id, { text: "❌ Tidak ada menu ditemukan." }); } catch { }
    return;
  }
  if (data === "menu_nextcat") {
    catIndex = (catIndex + 1) % pages.length;
    offset = 0;
  } else if (data === "menu_backcat") {
    catIndex = (catIndex - 1 + pages.length) % pages.length;
    offset = 0;
  }

  // page navigation within category
  if (data === "menu_next") offset += MAX_PER_PAGE;
  if (data === "menu_back") offset -= MAX_PER_PAGE;
  if (offset < 0) offset = 0;
  if (data === "menu_delete") {
    await conn.deleteMessage(chatId, msgId).catch(() => {
      conn.sendMessage(chatId, "❌ Tidak bisa hapus pesan (mungkin sudah dihapus atau tidak ada izin).")
    })
    await conn.answerCallbackQuery(callback.id, { text: "Pesan dihapus!" })
    return
  }
  // edit view (only root owner)
  if (data === "menu_edit") {
    if (!isROwner) {
      try { await conn.answerCallbackQuery(callback.id, { text: "Hanya root owner yang bisa mengedit menu!" }); } catch { }
      return;
    }
    conn._menuViewIndex[chatId] = ((conn._menuViewIndex[chatId] || 0) + 1) % 5;
    try { await conn.answerCallbackQuery(callback.id, { text: `✏️ Ganti tampilan: ${conn._menuViewIndex[chatId] + 1}/5` }); } catch { }
    // After changing view, continue to render updated caption below
  }

  // compute current category & commands
  const currentKey = pages[catIndex];
  const commands = categories[currentKey] || [];
  const categoryTitle = categoryNames[currentKey] || currentKey || "Menu";
  const sliced = commands.slice(offset, offset + MAX_PER_PAGE);
  const hasNextPage = offset + MAX_PER_PAGE < commands.length;
  const hasPrevPage = offset > 0;
  // save positions back to cache
  conn._pageCache[chatId] = catIndex;
  conn._offsetCache[chatId] = offset;

  // build caption based on view
  const currentView = conn._menuViewIndex[chatId] || 0;
  let caption = `📚 *${categoryTitle}*\n\n`;
  if (!sliced.length) caption += "_(Tidak ada perintah di halaman ini)_";
  else {
    switch (currentView) {
      case 0:
        caption += sliced.map(cmd => `• *${cmd}*`).join("\n");
        break;
      case 1:
        caption += sliced.map(cmd => `💠 *${cmd}*`).join("\n");
        break;
      case 2:
        caption += sliced.map((cmd, i) => `${i + 1 + offset}. *${cmd}*`).join("\n");
        break;
      case 3:
        caption += sliced.map(cmd => `• *${cmd}*`).join("\n");
        break;
      case 4:
        caption += sliced.map(cmd => `🏷️ *${cmd}*`).join("\n");
        break;
      default:
        caption += sliced.map(cmd => `*${cmd}*`).join("\n");
    }
  }

  // build navigation rows
  // build navigation rows
  const navRow = [];
  if (hasPrevPage) navRow.push({ text: "⬅️ Prev", callback_data: "menu_back" });
  if (hasNextPage) navRow.push({ text: "Next ➡️", callback_data: "menu_next" });

  // hanya tampilkan baris navRow kalau ada
  const keyboard = [];
  if (navRow.length) keyboard.push(navRow);

  keyboard.push([
    { text: "⬅️", callback_data: "menu_backcat" },
    { text: "✖️", callback_data: "menu_delete" },
    { text: "➡️", callback_data: "menu_nextcat" },
  ]);

  // tombol edit hanya untuk root owner
  if (isROwner) {
    const currentView = conn._menuViewIndex[chatId] || 0;
    keyboard.push([{ text: `🖊 Tampilan ${currentView + 1}/5`, callback_data: "menu_edit" }]);
  }

  const reply_markup = { inline_keyboard: keyboard };

  // try edit as media (photo), else caption, else text
  try {
    if (typeof conn.editMessageMedia === "function" && global.links) {
      await conn.editMessageMedia({
        type: "photo",
        media: global.links,
        caption,
        parse_mode: "Markdown"
      }, {
        chat_id: chatId,
        message_id: msgId,
        reply_markup
      });
    } else if (typeof conn.editMessageCaption === "function") {
      await conn.editMessageCaption(chatId, msgId, caption, {
        parse_mode: "Markdown",
        reply_markup
      });
    } else if (typeof conn.editMessageText === "function") {
      await conn.editMessageText(chatId, msgId, caption, {
        parse_mode: "Markdown",
        reply_markup
      });
    } else {
      // fallback: send new message (if editing not supported)
      await conn.sendMessage(chatId, { text: caption, reply_markup });
    }
  } catch (e) {
    // final fallback: try edit caption/text separately and swallow errors
    try {
      if (typeof conn.editMessageCaption === "function") {
        await conn.editMessageCaption(chatId, msgId, caption, {
          parse_mode: "Markdown",
          reply_markup
        });
      } else if (typeof conn.editMessageText === "function") {
        await conn.editMessageText(chatId, msgId, caption, {
          parse_mode: "Markdown",
          reply_markup
        });
      }
    } catch (err) {
      console.error("Edit message gagal:", err);
    }
  }
}

  // ======== FUNGSI TAMBAHAN ========
  async function tampilkanDaftarDomain(conn, chatId, msgId, domain) {
    const cache = conn._srvCache[chatId];
    if (!cache) return;
    const { records, index } = cache;
    const perPage = 10;
    const totalPages = Math.ceil(records.length / perPage);
    const slice = records.slice(index * perPage, (index + 1) * perPage);

    let caption = `🌐 *Daftar Subdomain* untuk ${domain}\n\n`;
    slice.forEach((r, i) => {
      const num = index * perPage + i + 1;
      caption += `${num}. ${r.name}\n`;
    });
    caption += `\n📄 Halaman ${index + 1}/${totalPages}`;

    const reply_markup = {
      inline_keyboard: [
        ...slice.map((r, i) => {
          const nomor = index * perPage + i;
          return [{ text: r.name, callback_data: `sub_dom_${domain}_${nomor}` }];
        }),
        [
          { text: "⏮️ Back", callback_data: "sub_back" },
          { text: "❎", callback_data: "menu_delete" },
          { text: "Next ⏩", callback_data: "sub_next" },
        ],
      ],
    };

    try {
      await conn.editMessageText(caption, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup });
    } catch {
      await conn.editMessageCaption(caption, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup });
    }
  }

    
    if (m && typeof handler?.handler === "function") {
      await handler.handler.call(conn, m)
    } else {
      console.error("Handler untuk callback tidak ditemukan atau bukan fungsi.")
    }
  } catch (err) {
    console.error("❌ Error di callback_query:", err)
    try {
      await conn.answerCallbackQuery(callback.id, { text: "Terjadi kesalahan!" })
    } catch { }
  }
})
// === Message handler utama Telegram Bot ===
conn.on('message', async (msg) => {
  try {
    const m = smsg(msg);
    if (!m) return;

    // Panggil handler, userbot global.FelixUserBot bisa diakses via global.global.FelixUserBot
    await handler.handler.call(conn, m);
  } catch (e) {
    console.error('Error di handler message:', e);
  }
})
// === Event: Anggota baru masuk ===
conn.on('new_chat_members', async (msg) => {
  try {
    await handler.participantsUpdate.call(conn, msg)
  } catch (e) {
    console.error('Error handling new_chat_members:', e)
  }
})

// === Event: Anggota keluar ===
conn.on('left_chat_member', async (msg) => {
  try {
    await handler.participantsUpdate.call(conn, msg)
  } catch (e) {
    console.error('Error handling left_chat_member:', e)
  }
})

// === Event: Bot ditambahkan/dikeluarkan dari grup ===
conn.on('my_chat_member', async (msg) => {
  try {
    await handler.participantsUpdate.call(conn, msg)
  } catch (e) {
    console.error('Error handling my_chat_member:', e)
  }
})

async function checkMediaSupport() {
  const checks = await Promise.all(
    [
      child_process.spawn("ffmpeg"),
      child_process.spawn("ffprobe"),
      child_process.spawn("convert"),
      child_process.spawn("magick"),
      child_process.spawn("gm"),
    ].map((spawn) => {
      return Promise.race([
        new Promise((resolve) => {
          spawn.on("close", (exitCode) => resolve(exitCode !== 127))
        }),
        new Promise((resolve) => {
          spawn.on("error", () => resolve(false))
        }),
      ])
    }),
  )

  const [ffmpeg, ffprobe, convert, magick, gm] = checks
  global.support = { ffmpeg, ffprobe, convert, magick, gm }

  if (!global.support.ffmpeg) {
    conn.logger.warn("Please install FFMPEG for sending VIDEOS (sudo apt install ffmpeg)")
  }

  if (!global.support.magick) {
    conn.logger.warn("Please install ImageMagick for sending IMAGES (sudo apt install imagemagick)")
  }

}

async function launchBot() {
  let retryCount = 0
  const maxRetries = 5
  const retryDelay = 5000

  while (retryCount < maxRetries) {
    try {
      conn.logger.info("Bot launched successfully")
      break
    } catch (err) {
      retryCount++
      conn.logger.error(`Bot launch attempt ${retryCount} failed: ${err.message}`)

      if (err.code === 'ETIMEDOUT' || err.code === 'ENOTFOUND' || err.code === 'ECONNRESET') {
        if (retryCount < maxRetries) {
          conn.logger.info(`Retrying in ${retryDelay / 1000} seconds...`)
          await new Promise(resolve => setTimeout(resolve, retryDelay))
        } else {
          conn.logger.error("Max retries reached. Check your internet connection and conn token.")
        }
      } else {
        throw err
      }
    }
  }
}

checkMediaSupport()
  .then(() => conn.logger.info("Quick Test Done"))
  .then(() => launchBot())
  .catch(console.error)
process.once("SIGINT", () => {
  conn.stopPolling()
  conn.logger.warn("Bot stopped (SIGINT)")
})
process.once("SIGTERM", () => {
  conn.stopPolling()
  conn.logger.warn("Bot stopped (SIGTERM)")
})