const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const aiChat = require("../lib/openai.js");

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    if (!text)
      return m.reply(`📘 *Contoh:* ${usedPrefix + command} jelaskan apa itu javascript`);

    // Panggil AI
    const result = await aiChat("", text, "openai/gpt-oss-120b");

    // Jika hasil terlalu panjang, simpan sebagai file
    if (result.length > 3800) {
      const randomName = crypto.randomBytes(6).toString("hex");
      const fileName = `openai-${randomName}.js`;
      const savePath = path.join(__dirname, `../tmp/${fileName}`);

      // Simpan hasil ke file
      fs.writeFileSync(savePath, result, "utf-8");

      // Kirim file ke chat
      await conn.sendDocument(m.chat, savePath, {
        caption: `🧠 <b>Hasil OpenAI</b>\n\n📁 <code>${fileName}</code>\n\nKarena teks terlalu panjang, dikirim sebagai file.`,
        parse_mode: "HTML",
        reply_to_message_id: m.id,
      });

      // (opsional) hapus file setelah terkirim
      setTimeout(() => {
        if (fs.existsSync(savePath)) fs.unlinkSync(savePath);
      }, 10000);
    } else {
      // Kalau pendek, kirim langsung
      await m.reply(result);
    }
  } catch (err) {
    console.error("❌ Gagal menjalankan OpenAI:", err);
    m.reply(`❌ Terjadi kesalahan: ${err.message}`);
  }
};

handler.help = ["openai", "ai"];
handler.tags = ["tools", "ai"];
handler.command = /^(openai|ai)$/i;

module.exports = handler;
