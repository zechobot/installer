let handler = m => m;

handler.before = async function(m, {
 conn, isBotAdmin, isAdmin }) {
 try {
  if (!m || !m.isGroup) return true;

  // --- Init database ---
  if (!global.db) global.db = {
   data: {
    chats: {}
   }
  };
  if (!global.db.data.chats[m.chat]) {
   global.db.data.chats[m.chat] = {
    antiFoto: false,
    antiVideo: false,
    antiAudio: false,
    antiSticker: false,
    antiVoice: false,
   };
  }

  const chat = global.db.data.chats[m.chat];
  const mediaType = m.mediaType || m.mtype;

  // --- Mapping jenis media dan setting-nya ---
  const mediaRules = {
   photo: chat.antiFoto,
   video: chat.antiVideo,
   audio: chat.antiAudio,
   sticker: chat.antiSticker,
   voice: chat.antiVoice
  };

  // --- Cek apakah jenis media ini dilarang ---
  if (mediaRules[mediaType]) {
// --- Jika bot bukan admin, skip (tidak bisa hapus) ---
if (!isBotAdmin) {
  console.log("❌ Bot bukan admin, skip aksi anti-media.");
  return true;
}

// --- Jika user admin, skip (jangan hapus pesan admin) ---
if (isAdmin) {
  console.log("ℹ️ Pengirim adalah admin, lewati anti-media.");
  return true;
}
   console.log("✅ Bot admin & user bukan admin → lanjut hapus pesan.");
   const user = m.usertag || m.sender?.split("@")[0];
   const alertText = `
<blockquote>
🚨 <b>[ANTI ${mediaType.toUpperCase()}]</b>\n\n

👤 <b>Pelaku:</b> <a href="tg://user?id=${m.sender}">@${user}</a>
📛 <b>Status:</b> Pesan terdeteksi & akan dihapus
📷 <b>Jenis Media:</b> ${mediaType.toUpperCase()}

🛡️ Fitur ini aktif untuk menjaga kebersihan grup.
</blockquote>`;

   const summaryText = `
<blockquote>
🚫 <b>[ANTI ${mediaType.toUpperCase()}]</b>\n\n

Pesan dari <a href="tg://user?id=${m.sender}">@${user}</a> 
telah dihapus karena mengandung 
<b>${mediaType.toUpperCase()}</b> yang dilarang di grup ini.

✅ Tetap patuhi peraturan grup untuk menghindari tindakan lanjutan.
</blockquote>`;

    const sentMessage = await conn.sendMessage(
    m.chat, alertText, {
     parse_mode: "HTML",
    }
   );

   const chatreplay = sentMessage.chat.id;
   const msgreplay = sentMessage.message_id;
   // --- Hapus pesan ---
   try {
    await m.delete();
    setTimeout(async () => {
     await conn.editMessageText(summaryText, {
      chat_id: chatreplay,
      message_id: msgreplay,
      parse_mode: "HTML"
     });
     return true // skip hanya untuk non-admin
    }, 3000);
   } catch (e) {
    console.error(`[ANTI MEDIA] Gagal menghapus ${mediaType}:`, e.message);
   }
  }

 } catch (err) {
  console.error("Anti-Media Error:", err);
 }

 return true;
};

module.exports = handler;