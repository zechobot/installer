const axios = require("axios");

const handler = async (m, { conn, isOwner }) => {
  if (!isOwner) return m.reply("❌ Fitur ini hanya untuk Owner!");

  const sentMessage = await conn.sendMessage(m.chat, `<blockquote>⏳ Memeriksa penggunaan CPU semua server di semua panel...\n\nBatas CPU wajar: <b>70%</b>\nHarap tunggu beberapa detik...</blockquote>`,
    {
    parse_mode: "HTML"
  });
 
  let chatreplay = sentMessage.chat.id;
  let msgreplay = sentMessage.message_id;

  (async () => {
    try {
      const results = [];
      let totalDeleted = 0;

      const domains = Object.keys(global.cpanel);
      for (let i = 0; i < domains.length; i++) {
        const panelDomain = domains[i];
        const panelConfig = global.cpanel[panelDomain];
        const panelName = `Panel ${i + 1}`;

        results.push(`🧩 <b>${panelName}</b>\n🌐 <code>${panelDomain}</code>`);

        try {
          // Ambil semua server
          let allServers = [];
          let page = 1;
          let hasMore = true;

          while (hasMore) {
            const res = await axios.get(
              `${panelDomain}/api/application/servers?page=${page}`,
              {
                headers: {
                  Authorization: `Bearer ${panelConfig.apikey}`,
                  Accept: "application/json",
                },
              }
            );

            const data = res.data;
            allServers = allServers.concat(data.data);
            hasMore =
              data.meta.pagination.current_page <
              data.meta.pagination.total_pages;
            page++;
          }

          if (allServers.length === 0) {
            results.push("📭 Tidak ada server di panel ini.");
            continue;
          }

          // Cari server offline
          const offlineServers = [];

          for (const srv of allServers) {
            const { id, uuid, name } = srv.attributes;

            try {
              const resource = await axios.get(
                `${panelDomain}/api/client/servers/${uuid}/resources`,
                {
                  headers: {
                    Authorization: `Bearer ${panelConfig.capikey}`,
                  },
                  timeout: 5000,
                }
              );

              const state = resource.data.attributes.current_state;
              if (state === "offline" || state === "stopped") {
                offlineServers.push({ id, name, state });
              }
            } catch {
              // Jika gagal ambil status, abaikan
            }
          }

          if (offlineServers.length === 0) {
            results.push("✅ Tidak ada server offline di panel ini.\n");
            continue;
          }

          results.push(
            `🗑️ Menghapus ${offlineServers.length} server offline...`
          );

          // Hapus server offline
          for (const srv of offlineServers) {
            try {
              const del = await axios.delete(
                `${panelDomain}/api/application/servers/${srv.id}`,
                {
                  headers: {
                    Authorization: `Bearer ${panelConfig.apikey}`,
                  },
                }
              );

              if (del.status === 204) {
                totalDeleted++;
                results.push(
                  `• ✅ <b>${srv.name}</b> (ID: ${srv.id}) — ${srv.state}`
                );
              } else {
                results.push(
                  `• ❌ <b>${srv.name}</b> (ID: ${srv.id}) gagal (HTTP ${del.status})`
                );
              }
            } catch (err) {
              results.push(
                `• ⚠️ <b>${srv.name}</b> gagal dihapus: ${err.message}`
              );
            }
          }
        } catch (err) {
          results.push(
            `❌ Gagal mengakses panel ini: ${
              err.response ? `HTTP ${err.response.status}` : err.message
            }`
          );
        }

        results.push("───────────────────────────\n");
      }

      const summary = `<blockquote>🧹 <b>Hasil Penghapusan Server Offline</b>\n\n${results.join(
        "\n"
      )}\n📊 <b>Total Dihapus:</b> ${totalDeleted} server</blockquote>`;

      await conn.editMessageText(
        `${summary}`,
        {
          chat_id: chatreplay,
          message_id: msgreplay,
          parse_mode: "HTML"
        }
      );
    } catch (err) {
      
      await conn.editMessageText(
        `<blockquote>❌ Gagal menjalankan penghapusan: ${err.message}</blockquote>`,
        {
          chat_id: chatreplay,
          message_id: msgreplay,
          parse_mode: "HTML"
        }
      );
    }
  })();
};

handler.help = ["delsrvoff"];
handler.tags = ["owner"];
handler.command = /^delsrvoff$/i;
handler.owner = true;

module.exports = handler;
