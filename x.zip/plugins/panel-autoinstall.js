const axios = require("axios");
const { Client } = require("ssh2");
const ssh = new Client();

const handler = async (m, {
  conn,
  text,
  args,
  isOwner,
  isPrems,
  usedPrefix,
  command
 }) => {
  if (!isOwner && !isPrems) return m.reply("❌ Fitur ini khusus untuk Owner atau Premium!");

   const input = args.slice(1).join(" ").trim();
   const [ipVps, pwvps, namapanel, ramserver]  = input.split("|").map(s => s.trim());
   const domainIndex = Number(args[0]) - 1; // angka domain di depan
   const dom = Object.keys(subdomain);
   if (isNaN(domainIndex) || domainIndex < 0 || domainIndex >= dom.length) {
    // ❌ Jika nomor server salah, tampilkan daftar server yang tersedia
    let teks = `⚠️ *Pilih Server/Domain Panel yang tersedia!*\n\nDaftar Server yang tersedia:\n`;
    dom.forEach((domain, i) => teks += `*${i + 1}.* ${domain}\n`);
    teks += `\nGunakan format:\n*${usedPrefix + command} <nomor_server> ipVps|pwvps|namapanel|ramserver*\n\n`;
    teks += `Contoh:\n*${usedPrefix + command} 1 103.12.34.56|passwordvps|Panel|1024*`;
    return m.reply(teks, { parse_mode: 'Markdown' });
  }
  let vii = text.split("|");
  if (vii.length < 4) return await conn.sendMessage(
    m.chat, `<blockquote>❌ <b>Salah..</b>\n\nContoh:\n<b>${usedPrefix + command} ${args[0]} 103.12.34.56|passwordvps|Panel|1024</b></blockquote>`, {
     parse_mode: "HTML",
    }
   );
  const tld = dom[domainIndex];
  const connSettings = {
   host: ipVps,
   port: '22',
   username: 'root',
   password: pwvps
  };

  async function createSubdomain(name, ip) {
   try {
    const res = await axios.post(
     `https://api.cloudflare.com/client/v4/zones/${subdomain[tld].zone}/dns_records`, {
      type: "A",
      name: `${name}`,
      content: ip,
      ttl: 3600,
      proxied: false,
     }, {
      headers: {
       Authorization: `Bearer ${subdomain[tld].apitoken}`,
       "Content-Type": "application/json",
      },
     }
    );
    if (res.data.success)
     return {
      success: true,
      name: res.data.result.name
     };
    return {
     success: false,
     error: "Gagal membuat subdomain"
    };
   } catch (e) {
    return {
     success: false,
     error: e.response?.data?.errors?.[0]?.message || e.message
    };
   }
  }
 
  let progress = 0;
  let interval;
  const domainpanel = `${namapanel}.${tld}`;
  const domainnode = `node.${namapanel}.${tld}`;
  let sentMessage = await conn.sendMessage(
    m.chat, `<blockquote>⚙️ <b>Membuat subdomain panel dan node...</b>\n🛠️ Proses membuat subdomain panel sedang berjalan 🚀\n\n📡 IP VPS: ${ipVps}\n🌐 Domain Panel: ${domainpanel}\n🌐 Node Domain Panel: ${domainnode}\n\n⏳ Mohon tunggu sekitar 10–20 menit hingga proses instalasi selesai.\nAnda akan mendapatkan notifikasi setelah panel berhasil terinstal.</blockquote>`, {
     parse_mode: "HTML",
    }
   );
  let chatreplay = sentMessage.chat.id;
  let msgreplay = sentMessage.message_id;
  const sub1 = await createSubdomain(domainpanel, ipVps);
  const sub2 = await createSubdomain(domainnode, ipVps);
  if (!sub1.success || !sub2.success) return await conn.editMessageText(`<blockquote>❌ <b>Gagal membuat subdomain panel!</b>\nError: ${sub1.error || sub2.error}</blockquote>`, {
    chat_id: chatreplay,
    message_id: msgreplay,
    parse_mode: "HTML"
   });
  
  const passwordPanel = "Sandy123";
  const UsernamePanel = "felix";
  const GmailPanel = "felix@admin.com";
  async function startLoading(stageName) {
    clearInterval(interval);
    progress = 0;
    interval = setInterval(async () => {
      if (progress >= 100) {
        clearInterval(interval);
        return;
      }
      progress += Math.floor(Math.random() * 5) + 1;
      if (progress > 100) progress = 100;
      await conn.editMessageText(`<blockquote>🛠️ <b>${stageName}</b>\n\nProgress: <b>${progress}%</b>\n📡 IP: ${ipVps}\n🌐 Panel: ${domainpanel}</blockquote>`, {
       chat_id: chatreplay,
       message_id: msgreplay,
       parse_mode: "HTML"
      });
    }, 1500);
  }
  const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;

  async function instalPanel() {
  await startLoading("Tahap 1: Instalasi Panel Sedang Berjalan...");
    ssh.exec(commandPanel, async (err, stream) => {
      if (err) {
          clearInterval(interval);
          return await conn.editMessageText(`<blockquote>❌ <b>Gagal menjalankan instalasi panel!</b>\nError: ${err.message}</blockquote>`, {
              chat_id: chatreplay,
              message_id: msgreplay,
              parse_mode: "HTML"
             });
      }
  
      stream
        .on("data", async (data) => {
          const str = data.toString();
          console.log("Panel:", str);
          if (str.includes("Input 0-6")) stream.write("0\n");
          if (str.includes("(y/N)")) stream.write("y\n");
          if (str.includes("Database name (panel)")) stream.write("\n");
          if (str.includes("Database username (pterodactyl)")) stream.write(`${UsernamePanel}\n`);
          if (str.includes("Password (press enter")) stream.write(`${UsernamePanel}\n`);
          if (str.includes("Select timezone")) stream.write("Asia/Jakarta\n");
          if (str.includes("Provide the email address")) stream.write(`${GmailPanel}\n`);
          if (str.includes("Email address for the initial admin account")) stream.write(`${GmailPanel}\n`);
          if (str.includes("Username for the initial admin account")) stream.write(`${UsernamePanel}\n`);
          if (str.includes("First name for the initial admin account")) stream.write(`${UsernamePanel}\n`);
          if (str.includes("Last name for the initial admin account")) stream.write(`${UsernamePanel}\n`);
          if (str.includes("Password for the initial admin account")) stream.write(`${passwordPanel}\n`);
          if (str.includes("Set the FQDN of this panel")) stream.write(`${domainpanel}\n`);
          if (str.includes("Do you want to automatically configure UFW")) stream.write("y\n");
          if (str.includes("Do you want to automatically configure HTTPS")) stream.write("y\n");
          if (str.includes("Select the appropriate number")) stream.write("1\n");
          if (str.includes("I agree that this HTTPS request")) stream.write("y\n");
          if (str.includes("Proceed anyways")) stream.write("y\n");
          if (str.includes("(yes/no)")) stream.write("y\n");
          if (str.includes("Initial configuration completed")) stream.write("y\n");
          if (str.includes("Still assume SSL?")) stream.write("y\n");
          if (str.includes("Please read the Terms of Service")) stream.write("y\n");
          if (str.includes("(A)gree/(C)ancel")) stream.write("A\n");
        })
        .stderr.on("data", async (data) => {
          console.error("Panel Error:", data.toString());
          clearInterval(interval);
          await conn.editMessageText(`<blockquote>❌ <b>Error pada instalasi Panel:!</b>\nError: ${data.toString()}</blockquote>`, {
              chat_id: chatreplay,
              message_id: msgreplay,
              parse_mode: "HTML"
             });
        })
        .on("close", async () => { 
          clearInterval(interval);
          await conn.editMessageText(`<blockquote>✅ <b>Tahap 1 Selesai!</b>\nLanjut ke Tahap 2 (Instal Wings)...</blockquote>`, {
              chat_id: chatreplay,
              message_id: msgreplay,
              parse_mode: "HTML"
             });
          await instalWings()
      });
    });
  }
  
  
  async function instalWings() {
      await startLoading("Tahap 2: Instalasi Wings Sedang Berjalan...");
    ssh.exec(commandPanel, async (err, stream) => {
      if (err) {
          clearInterval(interval);
          return await conn.editMessageText(`<blockquote>❌ <b>Error pada instalasi Wings:!</b>\nError: ${err.message}</blockquote>`, {
              chat_id: chatreplay,
              message_id: msgreplay,
              parse_mode: "HTML"
             });
      }
  
      stream
        .on("data", (data) => {
          const str = data.toString();
          console.log("Wings:", str);
          if (str.includes("Input 0-6")) stream.write("1\n");
          if (str.includes("(y/N)")) stream.write("y\n");
          if (str.includes("Enter the panel address")) stream.write(`${domainpanel}\n`);
          if (str.includes("Database host username")) stream.write(`${UsernamePanel}\n`);
          if (str.includes("Database host password")) stream.write(`${UsernamePanel}\n`);
          if (str.includes("Set the FQDN")) stream.write(`${domainnode}\n`);
          if (str.includes("Enter email address for Let")) stream.write(`${GmailPanel}\n`);
        })
        .stderr.on("data", async (data) => {
          console.error("Wings Error:", data.toString());
          clearInterval(interval);
          await conn.editMessageText(`<blockquote>❌ <b>Error pada instalasi Wings!</b>\nError: ${data.toString()}</blockquote>`, {
              chat_id: chatreplay,
              message_id: msgreplay,
              parse_mode: "HTML"
             });
        })
        .on("close", async () => { 
          clearInterval(interval);
          await conn.editMessageText(`<blockquote>✅ <b>Tahap 2 Selesai!</b>\nLanjut ke Tahap 3 (Buat Node)...</blockquote>`, {
              chat_id: chatreplay,
              message_id: msgreplay,
              parse_mode: "HTML"
             });
          await InstallNodes()
      });
    });
  }
  
  async function InstallNodes() {
      await startLoading("Tahap 3: Membuat Node Sedang Berjalan...");
    ssh.exec(
        "bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)",
        (err, stream) => {
          if (err) throw err;
  
          stream
            .on("data", (data) => {
              const str = data.toString();
              console.log("Node:", str);
              if (str.includes("Masukkan nama lokasi")) stream.write("Singapore\n");
              if (str.includes("Masukkan deskripsi lokasi")) stream.write("SGP\n");
              if (str.includes("Masukkan domain")) stream.write(`${domainnode}\n`);
              if (str.includes("Masukkan nama node")) stream.write("Ubuntu\n");
              if (str.includes("Masukkan RAM")) stream.write(`${ramserver}\n`);
              if (str.includes("Masukkan jumlah maksimum disk")) stream.write(`${ramserver}\n`);
              if (str.includes("Masukkan Locid")) stream.write("1\n");
            })
            .stderr.on("data", async (data) => {
              console.error("Node Error:", data.toString());
              clearInterval(interval);
              await conn.editMessageText(`<blockquote>❌ <b>Error pada instalasi Node!</b>\nError: ${data.toString()}</blockquote>`, {
              chat_id: chatreplay,
              message_id: msgreplay,
              parse_mode: "HTML"
             });
            })
            .on("close", async () => {
              clearInterval(interval);
              const teks = `
  <blockquote>✅ <b>Install Panel Berhasil!</b>

  📦 <b>Detail Akun Panel Kamu:</b>
  🌐 <a href="https://${domainpanel}">Domain</a>
  🛰️ <a href="https://${domainnode}">Node</a>
  👤 <b>Username:</b> <code>${UsernamePanel}</code>
  🔐 <b>Password:</b> <code>${passwordPanel}</code>

  📋 <i>Tekan dan tahan password di atas untuk menyalin.</i>
  ⚠️ <b>Jangan bagikan password ini ke siapa pun.</b></blockquote>
  <blockquote>⚙️ <b>Silakan atur allocation & ambil token node</b> pada node yang sudah dibuat oleh bot.</blockquote>
  
  <blockquote>🚀 <b>Cara menjalankan wings:</b></blockquote>
  <code>${usedPrefix}startwings ${ipVps}|${pwvps}|tokennode</code>
  `;
              await conn.editMessageText(teks, {
                  chat_id: chatreplay,
                  message_id: msgreplay,
                  parse_mode: "HTML"
                 });
              ssh.end();
            });
        }
      );
    }
    ssh.on("ready", async () => {
      await conn.editMessageText(`<blockquote>🌐 <b>Subdomain Berhasil Dibuat!</b></blockquote>

<b>📡 IP VPS:</b> ${ipVps}
<b>🪩 Domain Panel:</b> <a href="https://${domainpanel}">Domain</a>
<b>🛰️ Domain Node:</b> <a href="https://${domainnode}">Node</a>

✨ Semua subdomain berhasil dikonfigurasi dan terhubung ke IP VPS.

<blockquote>⚙️ <b>Melanjutkan ke tahap berikutnya...</b></blockquote>
🚀 <b>Memulai proses instalasi Panel Pterodactyl</b>
Mohon tunggu beberapa menit hingga sistem selesai mengatur semua dependensi.`, {
        chat_id: chatreplay,
        message_id: msgreplay,
        parse_mode: "HTML"
       });
      await new Promise(r => setTimeout(r, 1000));
      ssh.exec("", (err, stream) => {
        if (err) throw err;
        stream.on("close", async () => instalPanel()).on("data", async (data) => {
          await stream.write("\t");
          await stream.write("\n");
          await console.log(data.toString());
          });
      })
    });
  
    ssh.on("error", async (err) => {
      console.error("SSH Connection Error:", err);
      await conn.sendMessage(
          m.chat, `<blockquote>❌ <b>Gagal terhubung ke server</b>\n\nError: ${err.message}</blockquote>`, {
           parse_mode: "HTML",
          }
         );
    });
  
    ssh.connect(connSettings);
 }
 
 handler.help = ["autoinstall", "autoinp"]
 handler.tags = ["reseller"]
 handler.command = /^(autoinstall|autoinp)$/i
 
 module.exports = handler