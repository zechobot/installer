const handler = async (m, { text, conn, command }) => {
  try {
    let target;

    // Tentukan target
    if (m.quoted) {
      target = m.quoted.sender; // reply pesan
    } else if (text) {
      text = text.trim();
      if (text.startsWith("@")) text = text.slice(1);

      if (/^\d+$/.test(text)) {
        target = Number(text);
      } else {
        if (!m.isGroup) return m.reply("⚠️ Username hanya bisa dicek di grup.");
        let members = [];
        try { members = await conn.getChatAdministrators(m.chat); } catch {}
        const found = members.find(
          u => u.user && u.user.username && u.user.username.toLowerCase() === text.toLowerCase()
        );
        if (!found) return m.reply(`❌ Tidak menemukan user dengan username @${text} di grup ini.`);
        target = found.user.id;
      }
    } else {
      target = m.sender;
    }
    const replyHTML = (text) =>
    conn.sendMessage(m.chat, `<blockquote>${text}</blockquote>`, { parse_mode: "HTML" })
    // Check apakah user sudah chat bot
    let hasChatted = false;
    try {
      await conn.getChat(target);
      hasChatted = true; // berhasil ambil chat → sudah chat bot
    } catch {
      hasChatted = false; // error → belum chat bot
    }

    // === Command ID user ===
    if (/^(id|cekid)$/i.test(command)) {
      let chat;
      try {
        chat = await conn.getChat(target);
      } catch (err) {
        return m.reply(`❌ Tidak bisa ambil info user.\nError: ${err.message}`);
      }

      let info = `📄 <b>>User Info</b>\n\n`;
      info += `🆔 <b>ID</b>: <pre>${chat.id}</pre>\n`;
      info += `👥 <b>Type:</b> <code>${chat.type}</code>\n`;
      if (chat.first_name) info += `👤 <b>First Name:</b> ${chat.first_name}\n`;
      if (chat.last_name) info += `👥 <b>Last Name:</b> ${chat.last_name}\n`;
      if (chat.username) info += `🔗 <b>Username:</b> @${chat.username}\n`;

      // ✅ / ❌ status chat bot
      info += `💬 <b>Chat Bot:</b> ${hasChatted ? "✅ Sudah" : "❌ Belum"}\n`;
      return replyHTML(info)
    }

    // === Command ID grup ===
    if (/^(idgc|cekidgc)$/i.test(command)) {
      if (!m.isGroup) return m.reply("⚠️ Command ini hanya bisa digunakan di grup.");
      const chat = await conn.getChat(m.chat);
      let info = `📄 <b>Group Info</b>\n\n`;
      info += `🆔 <b>ID:</b> <pre>${chat.id}</pre>\n`;
      info += `👥 <b>Type:</b> ${chat.type}\n`;
      if (chat.title) info += `📛 <b>Title:</b> ${chat.title}\n`;
      return replyHTML(info)
    }
  } catch (err) {
    console.error(err);
    m.reply(`❌ Terjadi kesalahan: ${err.message}`);
  }
};

handler.help = ["id", "cekid", "idgc", "cekidgc"];
handler.tags = ["info", "main"];
handler.command = /^(id|cekid|idgc|cekidgc)$/i;

module.exports = handler;