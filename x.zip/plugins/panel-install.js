const { Client } = require("ssh2");
const ssh = new Client();

const handler = async (m, { conn, text, isOwner, isPrems, usedPrefix, command }) => {
    if (m.isGroup && isOwner && !isPrems) return m.reply("⚠️ Perintah ini hanya bisa digunakan di chat pribadi.");
  if (!isOwner && !isPrems) return m.reply("Fitur ini untuk owner bot!")
    if (!text) return m.reply(`Contoh: *${usedPrefix + command}* ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*`);

    let vii = text.split("|");
    if (vii.length < 5) return m.reply(`Contoh: *${usedPrefix + command}* ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*`);
    const [ipVps, pwVps, domainpanel, domainnode, ramserver] = vii;
    const connSettings = {
        host: ipVps,
        port: '22',
        username: 'root',
        password: pwVps
    };

    const passwordPanel = "Sandy123";
    const UsernamePanel = "felix";
    const GmailPanel = "felix@admin.com";

    const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;
       let sentMessage = await conn.sendMessage(
           m.chat, `<blockquote>⚙️ <b>Memulai proses instalasi panel...</b>\n🛠️ Proses instalasi panel sedang berjalan 🚀\n\n📡 IP VPS: ${ipVps}\n🌐 Domain Panel: ${domainpanel}\n\n⏳ Mohon tunggu sekitar 10–20 menit hingga proses instalasi selesai.\nAnda akan mendapatkan notifikasi setelah panel berhasil terinstall.</blockquote>`, {
            parse_mode: "HTML",
           }
          );
       let chatreplay = sentMessage.chat.id;
       let msgreplay = sentMessage.message_id;
       let progress = 0;
       let interval;
     
       async function startLoading(stageName) {
         clearInterval(interval);
         progress = 0;
         interval = setInterval(async () => {
           if (progress >= 100) {
             clearInterval(interval);
             return;
           }
           progress += Math.floor(Math.random() * 5) + 1;
           if (progress > 100) progress = 100;
           await conn.editMessageText(`<blockquote>🛠️ <b>${stageName}</b>\n\nProgress: <b>${progress}%</b>\n📡 IP: ${ipVps}\n🌐 Panel: ${domainpanel}</blockquote>`, {
            chat_id: chatreplay,
            message_id: msgreplay,
            parse_mode: "HTML"
           });
         }, 1500);
       }

    async function instalPanel() {
    await startLoading("Tahap 1: Instalasi Panel Sedang Berjalan...");
      ssh.exec(commandPanel, async (err, stream) => {
        if (err) {
            clearInterval(interval);
            return await conn.editMessageText(`<blockquote>❌ <b>Gagal menjalankan instalasi panel!</b>\nError: ${err.message}</blockquote>`, {
                chat_id: chatreplay,
                message_id: msgreplay,
                parse_mode: "HTML"
               });
        }
    
        stream
          .on("data", async (data) => {
            const str = data.toString();
            console.log("Panel:", str);
            if (str.includes("Input 0-6")) stream.write("0\n");
            if (str.includes("(y/N)")) stream.write("y\n");
            if (str.includes("Database name (panel)")) stream.write("\n");
            if (str.includes("Database username (pterodactyl)")) stream.write(`${UsernamePanel}\n`);
            if (str.includes("Password (press enter")) stream.write(`${UsernamePanel}\n`);
            if (str.includes("Select timezone")) stream.write("Asia/Jakarta\n");
            if (str.includes("Provide the email address")) stream.write(`${GmailPanel}\n`);
            if (str.includes("Email address for the initial admin account")) stream.write(`${GmailPanel}\n`);
            if (str.includes("Username for the initial admin account")) stream.write(`${UsernamePanel}\n`);
            if (str.includes("First name for the initial admin account")) stream.write(`${UsernamePanel}\n`);
            if (str.includes("Last name for the initial admin account")) stream.write(`${UsernamePanel}\n`);
            if (str.includes("Password for the initial admin account")) stream.write(`${passwordPanel}\n`);
            if (str.includes("Set the FQDN of this panel")) stream.write(`${domainpanel}\n`);
            if (str.includes("Do you want to automatically configure UFW")) stream.write("y\n");
            if (str.includes("Do you want to automatically configure HTTPS")) stream.write("y\n");
            if (str.includes("Select the appropriate number")) stream.write("1\n");
            if (str.includes("I agree that this HTTPS request")) stream.write("y\n");
            if (str.includes("Proceed anyways")) stream.write("y\n");
            if (str.includes("(yes/no)")) stream.write("y\n");
            if (str.includes("Initial configuration completed")) stream.write("y\n");
            if (str.includes("Still assume SSL?")) stream.write("y\n");
            if (str.includes("Please read the Terms of Service")) stream.write("y\n");
            if (str.includes("(A)gree/(C)ancel")) stream.write("A\n");
          })
          .stderr.on("data", async (data) => {
            console.error("Panel Error:", data.toString());
            clearInterval(interval);
            await conn.editMessageText(`<blockquote>❌ <b>Error pada instalasi Panel:!</b>\nError: ${data.toString()}</blockquote>`, {
                chat_id: chatreplay,
                message_id: msgreplay,
                parse_mode: "HTML"
               });
          })
          .on("close", async () => { 
            clearInterval(interval);
            await conn.editMessageText(`<blockquote>✅ <b>Tahap 1 Selesai!</b>\nLanjut ke Tahap 2 (Instal Wings)...</blockquote>`, {
                chat_id: chatreplay,
                message_id: msgreplay,
                parse_mode: "HTML"
               });
            await instalWings()
        });
      });
    }
    
    
    async function instalWings() {
        await startLoading("Tahap 2: Instalasi Wings Sedang Berjalan...");
      ssh.exec(commandPanel, async (err, stream) => {
        if (err) {
            clearInterval(interval);
            return await conn.editMessageText(`<blockquote>❌ <b>Error pada instalasi Wings:!</b>\nError: ${err.message}</blockquote>`, {
                chat_id: chatreplay,
                message_id: msgreplay,
                parse_mode: "HTML"
               });
        }
    
        stream
          .on("data", (data) => {
            const str = data.toString();
            console.log("Wings:", str);
            if (str.includes("Input 0-6")) stream.write("1\n");
            if (str.includes("(y/N)")) stream.write("y\n");
            if (str.includes("Enter the panel address")) stream.write(`${domainpanel}\n`);
            if (str.includes("Database host username")) stream.write(`${UsernamePanel}\n`);
            if (str.includes("Database host password")) stream.write(`${UsernamePanel}\n`);
            if (str.includes("Set the FQDN")) stream.write(`${domainnode}\n`);
            if (str.includes("Enter email address for Let")) stream.write(`${GmailPanel}\n`);
          })
          .stderr.on("data", async (data) => {
            console.error("Wings Error:", data.toString());
            clearInterval(interval);
            await conn.editMessageText(`<blockquote>❌ <b>Error pada instalasi Wings!</b>\nError: ${data.toString()}</blockquote>`, {
                chat_id: chatreplay,
                message_id: msgreplay,
                parse_mode: "HTML"
               });
          })
          .on("close", async () => { 
            clearInterval(interval);
            await conn.editMessageText(`<blockquote>✅ <b>Tahap 2 Selesai!</b>\nLanjut ke Tahap 3 (Buat Node)...</blockquote>`, {
                chat_id: chatreplay,
                message_id: msgreplay,
                parse_mode: "HTML"
               });
            await InstallNodes()
        });
      });
    }
    
    async function InstallNodes() {
        await startLoading("Tahap 3: Membuat Node Sedang Berjalan...");
      ssh.exec(
          "bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)",
          (err, stream) => {
            if (err) throw err;
    
            stream
              .on("data", (data) => {
                const str = data.toString();
                console.log("Node:", str);
                if (str.includes("Masukkan nama lokasi")) stream.write("Singapore\n");
                if (str.includes("Masukkan deskripsi lokasi")) stream.write("SGP\n");
                if (str.includes("Masukkan domain")) stream.write(`${domainnode}\n`);
                if (str.includes("Masukkan nama node")) stream.write("Ubuntu\n");
                if (str.includes("Masukkan RAM")) stream.write(`${ramserver}\n`);
                if (str.includes("Masukkan jumlah maksimum disk")) stream.write(`${ramserver}\n`);
                if (str.includes("Masukkan Locid")) stream.write("1\n");
              })
              .stderr.on("data", async (data) => {
                console.error("Node Error:", data.toString());
                clearInterval(interval);
                await conn.editMessageText(`<blockquote>❌ <b>Error pada instalasi Node!</b>\nError: ${data.toString()}</blockquote>`, {
                chat_id: chatreplay,
                message_id: msgreplay,
                parse_mode: "HTML"
               });
              })
              .on("close", async () => {
                clearInterval(interval);
                const teks = `
  <blockquote>✅ <b>Install Panel Berhasil!</b>

  📦 <b>Detail Akun Panel Kamu:</b>
  
  🌐 <a href="https://${domainpanel}">Domain</a>
  👤 <b>Username:</b> <code>${UsernamePanel}</code>
  🔐 <b>Password:</b> <code>${passwordPanel}</code>

  📋 <i>Tekan dan tahan password di atas untuk menyalin.</i>
  ⚠️ <b>Jangan bagikan password ini ke siapa pun.</b></blockquote>
  <blockquote>⚙️ <b>Silakan atur allocation & ambil token node</b> pada node yang sudah dibuat oleh bot.</blockquote>
  
  <blockquote>🚀 <b>Cara menjalankan wings:</b></blockquote>
  <code>${usedPrefix}startwings ${ipVps}|${pwVps}|tokennode</code>
  `;
                await conn.editMessageText(teks, {
                    chat_id: chatreplay,
                    message_id: msgreplay,
                    parse_mode: "HTML"
                   });
                ssh.end();
              });
          }
        );
      }
      ssh.on("ready", () => {
        ssh.exec("", (err, stream) => {
          if (err) throw err;
          stream.on("close", async () => instalPanel()).on("data", async (data) => {
            await stream.write("\t");
            await stream.write("\n");
            await console.log(data.toString());
            });
        })
      });
    
      ssh.on("error", async (err) => {
        console.error("SSH Connection Error:", err);
        await conn.sendMessage(
            m.chat, `<blockquote>❌ <b>Gagal terhubung ke server</b>\n\nError: ${err.message}</blockquote>`, {
             parse_mode: "HTML",
            }
           );
      });
    
      ssh.connect(connSettings);
}

handler.help = ["instalpanel", "instalp"]
handler.tags = ["reseller", "owner"]
handler.command = /^(instalpanel|instalp)$/i

module.exports = handler
