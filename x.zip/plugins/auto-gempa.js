// plugins/info-bmkg.js
const axios = require("axios")
const fs = require("fs")
const path = require("path")
// === Ambil info gempa BMKG ===
async function gempa() {
  const res = await axios.get("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json")
  const data = res.data.Infogempa.gempa
  return {
    source: "BMKG (data.bmkg.go.id)",
    data: {
      waktu: data.Tanggal + " " + data.Jam,
      magnitude: data.Magnitude,
      kedalaman: data.Kedalaman,
      lintang_bujur: data.Lintang + " - " + data.Bujur,
      wilayah: data.Wilayah,
      dirasakan: data.Dirasakan,
      imagemap: `https://data.bmkg.go.id/DataMKG/TEWS/${data.Shakemap}`
    }
  }
}

// === Download image ke buffer ===
async function fetchImageBuffer(url) {
  try {
    const res = await axios.get(url, { responseType: "arraybuffer" })
    return Buffer.from(res.data)
  } catch (err) {
    console.error("❌ Gagal ambil gambar BMKG:", err.message)
    return null
  }
}

// === Kirim info gempa ke Telegram ===
async function sendGempaInfo(conn, chatId, gempaData) {
  const captionText =
    `🌋 *INFO GEMPA TERKINI* 🌋\n\n` +
    `*🕒 Waktu:* ${gempaData.waktu}\n` +
    `*📍 Lokasi:* ${gempaData.wilayah}\n` +
    `*📊 Magnitudo:* ${gempaData.magnitude}\n` +
    `*📏 Kedalaman:* ${gempaData.kedalaman}\n` +
    `*🗺️ Koordinat:* ${gempaData.lintang_bujur}\n` +
    `*😱 Dirasakan:* ${gempaData.dirasakan || 'Tidak ada data'}\n\n` +
    `_Sumber: [BMKG](https://www.bmkg.go.id)_`

    const replyMarkusp = {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🌐 Lihat di BMKG", url: "https://www.bmkg.go.id" }]
          ]
        }
      }
  const replyMarkup = {
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "🌐 Lihat di BMKG", url: `${gempaData.imagemap}` }]
      ]
    }
  }

  if (gempaData.imagemap) {
    const imgBuffer = await fetchImageBuffer(gempaData.imagemap)
    if (imgBuffer) {
      await conn.sendPhoto(chatId, imgBuffer, {
        caption: captionText,
        ...replyMarkusp
      })
    } else {
      await conn.sendMessage(chatId, captionText, replyMarkup)
    }
  } else {
    await conn.sendMessage(chatId, captionText, replyMarkup)
  }
}

// === Command manual ===
let handler = async (m, { conn }) => {
  try {
    const result = await gempa()
    await sendGempaInfo(conn, m.chat, result.data)
  } catch (e) {
    console.error("BMKG manual error:", e)
    await conn.sendMessage(m.chat, "⚠️ Gagal mengambil data dari BMKG.")
  }
}
handler.command = handler.help = ['infogempa' , 'gempa', 'bmkg'];
handler.tags = ["info"]


// === Auto update tiap 5 menit ===
handler.before = async function (m, { conn }) {
  try {
  const autogempa = global.db.data.chats;
  // pastikan struktur data aman
  if (!autogempa[m.chat].autoGempa) {
    autogempa[m.chat].autoGempa = { status: false, lastCheck: 0, lastGempa: {} };
  }
  const autoGempa = autogempa[m.chat].autoGempa;
  if (!autoGempa.status) return;
    const now = Date.now()
     if (now - autoGempa.lastCheck < 5 * 60 * 1000) return; // cek setiap 5 menit
      autoGempa.lastCheck = now;

    const result = await gempa()
    const newGempa = result.data

    if (!autoGempa.lastCheck || newGempa.waktu !== lastGempa.waktu) {
      lastGempa = newGempa
      autoGempa.lastGempa = newGempa;
      fs.writeFileSync(CACHE_PATH, JSON.stringify(newGempa, null, 2))
      console.log(`[BMKG] Gempa baru terdeteksi: ${newGempa.wilayah}`)

      const chats = Object.keys(global.db.data.chats || {})
      for (const id of chats) {
        if (global.db.data.chats[id].isBanned) continue
        await sendGempaInfo(conn, id, newGempa)
      }
    }
  } catch (e) {
    console.error("BMKG auto error:", e.message)
  }
}

module.exports = handler
