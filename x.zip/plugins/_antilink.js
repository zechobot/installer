// --- Regex per kategori (lebih spesifik + robust) ---
const regexMap = {
 // jangan ganti posisi ini — kita akan pakai order terpisah saat mengecek
 all: /(https?:\/\/[^\s]+)/i,

 1: /(https?:\/\/)?(chat\.whatsapp\.com\/[A-Za-z0-9]+|chat\.whatsapp\.com\/[^\s]+t\.me\/(\+)?[A-Za-z0-9_-]+|t\.me\/[^\s]+)/i, // WA / Telegram
 2: /(https?:\/\/)?(www\.)?(instagram\.com|instagr\.am)\/[^\s]+/i, // Instagram (post/reel/profile)
 3: /(https?:\/\/)?(www\.)?tiktok\.com\/[^\s]+/i, // TikTok
 4: /(https?:\/\/)?(www\.)?(facebook\.com|fb\.watch)\/?[^\s]*/i, // Facebook
 5: /(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/[^\s]+/i, // YouTube
 6: /(https?:\/\/)?(www\.)?(xvideos\.com|pornhub\.com|redtube\.com|xnxx\.com|rule34|hentai|jav)\/?[^\s]*/i // Adult
};
let handler = m => m;

handler.before = async function(m, {
 conn,
 text, 
 isBotAdmin, 
 isAdmin
}) {
 if (!m || !m.isGroup) return;

 if (!global.db) global.db = {
  data: {
   chats: {}
  }
 };
 if (!global.db.data.chats[m.chat]) {
  global.db.data.chats[m.chat] = {
   antilink: false,
   antilink1: false,
   antilink2: false,
   antilink3: false,
   antilink4: false,
   antilink5: false,
   antilink6: false
  };
 }

 const chat = global.db.data.chats[m.chat];

 // Tentukan regex sesuai pengaturan
 let regex = null;
 if (chat.antilink) regex = regexMap.all; // antilink true = cek semua
 else {
  for (let i = 1; i <= 6; i++) {
   if (chat[`antilink${i}`]) {
    regex = regexMap[i];
    break;
   }
  }
 }
 if (!regex) return; // Tidak ada anti-link aktif
 if (!regex.test(text)) return; // Tidak ada link sesuai kategori
 try {
  const chatInfo = await conn.getChat(m.chat);
  if (chatInfo.invite_link && text.includes(chatInfo.invite_link)) return true;
 } catch {}
 try {

  if (!isBotAdmin) {
    console.log("❌ Bot bukan admin, skip aksi anti-media.");
    return true;
  }
  
  // --- Jika user admin, skip (jangan hapus pesan admin) ---
  if (isAdmin) {
    console.log("ℹ️ Pengirim adalah admin, lewati anti-media.");
    return true;
  }
     console.log("✅ Bot admin & user bukan admin → lanjut hapus pesan.");
   const sentMessage = await conn.sendMessage(
    m.chat, `<blockquote> 🚨 <b>Anti-Link mode aktif!...</b>\n\nTerdeteksi tautan dalam pesan dari: <b>${m.name}</b></blockquote>`, {
     parse_mode: "HTML",
    }
   );

   const chatreplay = sentMessage.chat.id;
   const msgreplay = sentMessage.message_id;
   await m.delete();
   setTimeout(async () => {
    const summary = `<blockquote>🚫<b>Pesan dari ${m.name}</b>\n\nPesan dihapus karena mengandung tautan</blockquote>`;

    await conn.editMessageText(summary, {
     chat_id: chatreplay,
     message_id: msgreplay,
     parse_mode: "HTML"
    });
    return true // skip hanya untuk non-admin
   }, 200);
 } catch (err) {
  console.error("Anti-Link Error:", err.message);
 }
 return true;
};

module.exports = handler;