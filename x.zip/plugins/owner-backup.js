const fs = require('fs');
const { execSync } = require('child_process');
const handler = async (m, { conn, isOwner }) => {
  if (!isOwner) return m.reply(`Fitur ini hanya untuk developer bot`);

  const sender = m.sender;
  const chatId = m.chat;
  // pesan awal progress
  const progressMsg = await m.reply("⏳ Proses backup dimulai...");

  let chatreplay = progressMsg.chat.id;
  let msgreplay = progressMsg.message_id;

  try {
    const tmpDir = "./tmp";
    if (fs.existsSync(tmpDir)) {
      const files = fs.readdirSync(tmpDir).filter(f => !f.endsWith(".js"));
      for (let file of files) {
        fs.unlinkSync(`${tmpDir}/${file}`);
      }
    }

    const name = `KawairunEnginBot`;
    const exclude = ["node_modules", "BackupBot", "package-lock.json", "yarn.lock", ".npm", ".cache"];
    const filesToZip = fs.readdirSync(".").filter(f =>
      !exclude.includes(f) && !f.endsWith(".zip") && f !== ""
    );

    if (!filesToZip.length) return m.reply("❌ Tidak ada file yang bisa di-backup.");

    // proses zip
    execSync(`zip -r ${name}.zip ${filesToZip.join(" ")}`);
    // kirim file hasil zip
    try {
      await conn.sendDocument(sender, fs.createReadStream(`./${name}.zip`), {}, { filename: `${name}.zip` });
      fs.unlinkSync(`./${name}.zip`);
      const chats = await conn.getChat(sender);
      let textxxx = `\n\n🧍 *User Info*\n\n`;
      textxxx += `🆔 ID: \`${chats.id}\`\n`;
      if (chats.username) textxxx += `🔗 Username: \`@${chats.username}\`\n`;
      await conn.editMessageText(
        `✅ ${name}.zip berhasil dikirim ke ${textxxx}`,
        {
          chat_id: chatreplay,
          message_id: msgreplay,
          parse_mode: "Markdown"
        }
      );
    } catch (err) {
      const ownerIds = global.ownerid || global.db.data?.owner || [];
      if (!Array.isArray(ownerIds) || ownerIds.length === 0) {
        await m.reply(`❌ Gagal kirim ke target dan owner tidak terdeteksi!`);
        return;
      }
      for (const oid of ownerIds) {
        const owner = Number(oid);
        const chats = await conn.getChat(sender);
        const chatsx = await conn.getChat(owner);
        try {

          let textxxx = `\n\n🧍 *User Info*\n\n`;
          textxxx += `🆔 ID: \`${chats.id}\`\n`;
          if (chats.username) textxxx += `🔗 Username: \`@${chats.username}\`\n`;
          if (chats.username) textxxx += `⚠️ *Gagal kirim Data Backup e: @${chats.username}*`;
          await conn.sendMessage(owner, `${textxxx}`, {
            parse_mode: 'Markdown'
          });
          await conn.sendDocument(owner, fs.createReadStream(`./${name}.zip`), {}, { filename: `${name}.zip` });
          await conn.editMessageText(
            `✅ ${name}.zip berhasil dikirim ke ${chatsx.username}`,
            {
              chat_id: chatreplay,
              message_id: msgreplay,
              parse_mode: "Markdown"
            }
          );
        } catch (err) {
          const chats = await conn.getChat(chatId);
          let textxxx = `\n\n*Groups Info*\n\n`;
          textxxx += `🆔 ID: \`${chats.id}\`\n`;
          if (chats.username) textxxx += `🔗 Username: \`@${chats.username}\`\n`;
          await conn.sendDocument(chatId, fs.createReadStream(`./${name}.zip`), {}, { filename: `${name}.zip` });
          await conn.editMessageText(
            `✅ ${name}.zip berhasil dikirim ke ${textxxx}`,
            {
              chat_id: chatreplay,
              message_id: msgreplay,
              parse_mode: "Markdown"
            }
          );
        }
      }
    }
  } catch (err) {
    console.error("Backup Error:", err);
    await conn.editMessageText(
      `❌ Terjadi kesalahan saat backup:\n${err.message}`,
      {
        chat_id: chatreplay,
        message_id: msgreplay,
        parse_mode: "Markdown"
      }
    );
  }
}
handler.help = ["backupsc", "backup", "bck"]
handler.tags = ["main"]
handler.command = /^(bck|backup|backupsc)$/i

module.exports = handler
