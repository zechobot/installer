const fetch = require("node-fetch");

const handler = async (m, { conn }) => {
  try {
    const chatId = m.chat;

    const panels = Object.keys(global.cpanel || {});
    if (!panels.length) return m.reply("❌ Tidak ada panel tersedia.");

    // Simpan cache panel per chat
    if (!conn._panelCache) conn._panelCache = {};
    conn._panelCache[chatId] = { panels, selected: null };
    if (!global.subdomain || Object.keys(global.subdomain).length === 0)
      return m.reply("⚠️ Tidak ada data subdomain terdaftar di global.subdomain!")

    // Ambil daftar domain (srv list)
    const domainKeys = Object.keys(global.subdomain)
    let text = "🧩 *Pilih Server Cloudflare*\n\n"
    domainKeys.forEach((domain, i) => {
      text += `*${i + 1}.* ${domain}\n`
    })
    // Tombol daftar panel, kirim nomor panel atau nama panel di callback_data
    const keyboard = domainKeys.map((domain, i) => [
      {
        text: `🖥 ${i + 1}. ${domain}`,
        callback_data: `sub_srv_${i + 1}`
      },
    ]);

    // Tombol tutup
    keyboard.push([{ text: "✖ Tutup", callback_data: "menu_delete" }]);

    await conn.sendMessage(chatId, "📋 Pilih Pilih Server Cloudflare:", {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard },
    });
  } catch (e) {
    console.error("❌ Error di /csubdo handler:", e);
    m.reply("Terjadi kesalahan saat mengambil daftar panel.");
  }
};

handler.help = ["getsubdomain", "getdomain", "csubdo", "ceksubdo", "ceksubdomain", "cekdomain"];
handler.tags = ["subdomain", "owner", "reseller"];
handler.command = /^(getsubdomain|getdomain|csubdo|ceksubdo|ceksubdomain|cekdomain|\?)$/i;

module.exports = handler;
