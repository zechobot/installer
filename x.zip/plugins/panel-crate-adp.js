// === HANDLER CREATE PANEL ===
const handler = async (m, { conn, args, isROwner, isReseller, isOwner, usedPrefix, command }) => {
  if (!isROwner && !isOwner && !isReseller)
    return m.reply("⚠️ Fitur ini hanya untuk Reseller dan Owner bot!");

  let username, idTelegram;

  if (m.quoted) {
    username = args[0];
    idTelegram = m.quoted.sender;
  } else if (args[0] && args[0].includes(",")) {
    [username, idTelegram] = args[0].split(",").map(s => s.trim());
  } else if (m.sender) {
    username = args[0];
    idTelegram = m.sender;
  }

  if (!username || !idTelegram)
    return m.reply(
      `❗ Tag, reply, atau kirim ID user!\n\nContoh:\n${usedPrefix}${command} username reply pesan\n${usedPrefix}${command} username,123456789`
    );

  // === Simpan konteks sementara untuk user ini ===
  if (!conn._createCache) conn._createCache = {};
  conn._createCache[m.sender] = { username, idTelegram, command };

  // === Buat tombol list server dari global.cpanel ===
  const cpanels = Object.keys(global.cpanel || {});
  if (!cpanels.length) return m.reply("❌ Tidak ada server di global.cpanel!");

  const keyboard = cpanels.map((domain, i) => [
    { text: `🌐 Server ${i + 1}`, callback_data: `crate_adp_${i + 1}` }
  ]);

  const teks = `<blockquote>🛠 <b>Pilih server untuk membuat panel</b> <b>${username}</b>\n\nCommand: <b>${command.toUpperCase()}</b></blockquote>`;

  await conn.sendMessage(m.chat, teks, {
    reply_markup: { inline_keyboard: keyboard },
    parse_mode: "HTML"
  });
};

// === REGISTER COMMANDS ===
handler.help = [
  "adp  <username>", "cadp  <username>", "cadmin  <username>", "crateadmin  <username>"
];
handler.tags = ["reseller", "owner"];
handler.command = /^(adp|cadp|cadmin|crateadmin)$/i;

module.exports = handler;