const handler = async (m, { conn, usedPrefix, command, args, isOwner, isROwner, isPrems, isReseller }) => {
  const owners = global.db?.data?.owner || [];
  const resellers = global.db?.data?.reseller || [];
  const premiums = global.db?.data?.premium || [];
  const usersx = global.db?.data?.users || {};

  let target;
  if (m.quoted) {
    target = m.quoted.sender;
  } else if (args[0]) {
    const arg = args[0].trim();
    if (/^\d+$/.test(arg)) target = arg;
    else if (arg.startsWith('@')) target = arg.replace('@', '');
  }

  if (target) target = target.toString();

  const needTarget = [
    "addown","addowner","addowners",
    "delown","delowner","delowners",
    "addprem","addpremium","delprem","delpremium",
    "addres","addseler","addreseller",
    "delres","delseler","delreseller"
  ];

  if (needTarget.includes(command) && !target)
    return m.reply(`❗ Tag, reply, atau kirim ID user!\n\nContoh:\n${usedPrefix}${command} reply pesan\n${usedPrefix}${command} 123456789`);

  if (target && !usersx[target]) {
    usersx[target] = {
      saldo: 0, exp: 0, level: 0, limit: 30,
      owner: false, registered: false, premium: false, reseller: false
    };
  }

  try {
    switch (command) {
      // ========== OWNER ==========
      case "addown":
      case "addowner":
      case "addowners": {
        if (!isROwner) return m.reply("❌ Hanya *Root Owner* yang bisa menambah owner!");
        usersx[target].owner = true;
        if (!owners.includes(target)) owners.push(target);
        m.reply(`✅ User [${target}] sekarang adalah *Owner*!`);
      }
        break;

      case "delown":
      case "delowner":
      case "delowners": {
        if (!isROwner) return m.reply("❌ Hanya *Root Owner* yang bisa menghapus owner!");
        usersx[target].owner = false;
        const idx = owners.indexOf(target);
        if (idx !== -1) owners.splice(idx, 1);
        m.reply(`❌ User [${target}] bukan lagi *Owner*!`);
      }
        break;

      // ========== PREMIUM ==========
      case "addprem":
      case "addpremium": {
        if (!isOwner && !isROwner && !isReseller)
          return m.reply("❌ Hanya owner atau reseller yang bisa menambah user premium!");
        usersx[target].premium = true;
        if (!premiums.includes(target)) premiums.push(target);
        m.reply(`💎 User [${target}] sekarang adalah *User Premium*!`);
      }
        break;

      case "delprem":
      case "delpremium": {
        if (!isOwner && !isROwner && !isReseller)
          return m.reply("❌ Hanya owner atau reseller yang bisa menghapus user premium!");
        usersx[target].premium = false;
        const idx = premiums.indexOf(target);
        if (idx !== -1) premiums.splice(idx, 1);
        m.reply(`🪙 User [${target}] bukan lagi *User Premium*!`);
      }
        break;

      // ========== RESELLER ==========
      case "addres":
      case "addseler":
      case "addreseller": {
        if (!isOwner && !isROwner) return m.reply("❌ Hanya owner yang bisa menambah reseller!");
        usersx[target].reseller = true;
        if (!resellers.includes(target)) resellers.push(target);
        m.reply(`📦 User [${target}] sekarang adalah *Reseller*!`);
      }
        break;

      case "delres":
      case "delseler":
      case "delreseller": {
        if (!isOwner && !isROwner) return m.reply("❌ Hanya owner yang bisa menghapus reseller!");
        usersx[target].reseller = false;
        const idx = resellers.indexOf(target);
        if (idx !== -1) resellers.splice(idx, 1);
        m.reply(`🚫 User [${target}] bukan lagi *Reseller*!`);
      }
        break;

      // ========== LIST OWNER ==========
      case "listown":
      case "listowner": {
        if (!owners.length) return m.reply("📭 Tidak ada *Owner* terdaftar!");
        let teks = "📜 *Daftar Owner:*\n\n";
        for (let i = 0; i < owners.length; i++) {
          const v = owners[i];
          try {
            const chat = await conn.getChat(v);
            if (chat?.username) teks += `👑 ${i + 1}. @${chat.username}\n`;
            else teks += `👑 ${i + 1}. ${v}\n`;
          } catch {
            teks += `👑 ${i + 1}. ${v} (ID)\n`;
          }
        }
        await m.reply(teks);
      }
        break;

      // ========== LIST RESELLER ==========
      case "listres":
      case "listreseller": {
        if (!resellers.length) return m.reply("📭 Tidak ada *Reseller* terdaftar!");
        let teks = "📜 *Daftar Reseller:*\n\n";
        for (let i = 0; i < resellers.length; i++) {
          const v = resellers[i];
          try {
            const chat = await conn.getChat(v);
            if (chat?.username) teks += `💼 ${i + 1}. @${chat.username}\n`;
            else teks += `💼 ${i + 1}. ${v}\n`;
          } catch {
            teks += `💼 ${i + 1}. ${v} (ID)\n`;
          }
        }
        await m.reply(teks);
      }
        break;

      // ========== LIST PREMIUM ==========
      case "listprem":
      case "listpremium": {
        if (!premiums.length) return m.reply("📭 Tidak ada *User Premium* terdaftar!");
        let teks = "📜 *Daftar User Premium:*\n\n";
        for (let i = 0; i < premiums.length; i++) {
          const v = premiums[i];
          try {
            const chat = await conn.getChat(v);
            if (chat?.username) teks += `💎 ${i + 1}. @${chat.username}\n`;
            else teks += `💎 ${i + 1}. ${v}\n`;
          } catch {
            teks += `💎 ${i + 1}. ${v} (ID)\n`;
          }
        }
        await m.reply(teks);
      }
        break;

      // ========== DEFAULT ==========
      default:
        return m.reply(`
🧩 *Daftar Perintah Owner/Reseller/Premium:*

👑 Owner:
- ${usedPrefix}addowner <@user/id>
- ${usedPrefix}delowner <@user/id>
💎 Premium:
- ${usedPrefix}addprem <@user/id>
- ${usedPrefix}delprem <@user/id>
💼 Reseller:
- ${usedPrefix}addres <@user/id>
- ${usedPrefix}delres <@user/id>

📋 Cek daftar:
- ${usedPrefix}listown
- ${usedPrefix}listres
- ${usedPrefix}listprem
        `.trim());
    }

    await global.db.write();
  } catch (err) {
    console.error(err);
    m.reply(`❌ Terjadi kesalahan:\n${err.message}`);
  }
};

// === Metadata Command ===
handler.help = ["addowner", "delowner", "addprem", "delprem", "addres", "delres", "listown", "listres", "listprem"];
handler.tags = ["owner"];
handler.command = /^(addowner|delowner|addprem|delprem|addres|delres|listown|listres|listprem|listowner)$/i;

module.exports = handler;
