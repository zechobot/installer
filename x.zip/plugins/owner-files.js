const fs = require("fs")
const path = require("path")

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const args = text.trim().split(/\s+/)
  const cmd = command.toLowerCase()

  // === SAVE FILE (.sf / .sv) ===
  if (cmd === "sf" || cmd === "sv") {
    if (!text) return m.reply(
      `⚙️ *Penggunaan:*\n${usedPrefix + command} <path>\n\n📌 *Contoh:*\n${usedPrefix + command} plugins/menu.js\n\nBalas pesan teks *atau* kirim dokumen untuk disimpan.`
    )

    const filePath = path.resolve(text.trim())

    try {
      // Simpan dari teks
      if (m.quoted?.text) {
        fs.mkdirSync(path.dirname(filePath), { recursive: true })
        fs.writeFileSync(filePath, m.quoted.text)
        await m.reply(`✅ Berhasil disimpan ke *${filePath}*`)
        return
      }

      // Simpan dari dokumen
      if (m.quoted?.media === "document") {
        let buffer = null
        try {
          buffer = await m.quoted.download()
        } catch {
          buffer = await conn.downloadFile(m.quoted.fileid)
        }

        if (!buffer) throw new Error("Gagal mengunduh file.")

        fs.mkdirSync(path.dirname(filePath), { recursive: true })
        fs.writeFileSync(filePath, buffer)
        await m.reply(`✅ Berhasil menyimpan dokumen ke *${filePath}*`)
        return
      }

      await m.reply(`⚠️ Balas teks atau dokumen agar bisa disimpan.`)
    } catch (e) {
      await m.reply(`❌ Gagal menyimpan file:\n${e.message}`)
    }
    return
  }

  // === GET FILE (.get / .gp / .getp) ===
  if (cmd === "get" || cmd === "gp" || cmd === "getp") {
    if (!text) return m.reply(`📂 Gunakan:\n${usedPrefix}get <path>`)
    const filePath = path.resolve(text)

    if (!fs.existsSync(filePath)) return m.reply(`❌ File *${filePath}* tidak ditemukan.`)
    if (fs.lstatSync(filePath).isDirectory()) return m.reply(`⚠️ Path tersebut adalah folder.`)
    await conn.sendFile(m.chat, filePath, `${filePath}`, '', m);
    //await conn.sendFile(m.chat.id, filePath, {}, { caption: path.basename(filePath) })
    return
  }

  // === DELETE FILE (.del / .df) ===
  if (cmd === "del" || cmd === "df") {
    if (!text) return m.reply(`🗑️ Gunakan:\n${usedPrefix}del <path>`)
    const filePath = path.resolve(text)

    if (!fs.existsSync(filePath)) return m.reply(`❌ File *${filePath}* tidak ditemukan.`)
    fs.unlinkSync(filePath)
    return m.reply(`✅ File *${filePath}* berhasil dihapus.`)
  }

  // === RENAME FILE (.rename / .rf) ===
  if (cmd === "rename" || cmd === "rf") {
    if (args.length < 2)
      return m.reply(`✏️ Gunakan:\n${usedPrefix}rename <old> <new>\n\nContoh:\n${usedPrefix}rename plugins/test.js plugins/test2.js`)
    const [oldPath, newPath] = args.map(p => path.resolve(p))

    if (!fs.existsSync(oldPath)) return m.reply(`❌ File *${oldPath}* tidak ditemukan.`)
    fs.mkdirSync(path.dirname(newPath), { recursive: true })
    fs.renameSync(oldPath, newPath)
    return m.reply(`✅ Rename berhasil:\n📁 *${oldPath}*\n➡️ *${newPath}*`)
  }

  // === LIST FILE (.list / .listp / .listplugins) ===
  if (cmd === "listp" || cmd === "listplugins") {
    const dir = text || "plugins"
    const dirPath = path.resolve(dir)

    if (!fs.existsSync(dirPath)) return m.reply(`❌ Folder *${dirPath}* tidak ditemukan.`)
    if (!fs.lstatSync(dirPath).isDirectory()) return m.reply(`⚠️ Path tersebut bukan folder.`)

    const files = fs.readdirSync(dirPath)
    if (!files.length) return m.reply(`📂 Tidak ada file di *${dirPath}*`)

    const list = files
      .map((f, i) => `${i + 1}. ${f}${fs.lstatSync(path.join(dirPath, f)).isDirectory() ? "/" : ""}`)
      .join("\n")

    return m.reply(`📁 *Daftar File di ${dir}*\n\n${list}`)
  }

  // Jika tidak cocok
  return m.reply("❌ Command tidak dikenal.")
}

handler.help = ["sf", "get", "del", "rename", "listp"].map(v => v + " <path>")
handler.tags = ["owner"]
handler.command = /^(sf|sv|get|gp|getp|del|df|rename|rf|listp|listplugins)$/i
handler.owner = true

module.exports = handler