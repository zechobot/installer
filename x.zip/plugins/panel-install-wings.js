const handler = async (m, { conn, text, isOwner, isPrems, usedPrefix, command }) => {
  if (!isOwner && !isPrems) return m.reply("Fitur ini untuk owner bot!")
    let t = text.split('|');
    if (t.length < 3) return m.reply(`Contoh: *${usedPrefix}startwings* ipvps|pwvps|token_node*`);

    let ipvps = t[0].trim();
    let passwd = t[1].trim();
    let token = t[2].trim();

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd
    };

    const commands = `${token} && systemctl start wings`;
    const ssh2 = require("ssh2");
    const ress = new ssh2.Client();

    ress.on('ready', () => {
        ress.exec(commands, (err, stream) => {
            if (err) {
                m.reply('Gagal menjalankan perintah di VPS');
                ress.end();
                return;
            }

            stream.on('close', async (code, signal) => {
                await m.reply("*Berhasil menjalankan wings ✅*");
                ress.end();
            }).on('data', (data) => {
                console.log("STDOUT:", data.toString());
            }).stderr.on('data', (data) => {
                console.log("STDERR:", data.toString());
                // Opsi jika perlu input interaktif
                stream.write("y\n");
                stream.write("systemctl start wings\n");
                m.reply('Terjadi error saat eksekusi:\n' + data.toString());
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error:', err.message);
        m.reply('Gagal terhubung ke VPS: IP atau password salah.');
    }).connect(connSettings);
}

handler.help = ["startwings", "configurewings"]
handler.tags = ["owner","reseller"]
handler.command = /^(startwings|configurewings|stw)$/i

module.exports = handler
