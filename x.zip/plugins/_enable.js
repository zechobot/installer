const handler = async (m, { conn, usedPrefix, command, args, isOwner, isROwner, isBotAdmin, isAdmin }) => {
  const isEnable = /true|enable|(turn)?on|1/i.test(command)
  const chat = global.db.data.chats[m.chat]
  const user = global.db.data.users[m.sender]
  const type = (args[0] || "").toLowerCase()

  const isGroup = m.isGroup

  let isAll = false
  let isUser = false
  // 🔹 Fungsi bantu kirim respon cepat
  const replyHTML = (text) =>
    conn.sendMessage(m.chat, `<blockquote>${text}</blockquote>`, { parse_mode: "HTML" })

  const onlyGroup = () => replyHTML("⚠️ <b>Perintah ini hanya bisa digunakan di grup.</b>")
  const onlyPrivate = () => replyHTML("⚠️ <b>Perintah ini hanya bisa digunakan di chat pribadi.</b>")
  const onlyAdmin = () => replyHTML("⚠️ <b>Perintah ini hanya untuk admin grup.</b>")
  const onlyBotadm = () => replyHTML("⚠️ <b>Bot bukan admin grup.</b>")
  const onlyOwner = () => replyHTML("⚠️ <b>Perintah ini hanya untuk owner bot.</b>")
  
  switch (type) {
    // === KHUSUS GRUP ===
    case "autogempa":
    case "welcome":
    case "left":
    case "detect":
    case "antilink":
    case "antilink1":
    case "antilink2":
    case "antilink3":
    case "antilink4":
    case "antibot5":
    case "antilink6":
    case "autodl":
    case "antitoxic":
    case "antivoice":
    case "antivideo":
    case "antiaudio":
    case "antifoto":
    case "antisticker":
    case "mute":
      if (!isGroup) return onlyGroup()
      if (isBotAdmin) return onlyBotadm()
      if (!isOwner && !isAdmin) return onlyAdmin()
      switch (type) {
        case "autogempa": chat.autoGempa = isEnable; break
        case "welcome": chat.welcome = isEnable; break
        case "left": chat.left = isEnable; break
        case "detect": chat.detect = isEnable; break
        case "antilink": chat.antilink = isEnable; break
        case "antilink1": chat.antilink1 = isEnable; break
        case "antilink2": chat.antilink2 = isEnable; break
        case "antilink3": chat.antilink3 = isEnable; break
        case "antilink4": chat.antilink4 = isEnable; break
        case "antilink5": chat.antilink5 = isEnable; break
        case "antilink6": chat.antilink6 = isEnable; break
        case "antibot": chat.antiBot = isEnable; break
        case "autodl": chat.autoDL = isEnable; break
        case "antivoice": chat.antiVoice = isEnable; break
        case "antivideo": chat.antiVideo = isEnable; break
        case "antiaudio": chat.antiAudio = isEnable; break
        case "antifoto": chat.antiFoto = isEnable; break
        case "antisticker": chat.antiSticker = isEnable; break
        case "antitoxic": chat.antiToxic = isEnable; break
        case "mute": chat.mute = isEnable; break
      }
      break

    // === KHUSUS PRIVATE ===
    case "autolevelup":
      if (!isROwner) return onlyOwner()
      if (isGroup && !isOwner && !isROwner) return onlyPrivate()
      user.autolevelup = isEnable
      isUser = true
      break

    // === KHUSUS OWNER BOT ===
    case "public":
    case "restrict":
    case "gconly":
    case "grouponly":
    case "pconly":
    case "privateonly":
      if (!isROwner) return onlyOwner()
      isAll = true
      global.opts = global.opts || {}
      switch (type) {
        case "public": global.opts.self = !isEnable; break
        case "restrict": global.opts.restrict = isEnable; break
        case "gconly":
        case "grouponly": global.opts.gconly = isEnable; break
        case "pconly":
        case "privateonly": global.opts.pconly = isEnable; break
      }
      break

    default:
      const text = `
<b>List opsi yang tersedia:</b>
│ <b>welcome</b>
│ <b>left</b>
│ <b>antilink (antilink ALL)</b>
│ <b>antilink1 (antilink TELE/WA)</b>
│ <b>antilink2 (antilink Ig)</b>
│ <b>antilink3 (antilink TT)</b>
│ <b>antilink4 (antilink FB)</b>
│ <b>antilink5 (antilink YT)</b>
│ <b>antilink6 (antilink BKP)</b>
│ <b>antitoxic</b>
│ <b>antifoto</b>
│ <b>antivoice</b>
│ <b>antivideo</b>
│ <b>antiaudio</b>
│ <b>antisticker</b>
│ <b>public</b>
│ <b>restrict</b>
│ <b>mute</b></blockquote>

<blockquote>📌 <b>Contoh:</b>
${usedPrefix}enable welcome
${usedPrefix}disable welcome
${usedPrefix}on antifoto
${usedPrefix}off antifoto`.trim()
return replyHTML(text)
}
  // === Konfirmasi hasil ===
  const textS = `✅ <b>${type}</b> berhasil di <b>${isEnable ? "aktifkan" : "nonaktifkan"}</b> \n\n<b>${
      isAll ? "untuk seluruh bot" : isUser ? "untuk user ini" : "untuk grup ini"
    }</b>`;
    replyHTML(textS)
}
handler.help = ["enable", "disable"].map(v => v + " <fitur>")
handler.tags = ["group", "owner"]
handler.command = /^((en|dis)able|(tru|fals)e|(turn)?o(n|ff))$/i

module.exports = handler