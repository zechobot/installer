const handler = async (m, { conn, isOwner, isReseller, isPrems, command }) => {
  if (!isOwner && !isReseller && !isPrems) return m.reply('❌ Fitur ini hanya untuk developer bot');

  try {
    const domains = Object.keys(global.cpanel);
    if (!domains.length) return m.reply('❌ Tidak ada panel!');

    // --- Build inline keyboard panel
    const keyboard = domains.map((domain, i) => [
      { text: `Panel ${i + 1}`, callback_data: `sandy_panel_${i + 1}` }
    ]);

    // --- Build caption
    let caption = '*Daftar Panel:*\n\n';
    domains.forEach((domain, i) => {
      caption += `*${i + 1}.* ${domain}\n`;
    });
    caption += `\nKlik tombol panel untuk membuka panel`;

    // --- Kirim pesan
    const imageUrl = 'https://lann.pw/get-upload?id=uploader-api-1:1752838394888.jpg';
    await conn.sendPhoto(m.chat, imageUrl, {
     caption,
     parse_mode: 'Markdown',
     reply_markup: { inline_keyboard: keyboard },
    });

  } catch (err) {
    console.error('List handler error:', err);
    await m.reply(`❌ Error: ${err.message}`);
  }
};

handler.help = ['list'];
handler.tags = ['reseller', 'owner'];
handler.command = /^(list)$/i;

module.exports = handler;
