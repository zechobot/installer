const axios = require("axios");

const handler = async (m, { conn, isOwner, isPrems }) => {
  if (!isOwner && !isPrems)
    return m.reply("❌ Fitur ini hanya untuk Owner atau Reseller!");
  const sentMessage = await conn.sendMessage(m.chat, `<blockquote>⏳ Memeriksa penggunaan CPU semua server di semua panel...\n\nBatas CPU wajar: <b>70%</b>\nHarap tunggu beberapa detik...</blockquote>`,
    {
    parse_mode: "HTML"
  });
 
  let chatreplay = sentMessage.chat.id;
  let msgreplay = sentMessage.message_id;
  
  (async () => {
    const results = [];
    const cpuAlerts = [];

    const domains = Object.keys(global.cpanel);
    for (let i = 0; i < domains.length; i++) {
      const panelDomain = domains[i];
      const panelConfig = global.cpanel[panelDomain];
      const serverName = ` SERVER ${i + 1}`;
      try {
        // --- Cek apakah panel online
        const check = await axios.get(`${panelDomain}/api/application/servers?per_page=1`, {
          headers: { Authorization: `Bearer ${panelConfig.apikey}` },
          timeout: 7000,
        });

        if (check.status === 200) {
          results.push(`✅ <b>${serverName}</b> — ONLINE`);
        } else {
          results.push(`❌ <b>${serverName}</b> — OFFLINE (Status: ${check.status})`);
          continue;
        }

        // --- Ambil daftar server
        const servers = check.data.data || [];
        if (!servers.length) continue;

        // --- Cek CPU tiap server
        for (const srv of servers) {
          const { name, uuid } = srv.attributes;
          try {
            const res = await axios.get(`${panelDomain}/api/client/servers/${uuid}/resources`, {
              headers: { Authorization: `Bearer ${panelConfig.capikey}` },
              timeout: 5000,
            });

            const info = res.data.attributes.resources;
            const cpu = info.cpu_absolute || 0;

            if (cpu > 80) {
              cpuAlerts.push(`🚨 <b>${serverName}</b>: <code>${name}</code> — ${cpu.toFixed(1)}%`);
            }
          } catch {
            // jika gagal ambil data cpu
          }
        }
      } catch (err) {
        const reason =
          err.response
            ? `Status: ${err.response.status}`
            : err.code === "ECONNABORTED"
              ? "Timeout"
              : "Tidak bisa dijangkau";
        results.push(`❌ <b>${serverName}</b> — ${reason}`);
      }
    }

    // --- Susun hasil akhir
    let text = `🧠 <b>Status Server Bot</b>\n\n${results.join("\n")}`;
    if (cpuAlerts.length > 0) {
      text += `\n\n⚙️ <b>Server dengan CPU tinggi:</b>\n${cpuAlerts.join("\n")}`;
    } else {
      text += `\n\n✅ Tidak ada server dengan CPU tinggi.`;
    }

    await conn.editMessageText(
      `<blockquote>${text}</blockquote>`,
      {
        chat_id: chatreplay,
        message_id: msgreplay,
        parse_mode: "HTML"
      }
    );
  })();
};

handler.help = ["srvstatus"];
handler.tags = ["owner", "reseller"];
handler.command = /^(srvstatus|statussrv|serverstatus)$/i;

module.exports = handler;
