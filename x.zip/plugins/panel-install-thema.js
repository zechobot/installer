const { Client } = require("ssh2");
const ress = new Client();

const handler = async (m, { conn, text, isOwner, isPrems, usedPrefix, command }) => {
 if (m.isGroup && !isOwner && !isPrems) return m.reply("⚠️ Perintah ini hanya bisa digunakan di chat pribadi.");
  if (!isOwner && !isPrems) return m.reply("Fitur ini untuk owner bot!")

  const t = text.split('|');
  if (t.length < 2) return m.reply(`*Contoh :* ${usedPrefix + command} ipvps|pwvps`)
  const ipvps = t[0].trim();
  const passwd = t[1].trim();
  const connSettings = {
      host: ipvps,
      port: 22,
      username: 'root',
      password: passwd
  };
  const commandx = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
  ress.on('ready', async () => {
      ress.exec(commandx, async (err, stream) => {
          if (err) {
              console.error("Exec error:", err);
              ress.end();
              return;
          }
          stream.stderr.on('data', (data) => {
              const stderrOutput = data.toString().toLowerCase();
                  stream.write("skyzodev\n");
                  stream.write("1\n");
                  stream.write("2\n");
                  stream.write("https://t.me/allgamemarket\n");
                  stream.write("https://t.me/allgamemarket\n");
                  stream.write("https://t.me/allgamemarket\n");
          });

          stream.on('close', async (code, signal) => {
              ress.end();
          });

          stream.on('data', (data) => {
              console.log(data.toString());
          });
      });
  }).on('error', async (err) => {
      console.error('Connection Error:', err);
  }).connect(connSettings);

}

handler.help = ["installthema"]
handler.tags = ["reseller", "owner"]
handler.command = /^(installthema)$/i

module.exports = handler
