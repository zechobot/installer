const { createDnsRecord, deleteDnsRecord } = require("../lib/csubdo");
const handler = async (m, { conn, text, isROwner, isReseller, isOwner, isPrems, args, usedPrefix, command }) => {

    if (!isOwner && !isReseller) return m.reply(`Fitur ini hanya untuk developer bot`);

    switch (command) {
        case "subdo":
        case "subdomain":
        case "domain": {
            if (!text) {
                const obj = Object.keys(subdomain);
                let teks = `\n`;
                obj.forEach((domain, index) => {
                    teks += `*${index + 1}.* ${domain}\n`;
                });
                teks += `\nContoh :\n*${usedPrefix}${command}* 2 host|ipvps\n`;
                return m.reply(teks)
            } if (!args[0] || isNaN(args[0])) return m.reply("Domain tidak ditemukan!")
            const result = await createDnsRecord({ args, text });
            if (!result.success) return m.reply(result.message)
            if (result.success) return m.reply(result.message)
        }
            break;

        case "delsubdo":
        case "delsubdomain":
        case "deldomain": {
            if (!text) {
                const obj = Object.keys(subdomain);
                let teks = `\n`;
                obj.forEach((domain, index) => {
                    teks += `*${index + 1}.* ${domain}\n`;
                });
                teks += `\nContoh :\n*${usedPrefix}${command} 2 host|ipvps\n`;
                return m.reply(teks)
            }
            const result = await deleteDnsRecord({ args, text });
            if (!result.success) return m.reply(result.message)
            if (result.success) return m.reply(result.message)
        }
            break;
    }
}

handler.help = ["subdo", "subdomain", "domain", "getsubdo", "delsubdo", "delsubdomain", "deldomain"]
handler.tags = ["subdomain", "owner", "reseller"]
handler.command = /^(subdo|subdomain|domain|delsubdo|delsubdomain|deldomain)$/i

module.exports = handler
