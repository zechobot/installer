const axios = require('axios');
const tiktok2 = require('../lib/tiktok'); // pastikan modul ini ada dan export function
const fs = require('fs');
const path = require('path');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`Masukkan URL!\n\nContoh:\n${usedPrefix + command} https://vt.tiktok.com/ZSY8XguF2/`); 
  }

  if (!/tiktok/gi.test(text)) {
    return m.reply(`URL tidak valid atau bukan dari TikTok!`);
  }

  try {
   m.reply(wait);
    const data = await tiktok2(text);
    console.log(data);

    let caption = `🎬 *Title:* ${data.title || '-'}\n`;

    // kirim video tanpa watermark
    if (data.no_watermark) {
      await conn.sendVideo(m.chat, data.no_watermark, {
        caption,
        reply_to_message_id: m.message_id
      });
    } else {
      await conn.sendVideo(m.chat, data.watermark, {
        caption,
        reply_to_message_id: m.message_id
      });
    }

    // kirim audio jika tersedia
    if (data.music && data.music.startsWith('http')) {
      const audioBuffer = await axios.get(data.music, { responseType: 'arraybuffer' });
      const tempFile = path.join(__dirname, '../tmp', `${data.title}.mp3`);
      fs.writeFileSync(tempFile, Buffer.from(audioBuffer.data));

      await conn.sendAudio(m.chat, tempFile, {
        title: data.title || 'TikTok Music',
        reply_to_message_id: m.message_id
      });

      fs.unlinkSync(tempFile); // hapus file sementara
    }

  } catch (err) {
    console.error(err);
    await conn.sendMessage(
      m.chat,
      { text: `❌ Terjadi kesalahan: ${err.message}` },
      { reply_to_message_id: m.message_id }
    );
  }
};

handler.help = ['tiktok', 'tt', 'ttdl', 'ttnowm', 'tiktokdl', 'tiktoknowm'];
handler.tags = ['downloader'];
handler.command = /^tiktok|tt|ttdl|ttnowm|tiktokdl|tiktoknowm$/i;

handler.limit = true;
handler.group = false;
handler.premium = false;
handler.owner = false;
handler.admin = false;
handler.botAdmin = false;
handler.private = false;

module.exports = handler;