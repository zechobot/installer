const fs = require("fs");
const { CatBox } = require("../lib/uploader.js"); // CatBox atau uploader lain

const handler = async (m, { conn }) => {
 try {
  // Ambil media dari reply atau pesan sendiri
  let target = null;
  if (m.quoted && m.quoted.isMedia) {
    target = m.quoted;
  } else if (m.isMedia) {
    target = m;
  }
  if (!target) return m.reply("📌 Balas atau kirim media untuk di-upload!");

  let buffer;
  try {
   buffer = await target.download();
  } catch (e) {
   return m.reply("❌ Gagal mengunduh media.");
  }
  if (!buffer) return m.reply("Tidak ada media untuk diproses!");

  // Upload ke server (misal CatBox)
  let url;
  try {
    const fileBuffer = fs.readFileSync(buffer);
   url = await CatBox(fileBuffer);
  } catch (e) {
    console.error("❌ Terjadi kesalahan:", e);
   return m.reply("❌ Gagal meng-upload media.");
  }

  // Kirim ulang hasil sesuai tipe media
  try {
   const mime = target.mimetype || "";
   if (mime.startsWith("image/") || target.sticker) {
    await conn.sendPhoto(m.chat, url, {
     caption: `✅ Media berhasil di-upload!\n${url}`,
     parse_mode: "HTML",
     reply_to_message_id: m.id,
    });
   } else if (mime.startsWith("video/")) {
    await conn.sendVideo(m.chat, url, {
     caption: `✅ Media berhasil di-upload!\n${url}`,
     reply_to_message_id: m.id,
    });
   } else if (mime.startsWith("audio/")) {
    await conn.sendAudio(m.chat, url, {
     caption: `✅ Media berhasil di-upload!\n${url}`,
     reply_to_message_id: m.id,
    });
   }
   return m.reply("Media Tidak Di Dukung");
  } catch (e) {
   console.error("⚠️ Gagal kirim media, fallback ke teks:", e);
   m.reply(`✅ Media berhasil di-upload:\n${url}`);
  }

 } catch (err) {
  console.error("❌ Terjadi kesalahan:", err);
  m.reply(`❌ Terjadi kesalahan: ${err.message}`);
 }
};

handler.help = ["tourl"];
handler.tags = ["tools", "ai", "media"];
handler.command = /^(tourl)$/i;

module.exports = handler;