const fs = require("fs");
const remini = require("../lib/remini.js");

const handler = async (m, { conn }) => {
  try {
    // m diasumsikan adalah objek message yang di-wrap oleh smsg (Jadi m.quoted, m.isMedia, m.download, dll ada)
    // Pilih target: jika membalas media -> gunakan quoted, kalau tidak -> pakai pesan itu sendiri (jika media)
    let target = null;
    if (m.quoted && m.quoted.isMedia) {
      target = m.quoted;
    } else if (m.isMedia) {
      target = m;
    }

    if (!target) {
      return m.reply("📸 Balas foto atau stiker yang ingin di-HD-kan menggunakan perintah ini!");
    }

    // Hanya izinkan foto atau stiker (cek mediaType / mimetype)
    const isPhotoOrSticker =
      target.mediaType === "photo" ||
      target.mediaType === "sticker" ||
      (typeof target.mimetype === "string" && target.mimetype.startsWith("image/"));

    if (!isPhotoOrSticker) {
      return m.reply("⚠️ Hanya foto atau stiker yang bisa di-HD-kan!");
    }

    // Download buffer
    let buffer;
    try {
      // target.download harus mengembalikan Buffer (sesuai smsg)
      buffer = await target.download();
    } catch (e) {
      console.error("Download error:", e);
      return m.reply("❌ Gagal mengunduh gambar.");
    }

    if (!buffer) return m.reply("Tidak ada media untuk diproses!");

    // Proses HD dengan remini (assume remini menerima Buffer dan mode 'upscale', mengembalikan URL atau Buffer)
    let imageResult;
    try {
      const fileBuffer = fs.readFileSync(buffer);
      imageResult = await remini(fileBuffer, "upscale");
    } catch (e) {
      console.error("Remini error:", e);
      return m.reply("❌ Gagal memproses gambar HD.");
    }

    // Kirim hasil — coba kirim sebagai foto, kalau gagal fallback ke teks URL
    try {
      // Jika library conn punya method sendPhoto
      if (conn.sendPhoto) {
        await conn.sendPhoto(m.chat, imageResult, {
          caption: `✅ <b>Foto berhasil di-HD-kan!</b>`,
          parse_mode: "HTML",
          reply_to_message_id: m.id,
        });
      } else {
        // fallback: kirim sebagai file/document
        await conn.sendMessage(m.chat, imageResult, {
          caption: `✅ <b>Foto berhasil di-HD-kan!</b>`,
          parse_mode: "HTML",
          reply_to_message_id: m.id,
        });
      }
    } catch (e) {
      console.error("⚠️ Gagal kirim via sendPhoto, fallback ke teks:", e);
      // Jika imageResult berupa URL, kirim URL; kalau Buffer, simpan sementara lalu kirim (opsional)
      if (typeof imageResult === "string") {
        return m.reply(`✅ HD Image:\n${imageResult}`);
      } else {
        return m.reply("✅ Gambar HD telah diproses, tetapi gagal dikirim oleh bot.");
      }
    }
  } catch (err) {
    console.error("❌ Gagal memproses HD:", err);
    m.reply(`❌ Terjadi kesalahan: ${err.message || err}`);
  }
};

handler.help = ["hd", "remini"];
handler.tags = ["tools", "ai", "photo"];
handler.command = /^(hd|remini)$/i;

module.exports = handler;