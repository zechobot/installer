const axios = require("axios");

const handler = async (m, { conn, isOwner }) => {
  if (!isOwner) return m.reply("❌ Fitur ini hanya untuk Owner!");

  const sentMessage = await conn.sendMessage(
    m.chat, `<blockquote>⏳ Mengecek status semua server di semua panel...\n\nStatus yang dicek: <b>Online</b> & <b>Offline</b>\nHarap tunggu beberapa detik...</blockquote>`,
       {
        parse_mode: "HTML",
    }
  );

  const chatreplay = sentMessage.chat.id;
  const msgreplay = sentMessage.message_id;

  (async () => {
    try {
      const results = [];
      const domains = Object.keys(global.cpanel);

      for (let i = 0; i < domains.length; i++) {
        const panelDomain = domains[i];
        const panelConfig = global.cpanel[panelDomain];
        const panelName = `Panel ${i + 1}`;

        results.push(`🧩 <b>${panelName}</b>\n🌐 <code>${panelDomain}</code>`);

        try {
          // Ambil semua server
          
          let page = 1;
          let allServers = [];
          let hasMore = true;

          while (hasMore) {
            const response = await axios.get(`${panelDomain}/api/application/servers?page=${page}`, {
              headers: {
                'Authorization': `Bearer ${panelConfig.apikey}`
              }
            });
            const result = response.data;
            if (result.errors) throw new Error(`Gagal mengambil daftar server: ${result.errors[0].detail}`);
            allServers = allServers.concat(result.data);
            hasMore = result.meta.pagination.current_page < result.meta.pagination.total_pages;
            page++;
          }

          if (allServers.length === 0) {
            results.push("📭 Tidak ada server di panel ini.\n");
            continue;
          }

          const onlineServers = [];
          const offlineServers = [];
          const unknownServers = [];

          for (const srv of allServers) {
            const serverUuid = srv.attributes.uuid;
            const serverName = srv.attributes.name;
            const serverId = srv.attributes.id;

            let state;

            try {
              
              const resource = await axios.get(`${panelDomain}/api/client/servers/${serverUuid}/resources`, {
                headers: {
                  'Authorization': `Bearer ${panelConfig.capikey}`
                },
                timeout: 5000,
              });

              state = resource.data.attributes.current_state;
              
            } catch (err) {
              // fallback jika gagal ambil data
              state = "unknown";
            }
              if (state === "running") {
              onlineServers.push(serverName);
            } else if (state === "starting") {
              onlineServers.push(serverName);
            } else if (state === "online") {
              onlineServers.push(serverName);
            } else if (state === "offline") {
              offlineServers.push(serverName);
            } else if (state === "stopped") {
              offlineServers.push(serverName);
            } else {
              unknownServers.push(`${serverName} (${state})`);
            }
          }

          results.push(
            `🟢 Online: ${onlineServers.length}\n🔴 Offline: ${offlineServers.length}\n⚪ Unknown: ${unknownServers.length}`
          );

          if (onlineServers.length)
            results.push(
              `\n<b>Online:</b>\n${onlineServers.map((n) => `• ${n}`).join("\n")}`
            );

          if (offlineServers.length)
            results.push(
              `\n<b>Offline:</b>\n${offlineServers.map((n) => `• ${n}`).join("\n")}`
            );

          if (unknownServers.length)
            results.push(
              `\n<b>Unknown:</b>\n${unknownServers.map((n) => `• ${n}`).join("\n")}`
            );

          results.push("\n───────────────────────────\n");
        } catch (err) {
          console.log(err);
          results.push(
            `❌ Gagal mengakses panel ini: ${
              err.response ? `HTTP ${err.response.status}` : err.message
            }\n───────────────────────────\n`
          );
        }
      }

      const summary = `<blockquote>📊 <b>Hasil Pengecekan Status Server</b>\n\n${results.join(
        "\n"
      )}</blockquote>`;

      await conn.editMessageText(summary,
        {
          chat_id: chatreplay,
          message_id: msgreplay,
          parse_mode: "HTML"
        }
      );
    } catch (err) {
      await conn.editMessageText(
        `<blockquote>❌ Terjadi kesalahan: ${err.message}</blockquote>`,
        {
          chat_id: chatreplay,
          message_id: msgreplay,
          parse_mode: "HTML"
        }
      );
    }
  })();
};

handler.help = ["ceksrv", "cekserver"];
handler.tags = ["owner", "reseller"];
handler.command = /^(ceksrv|cekserver)$/i;
handler.owner = true;

module.exports = handler;
