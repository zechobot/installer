// === HANDLER CREATE PANEL ===
const handler = async (m, { conn, args, isROwner, isReseller, isOwner, isPrems, usedPrefix, command }) => {
  if (!isROwner && !isOwner && !isPrems && !isReseller)
    return m.reply("⚠️ Fitur ini hanya untuk Reseller dan Owner bot!");

  let username, idTelegram;

  if (m.quoted) {
    username = args[0];
    idTelegram = m.quoted.sender;
  } else if (args[0] && args[0].includes(",")) {
    [username, idTelegram] = args[0].split(",").map(s => s.trim());
  } else if (m.sender) {
    username = args[0];
    idTelegram = m.sender;
  }

  if (!username || !idTelegram)
    return m.reply(
      `❗ Tag, reply, atau kirim ID user!\n\nContoh:\n${usedPrefix}${command} username reply pesan\n${usedPrefix}${command} username,123456789`
    );

  // === Simpan konteks sementara untuk user ini ===
  if (!conn._createCache) conn._createCache = {};
  conn._createCache[m.sender] = { username, idTelegram, command };

  // === Buat tombol list server dari global.cpanel ===
  const cpanels = Object.keys(global.cpanel || {});
  if (!cpanels.length) return m.reply("❌ Tidak ada server di global.cpanel!");

  const keyboard = cpanels.map((domain, i) => [
    { text: `🌐 Server ${i + 1}`, callback_data: `crate_srv_${i + 1}` }
  ]);

  const teks = `🛠 Pilih server untuk membuat panel *${username}*\n\nCommand: ${command.toUpperCase()}`;

  await conn.sendMessage(m.chat, teks, {
    reply_markup: { inline_keyboard: keyboard },
  });
  
console.log(idTelegram)
};

// === REGISTER COMMANDS ===
handler.help = [
  "1gb  <username>", "2gb  <username>", "3gb  <username>", "4gb  <username>", "5gb  <username>", "6gb  <username>", "7gb  <username>", "8gb  <username>", "9gb  <username>", "10gb  <username>", "unli"
];
handler.tags = ["reseller", "owner"];
handler.command = /^(1gb|2gb|3gb|4gb|5gb|6gb|7gb|8gb|9gb|10gb|unli)$/i;

module.exports = handler;