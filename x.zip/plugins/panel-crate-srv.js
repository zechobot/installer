// === HANDLER CREATE PANEL ===
const handler = async (m, { conn, args, isROwner, isReseller, isOwner, usedPrefix, command }) => {
  if (!isROwner && !isOwner && !isReseller)
    return m.reply("⚠️ Fitur ini hanya untuk Reseller dan Owner bot!");

  let username, idTelegram, userid;

  if (m.quoted) {
    username = args[0];
    userid = args[1];
    idTelegram = m.quoted.sender;
  } else if (args[0] && args[0].includes(",")) {
    [username, userid, idTelegram] = args[0].split(",").map(s => s.trim());
  } else if (m.sender) {
    username = args[0];
    userid = args[1];
    idTelegram = m.sender;
  }

  if (!username || !idTelegram || !userid)
    return m.reply(
      `❗ Tag, reply, atau kirim ID user!\n\nContoh:\n${usedPrefix}${command} username id user reply pesan\n${usedPrefix}${command} username,userid,123456789`
    );

  // === Simpan konteks sementara untuk user ini ===
  if (!conn._createCache) conn._createCache = {};
  conn._createCache[m.sender] = { username, userid };

  // === Buat tombol list server dari global.cpanel ===
  const cpanels = Object.keys(global.cpanel || {});
  if (!cpanels.length) return m.reply("❌ Tidak ada server di global.cpanel!");

  const keyboard = cpanels.map((domain, i) => [
    { text: `🌐 Server ${i + 1}`, callback_data: `crate_srvx_${i + 1}` }
  ]);
  
  const teks = `<blockquote>🛠 <b>Pilih server untuk membuat panel</b> <b>${username}</b></blockquote>`;
  
  await conn.sendMessage(m.chat, teks, {
    reply_markup: { inline_keyboard: keyboard },
    parse_mode: "HTML" // ⚠️ harus di sini, bukan di reply_markup
  });
  
};

// === REGISTER COMMANDS ===
handler.help = [
  "cratesrv <username> <id user>", "addsrv <username> <id user>", "addserver <username> <id user>", "ads <username> <id user>"
];
handler.tags = ["reseller", "owner"];
handler.command = /^(ads|addsrv|cratesrv|addserver)$/i;

module.exports = handler;