const { totalmem, freemem, cpus, platform, hostname } = require('os');
const { performance } = require('perf_hooks');
const { sizeFormatter } = require('human-readable');

const format = sizeFormatter({
  std: 'JEDEC',
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
});

// fungsi konversi ms ke HH,MM,SS
function msToHMS(ms) {
  let totalSeconds = Math.floor(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  totalSeconds %= 3600;
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${String(h).padStart(2,'0')},${String(m).padStart(2,'0')},${String(s).padStart(2,'0')}`;
}

const handler = async (m, { conn }) => {
  const used = process.memoryUsage();
  const _cpus = cpus().map(cpu => {
    cpu.total = Object.values(cpu.times).reduce((a, t) => a + t, 0);
    return cpu;
  });

  // mulai timer sebelum kirim
  const start = performance.now();
  // kirim pesan kosong / reply dummy untuk ukur delay
  const sentMsg = await m.reply('🏓 Mengukur ping...');
  const end = performance.now();

  const delayMs = end - start; // delay jaringan + eksekusi
  const speedFormatted = msToHMS(delayMs);

  const runtimeInSeconds = Math.floor((Date.now() - global.startTime) / 1000);
  const d = new Date();
  const times = d.toLocaleTimeString('id', { hour12: false });

  const txt = `
🏓 PING
${speedFormatted} per detik

⏱ RUNTIME
${runtimeInSeconds}s

💻 SERVER
🛑 RAM: ${format(totalmem() - freemem())} / ${format(totalmem())}
🔴 Heap Used: ${(used.heapUsed/1024/1024).toFixed(2)} MB
🔵 Free RAM: ${format(freemem())}
🖥 OS: ${platform()} (${hostname()})
⏰ Server Time: ${times}

🖧 CPU Usage
${_cpus.map((c,i)=> `${i+1}. ${c.model} - ${(100*c.times.user/c.total).toFixed(2)}% user, ${(100*c.times.sys/c.total).toFixed(2)}% sys`).join('\n')}
`.trim();

  await m.reply(txt);
};

handler.help = ['ping','speed'];
handler.tags = ['info'];
handler.command = /^(ping|speed|pong)$/i;
module.exports = handler;
