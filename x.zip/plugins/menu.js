const handler = async (m, { conn }) => {
  try {
    const user = global.db.data.users[m.sender];
    if (!user) return m.reply('User tidak ditemukan.');
    const limit = user.limit || 0;
    const isPremium = user.premium || user.premiumTime > Date.now();
    const premiumTime = user.premiumTime > Date.now()
      ? new Date(user.premiumTime).toLocaleDateString('id-ID')
      : 'Tidak ada';
    const text = `
<b>${global.ucapan()}  <i>${m.name || m.sender }</i></b>
<b>ID:</b> <code>${m.sender}</code>
<b>Premium:</b> ${isPremium ? '✅ Ya' : '❌ Tidak'}
<b>Limit:</b> <code>${limit}</code>
<b>Level:</b> <code>${user.level || 1}</code>
<b>EXP:</b> <code>${user.exp || 0}</code>
<b>Premium Time:</b> ${premiumTime}

<i>Tap tombol di bawah untuk lanjut.</i>
`.trim();

    await conn.sendMessage(m.chat, text, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🡰', callback_data: 'menu_back' },
            { text: '✖', callback_data: 'menu_delet' },
            { text: '🡲', callback_data: 'menu_next' }
          ]
        ]
      }
    });
  } catch {
    m.reply('Terjadi kesalahan.');
  }
};

handler.help = ['menu', 'help', 'start'];
handler.tags = ['main'];
handler.command = /^(menu|help|start|\?)$/i;

module.exports = handler;