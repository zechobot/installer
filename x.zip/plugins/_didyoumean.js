// BabyBotz MultiDevice - DidYouMean Command Suggestion
let didyoumean = require('didyoumean');
let similarity = require('similarity');

let handler = m => m;

handler.before = function (m, { conn, usedPrefix }) {
  try {
    if (!m || !m.text || !usedPrefix) return true; // skip kalau bukan pesan teks

    // ambil isi tanpa prefix
    let noPrefix = m.text.startsWith(usedPrefix)
      ? m.text.slice(usedPrefix.length).trim()
      : m.text.trim();

    // ambil semua command dari plugin aktif
    let alias = Object.values(global.plugins)
      .filter(v => v.help && !v.disabled)
      .flatMap(v => v.help);

    if (!alias || alias.length === 0) return true;

    // cari yang paling mirip
    let mean = didyoumean(noPrefix, alias);
    if (!mean) return true;

    let sim = similarity(noPrefix, mean);
    let similarityPercentage = parseInt(sim * 100);

    // kalau command cocok (identik), skip
    if (noPrefix.toLowerCase() === mean.toLowerCase()) return true;

    // hanya tampil kalau kemiripan tinggi (≥ 70%)
    if (similarityPercentage < 70) return true;

    // fungsi escape HTML untuk keamanan
    const escapeHTML = (str = '') =>
      String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');

    const suggestedCommand = escapeHTML(usedPrefix + mean);
    const responseHtml = `<blockquote>
<b>Perintah yang kamu masukkan keliru.</b>

➠ <code>${suggestedCommand}</code>
➠ Similar results: ${escapeHTML(String(similarityPercentage))}%
</blockquote>`;

    // kirim respons
    if (typeof m.reply === 'function') {
      m.reply(responseHtml, { parse_mode: 'HTML' });
    } else if (typeof conn?.sendMessage === 'function') {
      conn.sendMessage(m.chat, responseHtml, { parse_mode: 'HTML' });
    } else {
      console.log(`Saran command: ${suggestedCommand} (${similarityPercentage}%)`);
    }

  } catch (err) {
    console.error('❌ DidYouMean Error:', err);
  }

  return true;
};

module.exports = handler;