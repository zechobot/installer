const fs = require("fs")
const util = require("util")
const chalk = require("chalk")
const moment = require("moment-timezone")

const isNumber = (x) => typeof x === "number" && !isNaN(x)
const delay = (ms) => isNumber(ms) && new Promise((resolve) => setTimeout(resolve, ms))

function isRealError(error) {
  return error instanceof Error || (error && error.constructor && error.constructor.name === "Error")
}

async function rlimit() {
  const now = moment().tz("Asia/Makassar")
  const resetTime = moment().tz("Asia/Makassar").startOf('day')

  if (now.isSameOrAfter(resetTime)) {
    for (const userId in global.db.data.users) {
      const user = global.db.data.users[userId]
      if (user.lastReset !== resetTime.format('YYYY-MM-DD')) {
        user.limit += 30
        user.lastReset = resetTime.format('YYYY-MM-DD')
      }
    }
  }
}

module.exports = {
  async handler(m, msgx) {
    await global.loadDatabase()
    if (global.db.data == null) return
    if (!m) return
    try {
      m.exp = 0
      m.limit = false

      await rlimit()

      if (m.callbackQuery && !m.isSimulated) {
        await this.answerCallbackQuery(m.callbackQuery.id).catch(() => {})
        await this.answerCallbackQuery(m.callbackQuery.id, { text: "⏩ Bergeser...", show_alert: false });
      }

      const user = global.db.data.users[m.sender]
      if (typeof user !== "object") global.db.data.users[m.sender] = {}
      if (user) {
        if (!isNumber(user.saldo)) user.saldo = 0
        if (!isNumber(user.exp)) user.exp = 0
        if (!isNumber(user.level)) user.level = 0
        if (!isNumber(user.limit)) user.limit = 30
        if (!("owner" in user)) user.owner = false
        if (!("registered" in user)) user.registered = false
        if (!("premium" in user)) user.premium = false
        if (!("banned" in user)) user.banned = false
        if (!isNumber(user.premiumTime)) user.premiumTime = 0
         if (!isNumber(user.premiumTime)) user.ownerTime = 0
        if (!isNumber(user.command)) user.command = 0
        if (!isNumber(user.commandTotal)) user.commandTotal = 0
        if (!isNumber(user.lastCmd)) user.lastCmd = 0
        if (!isNumber(user.chat)) user.chat = 0
        if (!isNumber(user.chatTotal)) user.chatTotal = 0
        if (!isNumber(user.lastseen)) user.lastseen = 0
        if (!("lastReset" in user)) user.lastReset = moment().tz("Asia/Makassar").format('YYYY-MM-DD')
      } else {
        global.db.data.users[m.sender] = {
          saldo: 0,
          exp: 0,
          level: 0,
          limit: global.limit,
          owner: false,
          registered: false,
          premium: false,
          banned: false,
          ownerTime: 0,
          premiumTime: 0,
          command: 0,
          commandTotal: 0,
          lastCmd: 0,
          chat: 0,
          chatTotal: 0,
          lastseen: 0,
          lastReset: moment().tz("Asia/Makassar").format('YYYY-MM-DD')
        }
      }
      const chat = global.db.data.chats[m.chat]
      if (typeof chat !== "object") global.db.data.chats[m.chat] = {}
      if (chat) {
      if (!chat.autoGempa) {
      chat.autoGempa = { status: false, lastCheck: 0, lastGempa: {} };
       } 
        if (!("isBanned" in chat)) chat.isBanned = false
        if (!("welcome" in chat)) chat.welcome = false
        if (!("left" in chat)) chat.left = false
        
        if (!("antilink" in chat)) chat.antilink = false
        if (!("antilink1" in chat)) chat.antilink1 = false
        if (!("antilink2" in chat)) chat.antilink2 = false
        if (!("antilink3" in chat)) chat.antilink3 = false
        if (!("antilink4" in chat)) chat.antilink4 = false
        if (!("antilink5" in chat)) chat.antilink5 = false
        if (!("antilink6" in chat)) chat.antilink6 = false
        
        if (!("groupres" in chat)) chat.groupres = false
        if (!("mute" in chat)) chat.mute = false
        
        if (!("antiToxic" in chat)) chat.antiToxic = false
        if (!("antiFoto" in chat)) chat.antiFoto = false
        if (!("antiVoice" in chat)) chat.antiVoice = false
        if (!("antiVideo" in chat)) chat.antiVideo = false
        if (!("antiAudio" in chat)) chat.antiAudio = false
        if (!("antiSticker" in chat)) chat.antiSticker = false
        
        if (!("sWelcome" in chat)) chat.sWelcome = "Selamat datang @user di grup @subject!"
        if (!("sBye" in chat)) chat.sBye = "Selamat tinggal @user!"
        if (!("autoDL" in chat)) chat.autoDL = false
      } else {
        global.db.data.chats[m.chat] = {
          isBanned: false,
          welcome: false,
          left: false,
          // Anti Link
          antilink: false,
          antilink1: false,
          antilink2: false,
          antilink3: false,
          antilink4: false,
          antilink5: false,
          antilink6: false,
          
          groupres: false,
          mute: false,
          // Anti all
          antiToxic: false,
          antiFoto: false,
          antiVoice: false,
          antiVideo: false,
          antiAudio: false,
          antiSticker: false,
          // Pesan welcome atau lainya
          sWelcome: "Selamat datang @user di grup @subject!",
          sBye: "Selamat tinggal @user!",
          autoDL: false,
        }
      }
      let sendercek = m.sender?.toString() || m.sender;
      // pastikan target string
      if (sendercek) sendercek = sendercek.toString()
      // pastikan struktur data tidak undefined
      const pxys = (global.ownerid && global.ownerid.length > 0 ? global.ownerid?.includes(sendercek) : false);
      const prex = (global.premid && global.premid.length > 0 ? global.premid?.includes(sendercek) : false);
      const owners = global.db?.data?.owner || [];
      const resellers = global.db?.data?.reseller || [];
      const premiums = global.db?.data?.premium || [];
      const premids = global.premid || [];
      const ownerids = global.ownerid || [];

      // cek status
      const isROwner =
      pxys ||
      ownerids.includes(sendercek);
      
      const isPrem =
      prex ||
      owners.includes(sendercek) ||
      premids.includes(sendercek) ||
      resellers.includes(sendercek) ||
      ownerids.includes(sendercek) ||
      premiums.includes(sendercek);

      const isReseller =
      owners.includes(sendercek) ||
      ownerids.includes(sendercek) ||
      resellers.includes(sendercek);
  
      const isOwner = isROwner || m.fromMe || owners.includes(sendercek);
      const isPrems = isOwner || isPrem || isReseller;
      
      
      
       if (isPrem) {
      if (!premiums.includes(sendercek)) premiums.push(sendercek);
       }
      if (isROwner) {
          
       if (!owners.includes(sendercek)) owners.push(sendercek);
       if (!resellers.includes(sendercek)) resellers.push(sendercek);
       if (!premiums.includes(sendercek)) premiums.push(sendercek);
       global.db.data.users[sendercek].owner = true
       global.db.data.users[sendercek].premium = true
      }
      
    const botInfo = await this.getChatMember(m.chat, (await this.getMe()).id);
    const userInfo = await this.getChatMember(m.chat, m.sender);
    const adminStatus = ["administrator", "creator"];
    const isAdmin = adminStatus.includes(userInfo.status);
    const isBotAdmin = adminStatus.includes(botInfo.status);
      try {
        require("./lib/print")(m, this)
      } catch (e) {
        console.log(m, m.quoted, e)
      }
      const processedCommands = new Set()

      for (const name in global.plugins) {
        const plugin = global.plugins[name]
        if (!plugin) continue
        if (plugin.disabled) continue
        // 🧩 Jalankan plugin.before() global tanpa menunggu prefix/command
  if (typeof plugin.before === "function") {
    try {
      const extra = {
        conn: this,
        FelixUserBot: global.FelixUserBot,
        msgx,
        isROwner,
        isReseller,
        isOwner,
        isPrems,
        participants: m.participants || [],
        isBotAdmin,
        isAdmin,
        Func: global.Func || {},
        text: m.text || "",
      }

      // Jika plugin.before() return false, hentikan seluruh handler
      const beforeResult = await plugin.before.call(this, m, extra)
      if (beforeResult === false) return
    } catch (e) {
      console.error(`Before Global Error (${name}):`, e)
    }
  }
        let pluginData = plugin
        let pluginHandler = null
        let beforeHandler = null

        if (typeof plugin === 'function') {
          pluginHandler = plugin
          pluginData = plugin
          if (typeof plugin.before === 'function') beforeHandler = plugin.before
        } else if (typeof plugin === 'object') {
          if (plugin.handler && typeof plugin.handler === 'function') {
            pluginHandler = plugin.handler
            pluginData = plugin
          }
          else if (plugin.default && typeof plugin.default === 'function') {
            pluginHandler = plugin.default
            pluginData = plugin.default
          }
          else if (plugin.run && plugin.run.async && typeof plugin.run.async === 'function') {
            pluginHandler = plugin.run.async
            pluginData = plugin.run
          }
          else if (typeof plugin.before === 'function' && !plugin.handler && !plugin.default && !plugin.run) {
            continue
          }
          else {
            pluginHandler = plugin
            pluginData = plugin
          }
          
          if (typeof plugin.before === 'function') {
            beforeHandler = plugin.before
          } else if (plugin.default && typeof plugin.default.before === 'function') {
            beforeHandler = plugin.default.before
          } else if (plugin.run && typeof plugin.run.before === 'function') {
            beforeHandler = plugin.run.before
          }
        }

        if (!pluginHandler || typeof pluginHandler !== "function") continue

        const str2Regex = (str) => str.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&")

        let _prefix = pluginData.customPrefix || global.prefix || "/"

        if (!Array.isArray(_prefix)) {
          _prefix = [_prefix]
        }

        let match = null
        let usedPrefix = ""

        if (m.text) {
          let textToProcess = m.text

          if (m.isGroup && textToProcess.includes('@')) {
            const botUsername = global.botname?.toLowerCase() || 'bot'
            const mentions = textToProcess.match(/@\w+/g) || []

            for (const mention of mentions) {
              const mentionName = mention.slice(1).toLowerCase()
              if (mentionName.includes(botUsername) || mentionName.includes('ztxzy_bot')) {
                textToProcess = textToProcess.replace(mention, '').trim()
                break
              }
            }
          }

          for (const prefix of _prefix) {
            if (prefix instanceof RegExp) {
              const regexMatch = prefix.exec(textToProcess)
              if (regexMatch) {
                match = [regexMatch, prefix]
                usedPrefix = regexMatch[0]
                break
              }
            } else {
              const prefixStr = String(prefix)
              if (textToProcess.startsWith(prefixStr)) {
                match = [[prefixStr], new RegExp(str2Regex(prefixStr))]
                usedPrefix = prefixStr
                break
              }
            }
          }
        }

        if (match && usedPrefix && m.text) {
          let textToProcess = m.text

          if (m.isGroup && textToProcess.includes('@')) {
            const botUsername = global.botname?.toLowerCase() || 'bot'
            const mentions = textToProcess.match(/@\w+/g) || []

            for (const mention of mentions) {
              const mentionName = mention.slice(1).toLowerCase()
              if (mentionName.includes(botUsername) || mentionName.includes('ztxzy_bot')) {
                textToProcess = textToProcess.replace(mention, '').trim()
                break
              }
            }
          }

          const noPrefix = textToProcess.replace(usedPrefix, "")
          let [command, ...args] = noPrefix.trim().split` `.filter((v) => v)
          args = args || []
          const _args = noPrefix.trim().split` `.slice(1)
          const text = _args.join` `
          command = (command || "").toLowerCase()
          const fail = pluginData.fail || global.dfail

          let isAccept = false
          let commandList = pluginData.command || pluginData.usage

          if (commandList) {
            if (commandList instanceof RegExp) {
              isAccept = commandList.test(command)
            } else if (Array.isArray(commandList)) {
              isAccept = commandList.some((cmd) =>
                cmd instanceof RegExp ? cmd.test(command) : cmd === command
              )
            } else if (typeof commandList === "string") {
              isAccept = commandList === command
            }
          }
 // 🔹 Jalankan beforeHandler per-plugin (agar .menu & didyoumean bisa hidup)
 if (plugin.before && typeof plugin.before === "function") {
  try {
    const extra = {
      match,
      usedPrefix,
      noPrefix,
      _args,
      args,
      command,
      text,
      conn: this,
      FelixUserBot: global.FelixUserBot,
      msgx,
      isROwner,
      isReseller,
      isOwner,
      isPrems,
      isPrefix: usedPrefix,
      participants: m.participants || [],
      isBotAdmin,
      isAdmin,
      Func: global.Func || {}
    }
    const beforeResult = await plugin.before.call(this, m, extra);
    if (beforeResult === false) continue;
  } catch (e) {
    console.error(`Before Error (${name}):`, e);
  }
}
          if (!isAccept) continue

          const commandKey = `${m.sender}_${command}_${Date.now()}`
          if (processedCommands.has(commandKey)) continue
          processedCommands.add(commandKey)

          m.plugin = name

          if (m.chat in global.db.data.chats || m.sender in global.db.data.users) {
            const chat = global.db.data.chats[m.chat]
            const user = global.db.data.users[m.sender]
            if (chat?.isBanned || chat?.mute) return
            if (user && user.banned) return
          }

          if (pluginData.rowner && pluginData.owner && !(isROwner || isOwner)) {
            fail("owner", m, this)
            continue
          }
          if (pluginData.rowner && !isROwner) {
            fail("rowner", m, this)
            continue
          }
          if (pluginData.owner && !isOwner) {
            fail("owner", m, this)
            continue
          }
          if (pluginData.premium && !isPrems) {
            fail("premium", m, this)
            continue
          }
          if (pluginData.reseller && !isReseller) {
            fail("premium", m, this)
            continue
          }
          if (pluginData.group && !m.isGroup) {
            fail("group", m, this)
            continue
          }
          if (pluginData.private && m.isGroup) {
            fail("private", m, this)
            continue
          }
          if (pluginData.admin && !m.isAdmin) {
            fail("admin", m, this)
            continue
          }

          m.isCommand = true
          const xp = "exp" in pluginData ? Number.parseInt(pluginData.exp) : 17
          if (xp > 200) m.reply(`⚠️ Peringatan: Pengalaman (${xp}) terlalu tinggi, disarankan tidak lebih dari 200!`)
          else m.exp += xp

          if (!isReseller && !isPrems && !isOwner && pluginData.limit) {
            const requiredLimit = pluginData.limit === true ? 1 : pluginData.limit
            if (!args || args.length === 0) {
              m.limit = false
            } else {
              if (global.db.data.users[m.sender].limit < requiredLimit) {
                if (global.db.data.users[m.sender].limit === 0) {
                  await m.reply(`Limit kamu habis`, m)
                } else {
                  await m.reply(`Limit tidak mencukupi, membutuhkan ${requiredLimit}, dan kamu hanya mempunyai ${global.db.data.users[m.sender].limit}`, m)
                }
                continue
              }
              global.db.data.users[m.sender].limit -= requiredLimit
              m.limit = requiredLimit
            }
          }


          const extra = {
            match,
            usedPrefix,
            noPrefix,
            _args,
            args,
            command,
            text,
            conn: this,
            FelixUserBot: global.FelixUserBot,
            msgx,
            isROwner,
            isReseller,
            isOwner,
            isPrems,
            isPrefix: usedPrefix,
            participants: m.participants || [],
            isBotAdmin: m.isBotAdmin,
            isAdmin: m.isAdmin,
            Func: global.Func || {}
          }

          try {
            const result = await pluginHandler.call(this, m, extra)



            if (!isReseller && !isPrems && !isOwner && pluginData.limit && typeof m.limit === 'number' && m.limit > 0) {
              const sisa = global.db.data.users[m.sender].limit
              const limitMsg = `✅ ${m.limit} limit terpakai\n💡 Sisa limit: ${sisa}`

              try {
                if (m.isGroup) {
                  // 📨 Kirim ke PM user jika command dilakukan di grup
                  m.reply(limitMsg);
                  // await this.sendMessFage(m.sender, { text: limitMsg }, { quoted: m })
                } else {
                  // 📩 Kirim langsung di private
                  m.reply(limitMsg);
                  // await this.sendMessage(m.chat, { text: limitMsg }, { quoted: m })
                }
              } catch (e) {
                console.error("Gagal kirim info limit:", e)
              }
            }
          } catch (e) {

            if (!isReseller && !isPrems && !isOwner && pluginData.limit && m.limit) {
              global.db.data.users[m.sender].limit += m.limit
              console.log(`Limit ${m.limit} tidak jadi digunakan karena terjadi error pada plugin ${name}`)
            }

            if (isRealError(e)) {
              m.error = e
              console.error(`Plugin Error (${m.plugin}):`, e)
              let text = util.format(e)
                try {
                  await this.reply(
                    global.ownerid,
                    `*Plugin Error:* ${m.plugin}\n*Sender:* ${m.sender}\n*Chat:* ${m.chat}\n*Command:* ${usedPrefix}${command} ${args.join(" ")}\n\n\`\`\`${text}\`\`\``
                  )
                } catch (notifyError) {
                  console.error("Failed to notify owner:", notifyError)
                  if (!notifyError) return
                }
              try {
                await m.reply(text)
              } catch (replyError) {
                console.error("Failed to reply error to user:", replyError)
              }
            } else {
              try {
                await m.reply(String(e))
              } catch (replyError) {
                console.error("Failed to reply to user:", replyError)
              }
            }
          } finally {
            if (typeof pluginData.after === "function") {
              try {
                await pluginData.after.call(this, m, extra)
              } catch (e) {
                console.error(`Plugin After Error (${m.plugin}):`, e)
              }
            }
          }

          break
        }
      }

      const _user = global.db.data.users[m.sender]
      const stats = global.db.data.stats
      if (m) {
        if (m.sender && _user) {
          _user.exp += m.exp
        }

        let stat
        if (m.plugin) {
          const now = +new Date()
          if (m.plugin in stats) {
            stat = stats[m.plugin]
            if (!isNumber(stat.total)) stat.total = 1
            if (!isNumber(stat.success)) stat.success = m.error != null ? 0 : 1
            if (!isNumber(stat.last)) stat.last = now
            if (!isNumber(stat.lastSuccess)) stat.lastSuccess = m.error != null ? 0 : now
          } else {
            stat = stats[m.plugin] = {
              total: 1,
              success: m.error != null ? 0 : 1,
              last: now,
              lastSuccess: m.error != null ? 0 : now,
            }
          }
          stat.total += 1
          stat.last = now
          if (m.error == null) {
            stat.success += 1
            stat.lastSuccess = now
          }
        }
      }

      if (_user) {
        _user.chat++
        _user.chatTotal++
        _user.lastseen = Date.now()
      }
    } catch (e) {
      console.error("Handler Error:", e)
    }
  },
  async participantsUpdate(msg) {
  try {
    await global.loadDatabase()

    let chatId = msg.chat?.id
    let chatTitle = msg.chat?.title || "Unknown Group"
    let eventType, userId, userName, text
    
    const chat = global.db.data.chats[chatId] || {}
    
    // === BOT DIINVITE / DIKELUARKAN DARI GRUP ===
    if (msg.my_chat_member) {
      const oldStatus = msg.my_chat_member.old_chat_member.status
      const newStatus = msg.my_chat_member.new_chat_member.status
      const user = msg.my_chat_member.new_chat_member.user
      userId = user.id
      userName = user.first_name || user.username || "Unknown"

      if (newStatus === "member" && oldStatus === "left") {
        eventType = "join"
      } else if (newStatus === "left" && oldStatus === "member") {
        eventType = "leave"
      }
    }

    // === MEMBER BARU MASUK ===
    else if (msg.new_chat_members) {
      eventType = "join"
      for (const member of msg.new_chat_members) {
        userId = member.id
        userName = member.first_name || member.username || "Unknown"

        if (!chat.welcome) return;
          text = (chat.sWelcome || "Selamat datang @user di grup @subject!")
            .replace("@user", userName)
            .replace("@subject", chatTitle)
      }
      return
    }

    // === MEMBER KELUAR ===
    else if (msg.left_chat_member) {
      eventType = "leave"
      if (!chat.left) return;
        
      const member = msg.left_chat_member
      userId = member.id
      userName = member.first_name || member.username || "Unknown"
      
       text = (chat.sBye || "Selamat tinggal @user!")
            .replace("@user", userName)
            .replace("@subject", chatTitle)
        return;
    }

    // === Validasi data ===
    if (!chatId || !userId || !eventType) return
    
    if (eventType === "join") {
    if (!chat.welcome) return;
      text = (chat.sWelcome || "Selamat datang @user di grup @subject!")
        .replace("@user", userName)
        .replace("@subject", chatTitle)
    } else if (eventType === "leave") {
    if (!chat.left) return;
      text = (chat.sBye || "Selamat tinggal @user!")
        .replace("@user", userName)
        .replace("@subject", chatTitle)
    }

    if (text) {
      try {
        await this.sendMessage(chatId, text, { parse_mode: "Markdown" })
      } catch (e) {
        console.error("Error sending participant update message:", e)
      }
    }
  } catch (e) {
    console.error("Error in participantsUpdate:", e)
  }
},
}


global.error = global.message.error;
global.dfail = async (type, m, conn) => {
  const msg = global.message?.[type] || "Perintah ini tidak bisa digunakan di sini."
  return await m.reply(msg)
}

const file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update handler.js"))
  delete require.cache[file]
})