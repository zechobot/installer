global.token = "7659363950:AAGdZPiOGVSTzSbM9f00IiAcMlJpyY6GVWM"
global.ownername = "Felixhasgawa"
global.ownerid = ["8052207089"]
global.premid = "8052207089"
global.botname = "KawairunEnginmaBot"
global.prefix = ["/", ".", "#", "!"]
global.wib = 7
global.wait = "Tunggu Sebentar..."
global.wm = "© KawairunEnginmaBot"
global.links = "https://img1.pixhost.to/images/8709/640606517_skyzo.jpg"


global.session = "Felix.txt"
global.usersbot = true
global.apiId = 26024931
 // ganti dengan apiHash kamu
global.apiHash = "6580f21260f3f4b94588babd9d0518a3"
// ganti dengan nomor telepon telegram kamu
global.phoneNumber = "6281228796368"

//######## Setting Api Orderkuota ########//
global.usernameOrderkuota = "skyzopedia"
global.tokenOrderkuota = "2088243%3AgGrny3psEWxudlfLZziQDvMPhj7Ke"
global.ApikeyRestApi = "ubot"


//######## Setting Harga Produk #########//
global.hargaPanel = 1000 //per 1gb nya
global.hargaAdp = 20000

// fungsi cpanel
global.cpanel = {
    "https://mochfelix.panelwebsite.biz.id": {
    "egg": "15",
    "loc": "1",
    "nestid": "5",
    "apikey": "ptla_2ZvHZNc8Ac8rDZSjRXut8Kf5XHXd2LctUmklvlmAfth",
    "capikey": "ptlc_oJ0V1xpGgfRDHpFFaFRpya0LwchZMi6s68IR5VBbNIp"
  },
   "https://paneltes.panelwebsite.biz.id": {
    "egg": "15",
    "loc": "1",
    "nestid": "5",
    "apikey": "ptla_3BsNv6X7RV6o15eHUTQqUsytnCIQcS6JNgiGljDhhBQ",
    "capikey": "ptlc_hzgKIIp2cRXr0hclTLi8AvL9BCOS4Y411cQzJJtCoRE"
  } 
}

global.subdomain = {
  "skypedia.qzz.io": {
    "zone": "59c189ec8c067f57269c8e057f832c74",
    "apitoken": "mZd-PC7t7PmAgjJQfFvukRStcoWDqjDvvLHAJzHF"
  }, 
  "pteroweb.my.id": {
    "zone": "714e0f2e54a90875426f8a6819f782d0",
    "apitoken": "vOn3NN5HJPut8laSwCjzY-gBO0cxeEdgSLH9WBEH"
  },
  "vipserver.web.id": {
    "zone": "e305b750127749c9b80f41a9cf4a3a53",
    "apitoken": "cpny6vwi620Tfq4vTF4KGjeJIXdUCax3dZArCqnT"
  }, 
  "mypanelstore.web.id": {
    "zone": "c61c442d70392500611499c5af816532",
    "apitoken": "uaw-48Yb5tPqhh5HdhNQSJ6dPA3cauPL_qKkC-Oa"
  },
  "panelwebsite.biz.id": {
    "zone": "2d6aab40136299392d66eed44a7b1122",
    "apitoken": "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
  },
  "privatserver.my.id": {
    "zone": "699bb9eb65046a886399c91daacb1968",
    "apitoken": "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
  },
  "serverku.biz.id": {
    "zone": "4e4feaba70b41ed78295d2dcc090dd3a",
    "apitoken": "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
  }
}
// Message
global.message = {
    rowner: "Perintah ini hanya dapat digunakan oleh _*OWNER!*_",
    owner: "Perintah ini hanya dapat digunakan oleh _*Owner Bot*_!",
    premium: "Perintah ini hanya untuk member _*Premium*_!",
    group: "Perintah ini hanya dapat digunakan di grup!",
    private: "Perintah ini hanya dapat digunakan di Chat Pribadi!",
    admin: "Perintah ini hanya dapat digunakan oleh admin grup!",
    error: "Terjadi kesalahan, coba lagi nanti.",
  };

// Port configuration
global.ports = [4000, 3000, 5000, 8000];

// Database configuration
global.limit = 100;


let fs = require('fs');
let chalk = require('chalk');
const file = require.resolve(__filename);

fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`Update 'config.js'`));
  delete require.cache[file];
  require(file);
});
